<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">

<style type="text/css">
@import url("webfonts/dtacform/stylesheet.css");
@import url("webfonts/raphaelicons/stylesheet.css");
body,td,th {
	font-family: dtacform;
	font-size: 16px;
	font-weight: bold;
}
body {
	margin-top: 0px;
	background-image: url(images/noise_pattern_with_crosslines_2x.png);
	background-repeat: repeat;
}
p.margin {margin-left:5cm}
</style>


<title>นิสิต : ตอบรับแล้ว</title>
<script type="text/javascript">
function mm_openbrwindow(theurl,winname,features) { //v2.0
  window.open(theurl,winname,features);
}
</script>
</head>

<body>
<p align="center"><img src="images/bannerlink2.png" alt="" width="674" height="145"></p>
<table width="90%" border="0" align="center">
  <tr>
    <td><span class="icon_type"><img src="images/linetopic.png" alt="" /><br>
      \</span><span class="pr_news"> รายนามนิสิตเข้าร่วม <br />
    </span> <font color="#006600"> โครงการประชุมสัมมนา "วันสถานประกอบการโครงการสหกิจศึกษาพบผู้บริหารมหาวิทยาลัยเกษตรศาสตร์" ครั้งที่ ๑๕</font></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="90%" border="1"  bordercolor="#422918" cellpadding="0"   cellspacing="0" align="center">
  <tr bgcolor="#f9726a">
    <th width="10%" bgcolor="#ecd9cc">รหัสประจำตัวนิสิต</th>
    <th width="6%" bgcolor="#ecd9cc">รุ่นที่</th>
    <th width="23%" bgcolor="#ecd9cc">ชื่อ - นามสกุล</th>
    <th width="24%" bgcolor="#ecd9cc">ภาควิชา</th>
    <th width="28%" bgcolor="#ecd9cc">คณะและวิทยาเขต</th>
 <!--   <th width="10%">วิทยาเขต</th> -->
    
  </tr><? $i = 1; ?>
       <tr bgcolor="#fff">
       <td><div align="center">5640203811</div></td>
         <td><div align="center">30</div></td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นางสาว  วิรมณ  จารุการ</td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;วิทยาศาสตร์ทั่วไป เคมีประยุกต์</td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;วิทยาศาตร์และวิศวกรรมศาสตร์</td>
     <!--<td>4  </td> -->
      
     
    </tr><? $i++; ?>
         <tr bgcolor="#fff">
       <td><div align="center">5611303251</div></td>
         <td><div align="center">28</div></td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นางสาว  วดีพัชร์  โสภาธนัตถ์สกุล</td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;การตลาด</td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บริหารธุรกิจ</td>
     <!--<td>1  </td> -->
      
     
    </tr><? $i++; ?>
    </table>
<center>
  <br>
  <a href="meeting.php"><img src="images/btnmeeting.png" alt="" width="200" height="132"></a>
</center>
<br>
<th scope="col"><style type="text/css">
@import url("webfonts/dtacform/stylesheet.css");

body {
	margin-bottom: 0px;
}
body,td,th {
	font-family: dtacform;
	color: #000;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
	color: #060;
}
a:active {
	text-decoration: none;
}
.tblmargin {
	border-bottom-width: 0px;
	position:relative;
	left:0px;
	bottom:0px;
}
</style>
<link href="css/raphaelicons.css" rel="stylesheet" type="text/css">
<body leftmargin="10" topmargin="0">
<table width="90%" border="0">
  <tr>
    <th width="20%" rowspan="2" align="center" bgcolor="#e1e1e1" scope="col"><img src="images/coopfooter.png" alt="" width="162" height="70"></th>
    <th width="40%" rowspan="2" bgcolor="#e1e1e1" class="footer-2" scope="col"><p>อาคารศูนย์เรียนรวม 1 ห้อง 105 ชั้น 1 <br>
      ศูนย์ประสานงานสหกิจศึกษา <br>
      ฝ่ายบริการการศึกษา มหาวิทยาลัยเกษตรศาสตร์<br>
      หมายเลขโทรศัพท์ 02 942 8200 ต่อ 1083 หรือ 1084</p></th>
    <th width="30%" height="21" bgcolor="#e1e1e1" class="contact_tel" scope="col"><span class="icon">m</span> เว็บไซต์ที่เกี่ยวข้อง</th>
  </tr>
  <tr>
    <td height="44%" bgcolor="#e1e1e1" class="font_footer"><p>ภายใน มก.<br>
      <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="http://www.eduserv.ku.ac.th/" target="_blank">ฝ่ายบริการการศึกษา</a><br />
        <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="http://www.eduserv.ku.ac.th/" target="_blank>ฝ่ายบริการการศึกษา มก.</a><br />
          <img src="images/dotcoop.png" width="10" height="9" /> <a href="http://www.registrar.ku.ac.th/" target="_blank">สำนักทะเบียนและประมวลผล</a><br />
        <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="http://www.sa.ku.ac.th/" target="_blank">กองกิจการนิสิต </a><br />
        <img src="images/dotcoop.png" alt=""  width="10" height="9" /> <a href="http://www.ku.ac.th/" target="_blank">มหาวิทยาลัยเกษตรศาสตร์(บางเขน)</a><br /><hr>
      <p>ภายนอก<br>
        <img src="images/dotcoop.png" alt="" width="10" height="9" /><a href="https://tace.sut.ac.th/tace/" target="_blank"> สมาคมสหกิจศึกษาไทย</a><br />
          <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="http://eduserv.ku.ac.th/idealgrad/" target="_blank">เครือข่ายสถาบันอุดมศึกษา</a><br /><hr>
        <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="index.php?page=sitemap_coop">site map</a><br />
      </p>
      </p>
  </tr>
  <tr class="footer-2">
    <th height="44" colspan="2" align="right" bgcolor="#ee5353" class="footermeetscoop_r" scope="col">&nbsp;&nbsp; copyright © 2015 cooperative education kasetsart university | &nbsp;</th>
    <th height="44" align="left" bgcolor="#ee5353" class="footermeetscoop_r" scope="col">ติดต่อผู้ดูแลระบบ regtdk@ku.ac.th</th>
  </tr>
</table>
</th>
</body>
</html>
