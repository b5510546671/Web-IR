<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">

<style type="text/css">
@import url("webfonts/dtacform/stylesheet.css");
@import url("webfonts/raphaelicons/stylesheet.css");
body,td,th {
	font-family: dtacform;
	font-size: 16px;
	font-weight: bold;
}
body {
	margin-top: 0px;
	background-image: url(images/noise_pattern_with_crosslines_2x.png);
}
</style>


<title>บุคคลากรภายในมหาวิทยาลัย : ตอบรับแล้ว</title>
<script type="text/javascript">
function mm_openbrwindow(theurl,winname,features) { //v2.0
  window.open(theurl,winname,features);
}
</script>
</head>

<body>
<p align="center"><img src="images/bannerlink2.png" alt="" width="674" height="145"></p>
<table width="90%" border="0" align="center">
  <tr>
    <td><span class="icon_type"><img src="images/linetopic.png" alt="" /><br>
      \ </span><span class="pr_news">รายนามบุคลากรภายในมหาวิทยาลัยเข้าร่วม <br />
    </span> <font color="#006600"> โครงการประชุมสัมมนา "วันสถานประกอบการโครงการสหกิจศึกษาพบผู้บริหารมหาวิทยาลัยเกษตรศาสตร์" ครั้งที่ ๑๕</font></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="90%" border="1" bordercolor="#006600" cellpadding="0"   cellspacing="0" align="center">
  <tr bgcolor="#99ff99">
    <th width="5%" bgcolor="#cffad2">ลำดับที่</th>
    <th width="17%" bgcolor="#cffad2">ชื่อ - นามสกุล</th>
    <th width="19%" bgcolor="#cffad2">ตำแหน่ง</th>
    <th width="14%" bgcolor="#cffad2">ภาควิชา</th>
    <th width="18%" bgcolor="#cffad2">คณะ - วิทยาเขต</th>
    <th width="10
    %" bgcolor="#2e8d2e"><font color="#ffffff">เข้าร่วมได้หรือไม่</font></th>
<!--    <th width="12%">วิทยาเขต</th> -->
    <th width="17%" bgcolor="#ffdece"><font color="#000000">ผู้ร่วมงาน (ตัวแทน)</font></th>
  </tr>
        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">1</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ผศ.  วิมล  รอดเพ็ชร</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รักษาการณ์แทนผู้อำนวยการสำนักทะเบียนและประมวลผล</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;สำนักทะเบียนและประมวลผล</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;สำนักทะเบียนและประมวลผล</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jr.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">2</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รศ. ดร.  ชลลดา  หลวงพิทักษ์</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รองคณบดีฝ่ายวิชากา</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;เศรษฐศาสตร์</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;เศรษฐศาสตร์</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jx.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">ดร.จักรกฤษณ์  พจนศิลป์</td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">3</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ผศ. ดร.  นรุณ  วรามิตร</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ผู้ช่วยอธิการบดีฝ่ายการศึกษาฯ</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;พืชไร่นา</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;เกษตร - กำแพงแสน</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jr.png"></td>
     <!-- <td>2</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">4</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;อาจารย์  สรณัฐ  ศิริสวย</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;หัวหน้าภาควิชา</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;เพาะเลี้ยงสัตว์น้ำ</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ประมง</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jr.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">5</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ดร.  ชนินทร์  ตรงจิตภักดี</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รักษาการแทนผู้ช่วยอธิการบดี</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;วิศวกรรมการบินและอวกาศ</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;วิศวกรรมศาสตร์</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jx.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">6</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รศ.  สร้อยสุดา  ณ ระนอง</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รักษาการแทนผู้ช่วยอธิการบดีฝ่ายวิชาการ</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ภาษาตะวันออก</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;มนุษยศาสตร์</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jr.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">7</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ผศ. ดร.  งามลมัย  ผิวเหลือง</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รักษาการแทนรองคณบดีฝ่ายกิจการนิสิต</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;สนง.อธิการบดิ</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jr.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">8</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ศ.  สถาพร  จิตตปาลพงศ์</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;คณบดี</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;เทคนิคการสัตวแพทย์</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jx.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">9</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ผศ.  กันยารัตน์  สุขะวัธนกุล</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ประธานกรรมการโครงการสหกิจศึกษา</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ศิลปศาสตร์และวิทยาการจัดการ - สกลนคร</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jr.png"></td>
     <!-- <td>4</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">10</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รศ.  คณิตา  ตังคณานุรักษ์</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รองคณบดีฝ่ายวืชาการ</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;วิทยาศาสตร์สิ่งแวดล้อม</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;คณะสิ่งแวดล้อม</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jr.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">11</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รศ. ดร.  เชษฐพงษ์  เมฆสัมพันธ์</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;คณบดี</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;คณะประมง</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jx.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">ดร.ศันสนีย์  หวังวรลักษณ์</td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">12</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ผศ.  วัฒนา  อนันตผล</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รักษาการรองคณบดีฝ่ายบริการวิชาการและวิเทศสัมพันธ์</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ภาษาต่างประเทศ</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;มนุษยศาสตร์</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jr.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">13</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ผศ. ดร.  ศิริพร  เรียบร้อย  คิม</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;อาจารย์</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;คหกรรมศาสตร์</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;เกษตร</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jr.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">14</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;อาจารย์  รติพร  มั่นพรหม</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;อาจารย์</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;วิศวกรรมวัสดุ</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;วิศวกรรมศาสตร์</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jr.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">15</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ดร.  ปวเรศ  ชมเดช</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รองคณบดีฝ่ายวืชาการ</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;วิศวกรรมการบินและอวกาศ</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;วิศวกรรมศาสตร์</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jr.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">16</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ผศ. ดร.  สุดสายสิน  แก้วเรือง</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;รองคณบดีฝ่ายวิชาการ</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;เกษตรกลวิธาน</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;เกษตร</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jr.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
            <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">17</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ดร.  สุจินต์  เจนวีรวัฒน์</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;อาจารย์</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;พืชไร่นา</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;เกษตร</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/jx.png"></td>
     <!-- <td>1</td> -->
      <td align="center" bgcolor="#fff1ea">-  </td>
    </tr>
        </table>
<br><center>
  <a href="meeting.php"><img src="images/btnmeeting.png" alt="" width="200" height="132"></a>
  </center>
<div><style type="text/css">
@import url("webfonts/dtacform/stylesheet.css");

body {
	margin-bottom: 0px;
}
body,td,th {
	font-family: dtacform;
	color: #000;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
	color: #060;
}
a:active {
	text-decoration: none;
}
.tblmargin {
	border-bottom-width: 0px;
	position:relative;
	left:0px;
	bottom:0px;
}
</style>
<link href="css/raphaelicons.css" rel="stylesheet" type="text/css">
<body leftmargin="10" topmargin="0">
<table width="90%" border="0">
  <tr>
    <th width="20%" rowspan="2" align="center" bgcolor="#e1e1e1" scope="col"><img src="images/coopfooter.png" alt="" width="162" height="70"></th>
    <th width="40%" rowspan="2" bgcolor="#e1e1e1" class="footer-2" scope="col"><p>อาคารศูนย์เรียนรวม 1 ห้อง 105 ชั้น 1 <br>
      ศูนย์ประสานงานสหกิจศึกษา <br>
      ฝ่ายบริการการศึกษา มหาวิทยาลัยเกษตรศาสตร์<br>
      หมายเลขโทรศัพท์ 02 942 8200 ต่อ 1083 หรือ 1084</p></th>
    <th width="30%" height="21" bgcolor="#e1e1e1" class="contact_tel" scope="col"><span class="icon">m</span> เว็บไซต์ที่เกี่ยวข้อง</th>
  </tr>
  <tr>
    <td height="44%" bgcolor="#e1e1e1" class="font_footer"><p>ภายใน มก.<br>
      <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="http://www.eduserv.ku.ac.th/" target="_blank">ฝ่ายบริการการศึกษา</a><br />
        <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="http://www.eduserv.ku.ac.th/" target="_blank>ฝ่ายบริการการศึกษา มก.</a><br />
          <img src="images/dotcoop.png" width="10" height="9" /> <a href="http://www.registrar.ku.ac.th/" target="_blank">สำนักทะเบียนและประมวลผล</a><br />
        <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="http://www.sa.ku.ac.th/" target="_blank">กองกิจการนิสิต </a><br />
        <img src="images/dotcoop.png" alt=""  width="10" height="9" /> <a href="http://www.ku.ac.th/" target="_blank">มหาวิทยาลัยเกษตรศาสตร์(บางเขน)</a><br /><hr>
      <p>ภายนอก<br>
        <img src="images/dotcoop.png" alt="" width="10" height="9" /><a href="https://tace.sut.ac.th/tace/" target="_blank"> สมาคมสหกิจศึกษาไทย</a><br />
          <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="http://eduserv.ku.ac.th/idealgrad/" target="_blank">เครือข่ายสถาบันอุดมศึกษา</a><br /><hr>
        <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="index.php?page=sitemap_coop">site map</a><br />
      </p>
      </p>
  </tr>
  <tr class="footer-2">
    <th height="44" colspan="2" align="right" bgcolor="#ee5353" class="footermeetscoop_r" scope="col">&nbsp;&nbsp; copyright © 2015 cooperative education kasetsart university | &nbsp;</th>
    <th height="44" align="left" bgcolor="#ee5353" class="footermeetscoop_r" scope="col">ติดต่อผู้ดูแลระบบ regtdk@ku.ac.th</th>
  </tr>
</table>
</div>


</body>

</html>
