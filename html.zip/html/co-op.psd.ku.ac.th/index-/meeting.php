
<style type="text/css">
@import url("webfonts/dtacform/stylesheet.css");
@import url("webfonts/raphaelicons/stylesheet.css");
body {
	margin-top: 0px;
	background-image: url(images/trig.jpg);
	background-repeat: repeat;
}
a:link {
	text-decoration: none;
	color: #000;
}
a:visited {
	text-decoration: none;
	color: #000;
}
a:hover {
	text-decoration: none;
	color: #900;
}
a:active {
	text-decoration: none;
	color: #000;
}
body,td,th {
	color: #000;
}
.table_2 {
	border-collapse: collapse;
	border: 1px solid #093;
	background-image: url(images/bgmeeting.png);
	background-repeat: no-repeat;
	background-position: right bottom;
}

</style>

<title>วันสถานประกอบการโครงการสหกิจศึกษาพบผู้บริหาร</title>

<body>
<table width="800" border="0" align="center" bgcolor="#ffffff" class="table_2" >
  <tr>
    <th scope="col"><a href="index.php"><img src="images/bannerlink.png" width="800" height="253"></a></th>
  </tr>
  <tr align="left">
    <th scope="col">&nbsp;</th>
  </tr>
  <tr align="left">
    <th scope="col">&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span class="icon_type">\</span><span class="pr_news"> &nbsp;&nbsp;&nbsp;โครงการประชุมสัมมนา <br>
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  วันสถานประกอบการโครงการสหกิจศึกษาพบผู้บริหาร <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  มหาวิทยาลัยเกษตรศาสตร์ 
    (ครั้งที่ ๑๕)<br>

    </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <img src="images/linetopic.png" /></th>
  </tr>
  <tr align="left">
    <th scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th scope="col"><table width="80%" border="0" cellspacing="0" >
        <tr>
          <th width="17%" scope="col">&nbsp;</th>
          <td colspan="2" align="left" class="text_meetscoop_2" scope="col">
         <img src="images/download.gif" width="32" height="32"> ดาวน์โหลดข้อมูลโครงการ</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td width="2%" class="text_meetscoop_2">&nbsp;</td>
          <td width="81%" class="text_meetscoop_2"><a href="coopsmeeting15_schedule.pdf" target="_blank"><img src="images/dotdownload.gif" alt="" width="16" height="16"> โครงการและกำหนดการ</a></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td class="text_meetscoop_2">&nbsp;</td>
          <td class="text_meetscoop_2"><a href="kumapcoopsmeeting.pdf" target="_blank"><img src="images/dotdownload.gif" alt="" width="16" height="16"> แผนที่อาคารสารนิเทศ ๕๐ปี</a></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2" class="text_meetscoop_2">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2" bgcolor="#dfffca" class="text_meetscoop_2">
          <!--<h2 style="color:#900">เปิดลงทะเบียนวันพฤหัสบดีที่ 13 ส.ค. 2558</h2> -->
          <img src="https://www.writingforums.org/data/photos/l/3/3625-1427656788-bedf2d35a97f13cd976e4ed69ed04143.gif">ลงทะเบียนใบตอบรับออนไลน์ (๑๐ - ๒๕ สิงหาคม ๒๕๖๐) </td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td bgcolor="#dfffca" class="text_meetscoop_2">&nbsp;</td>
          <td bgcolor="#dfffca" class="text_meetscoop_close"><img src="images/edit_gy.gif" width="16" height="16"> <a href="_company.php">สำหรับ : สถานประกอบการ</a></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td bgcolor="#dfffca" class="text_meetscoop_2">&nbsp;</td>
          <td bgcolor="#dfffca" class="text_meetscoop_close"><img src="images/edit_p.gif" width="16" height="16"> <a href="_student.php">สำหรับ : นิสิต</a></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td bgcolor="#dfffca" class="text_meetscoop_2">&nbsp;</td>
          <td bgcolor="#dfffca" class="text_meetscoop_close"><img src="images/edit_g.gif" width="16" height="16"> <a href="_meeting.php">สำหรับ : บุคคลากรมหาวิทยาลัยเกษตรศาสตร์</a></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td class="text_meetscoop_2">&nbsp;</td>
          <td class="text_meetscoop_2">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2" class="text_meetscoop_2"><img src="images/document_.gif" width="32" height="32"> <font color="#009900"  >รายนามผู้เข้าร่วมโครงการ</font></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td class="text_meetscoop_2">&nbsp;</td>
          <td class="text_meetscoop_2"><a href="company_list.php" ><img src="images/document_gy.gif" width="16" height="16"> <font color="#009900"  >สถานประกอบการ</font> </a></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td class="text_meetscoop_2">&nbsp;</td>
          <td class="text_meetscoop_2"><a href="student_list.php"><img src="images/document_p.gif" width="16" height="16"><font color="#009900"  > นิสิต</font></a></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td class="text_meetscoop_2">&nbsp;</td>
          <td class="text_meetscoop_2"><a href="meeting_list.php"><img src="images/document_g.gif" width="16" height="16"><font color="#009900"  > บุคคลากรภายในมหาวิทยาลัย</font></a></td>
        </tr>
    </table></th>
  </tr>
  <tr>
    <th scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th scope="col">กลับสู่เว็บไซต์สหกิจศึกษา</th>
  </tr>
  <tr>
    <th align="center" bgcolor="#00665e" scope="col"><a href="index.php"><img src="images/coopku2.png"></a></th>
  </tr>
  <tr>
 
  </tr>
</table>
</body>

</html>