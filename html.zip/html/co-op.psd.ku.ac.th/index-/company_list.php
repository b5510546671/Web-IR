
<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">

<style type="text/css">
@import url("webfonts/dtacform/stylesheet.css");
@import url("webfonts/raphaelicons/stylesheet.css");
body,td,th {
	font-family: dtacform;
	font-size: 16px;
	font-weight: bold;
}
body {
	margin-top: 0px;
	background-image: url(images/noise_pattern_with_crosslines_2x.png);
	background-repeat: repeat;
}
</style>


<title>สถานประกอบการ : ตอบรับแล้ว</title>
<script type="text/javascript">
function mm_openbrwindow(theurl,winname,features) { //v2.0
  window.open(theurl,winname,features);
}
</script>
</head>

<body>
<p align="center"><img src="images/bannerlink2.png" alt="" width="674" height="145"></p>
<table width="90%" border="0" align="center">
  <tr>
    <td><span class="icon_type"><img src="images/linetopic.png" alt="" /><br>
      \</span><span class="pr_news"> รายนามสถานประกอบการ ประสงค์เข้าร่วมงาน <br /> 
      </span>
   <font color="#006600"> โครงการประชุมสัมมนา "วันสถานประกอบการโครงการสหกิจศึกษาพบผู้บริหารมหาวิทยาลัยเกษตรศาสตร์" ครั้งที่ ๑๕</font></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="90%" border="1" bordercolor="#333333"  cellpadding="0"   cellspacing="0" align="center">
  <tr bgcolor="#cccccc">
    <th width="6%">ลำดับที่</th>
    <th width="25%" bgcolor="#e1e1e1">สถานประกอบการ</th>
    <th width="21%" bgcolor="#e1e1e1">ผู้ลงทะเบียนเข้าร่วมงาน</th>
    <th width="24%" bgcolor="#e1e1e1">ตำแหน่ง</th>
    <th width="8%" bgcolor="#009b9b"><font color="#ffffff">เข้าร่วม<br>
    ด้วยตนเอง</font></th>
    <!--<th width="13%">เบอร์โทรศัพท์</th> -->
<!--    <th width="14%" >อีเมล์</th> -->
    <th width="8%" bgcolor="#ffde98"><font color="#000000">ผู้เข้าร่วม(แทน)<br> หรือ ผู้ติดตาม</font></th>
  </tr>      <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">1</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บริษัท โยโซ เซอร์วิส จำกัด </td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาย  กฤตภาส  อินทร์ภักดี</td>
      <td align="center" bgcolor="#fff">กรรมการผู้จัดการ</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center">0800831474</td> -->
      <!--<td align="center">yosotravel@gmail.com</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=1','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">2</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บริษัท บอลลุนนี่ จำกัด</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาย  รุ่งโรจน์  สุวรรณธาดา</td>
      <td align="center" bgcolor="#fff">กรรมการผู้จัดการ</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center">0892415569</td> -->
      <!--<td align="center">info@balloonie.com</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=5','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">3</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;a-host company limited</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาย  พิชานน  จะเรียมพันธ์</td>
      <td align="center" bgcolor="#fff">consulting manager</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center">0894148149</td> -->
      <!--<td align="center">pichanon@a-host.co.th</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=6','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">4</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บริษัท สยามคูโบต้า คอร์ปอเรชั่น จำกัด</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาย  ปราโมทย์  ฤกษ์รัตนเศรษฐ์</td>
      <td align="center" bgcolor="#fff">ผู้จัดการส่วนทรัพยากรบุคคล-นวนคร</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"><img src="http://co-op.psd.ku.ac.th/index/images/pers_22.png"></td>
      <!--<td align="center">0818500309</td> -->
      <!--<td align="center"></td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=7','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">5</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บริษัท ไทคูณ ฟูดส์ จำกัด</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาย  พิพัฒน์  อมรเวชสันติ</td>
      <td align="center" bgcolor="#fff">กรรมการผู้จัดการ</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center">0814474440</td> -->
      <!--<td align="center"></td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=8','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">6</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ศูนย์วิจัยและพัฒนาพันธุกรรมสัตว์น้ำปทุมธานี</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาย  คงภพ  อำพลศักดิ์</td>
      <td align="center" bgcolor="#fff">นักวิชาการประมงชำนาญการพิเศษ</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center"></td> -->
      <!--<td align="center"></td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=9','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">7</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บริษัท เจริญโภคภัณฑ์ จำกัด (มหาชน)</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาย  ชยากร  โล่ห์ทองคำ</td>
      <td align="center" bgcolor="#fff">ผู้จัดการฝ่ายสรรหาและสร้างเครือข่าย</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center"></td> -->
      <!--<td align="center"></td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=10','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">8</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;sheraton grande sukhumvit </td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาย  กมล  เตชะผาติกุล</td>
      <td align="center" bgcolor="#fff">human resources officer</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center">0867862225</td> -->
      <!--<td align="center">kamol.tc@gmail.com</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=11','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">9</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บริษัท ศรีตรังแอโกรอินดัสทรี จำกัด (มหาชน) สาขาอุบลราชธานี</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาย  ดนัย  ฝ่ายคำตา</td>
      <td align="center" bgcolor="#fff">ผู้จัดการโรงงาน</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_44.png"></td>
      <!--<td align="center">0900434656</td> -->
      <!--<td align="center">danaif@sritranggroup.com</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=12','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">10</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;triumph aviation services asia. ltd.</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นางสาว  นพมาศ  ดีสม</td>
      <td align="center" bgcolor="#fff">hr. manager</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_22.png"></td>
      <!--<td align="center"></td> -->
      <!--<td align="center"></td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=13','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">11</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;สำนักงานเศรษฐกิจการเกษตร</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นางสาว  ดัาชา  ผ่องใส</td>
      <td align="center" bgcolor="#fff">นักทรัพยากรบุคคลชำนาญการพิเศษ</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center"></td> -->
      <!--<td align="center"></td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=14','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">12</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;senior aerospace (thailand) ltd.</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาง  ทัศนียวรรณ  สุระประเสริฐ</td>
      <td align="center" bgcolor="#fff">ผู้จัดการฝ่ายทรัพยากรบุคคล</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center"></td> -->
      <!--<td align="center"></td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=16','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">13</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บริษัท ไทยซัมมิท โอโตพาร์ทอินดัสตรี จำกัด</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาง  นิภา  อัครจันทโชติ</td>
      <td align="center" bgcolor="#fff">ผู้อำนวยการ</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"><img src="http://co-op.psd.ku.ac.th/index/images/pers_22.png"></td>
      <!--<td align="center"></td> -->
      <!--<td align="center"></td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=17','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">14</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บริษัท อะมิวส์เม้นท์ครีเอชั่น จำกัด (ดรีมเวิลด์)</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาย  วิลาศ  ก้อนธง</td>
      <td align="center" bgcolor="#fff">ผู้จัดการฝ่านทรัพยากรบุคคล</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center"></td> -->
      <!--<td align="center"></td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=18','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">15</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;rohm integrated systems (thailand) co.,ltd.</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นางสาว  เพชรรินทร์  เทียนดำ</td>
      <td align="center" bgcolor="#fff">hr chief</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center">0891882785</td> -->
      <!--<td align="center">recruitement@adm.rohmthai.com</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=19','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">16</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;kidzania bangkok </td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นางสาว  พัทธนินทร์   จิรสัจจานุกูล</td>
      <td align="center" bgcolor="#fff">ผู้อำนวยการฝ่ายทรัพยากรมนุษย์และบริหารงานทั่วไป</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"><img src="http://co-op.psd.ku.ac.th/index/images/pers_22.png"></td>
      <!--<td align="center">02-6831888</td> -->
      <!--<td align="center">nattawat@kidzania.co.th</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=20','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">17</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;อังสตรอม โซลูชั่น จำกัด</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นางสาว  ลลิน  อนุจารี</td>
      <td align="center" bgcolor="#fff">ผู้จัดการฝ่ายบริหารธุรกิจ</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center">0994963655</td> -->
      <!--<td align="center">lalin@angstromsolutions.net</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=21','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">18</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บริษัท แฟคเกอร์ จำกัด</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาย  ธีรยุทธ  โกสินทร์</td>
      <td align="center" bgcolor="#fff">chief executive officer</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_22.png"></td>
      <!--<td align="center">0892915831</td> -->
      <!--<td align="center">theerayooth.k@facgure.com</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=23','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">19</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ซัมมิท คอมพิวเตอร์ จำกัด</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาง  จินดา  บุญลาภทวีโชค</td>
      <td align="center" bgcolor="#fff">กรรมการผู้จัดการ</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_22.png"></td>
      <!--<td align="center">022380895</td> -->
      <!--<td align="center">jinda@summitthai.com</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=24','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">20</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;celestica (thailand) limited</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นางสาว  วีณา  อักษรแก้ว</td>
      <td align="center" bgcolor="#fff">hr director</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_22.png"></td>
      <!--<td align="center">038493561</td> -->
      <!--<td align="center">waksorn@celestica.com</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=25','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">21</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;exotissimo travel co.,ltd</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นางสาว  เย็นจิตร  เตชะธนาลัย</td>
      <td align="center" bgcolor="#fff">human resources and admin. manager</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center">026339060</td> -->
      <!--<td align="center">yenchit@exotissimo.com</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=26','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">22</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ซันฟู้ดอินเตอร์เนชั่นแนล จำกัด</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาย  สมศักดิ์   พัตรสิงห์</td>
      <td align="center" bgcolor="#fff">ผู้จัดการฝ่ายบริหารทรัพยากรมนุษย์</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"><img src="http://co-op.psd.ku.ac.th/index/images/pers_22.png"></td>
      <!--<td align="center">0816572810</td> -->
      <!--<td align="center">parinya.aumung@gmail.com</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=27','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">23</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บริษัท โธธ โซเชียล จำกัด</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นาย  ณัฐพร  ยอดแก้ว</td>
      <td align="center" bgcolor="#fff">product development</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"><img src="http://co-op.psd.ku.ac.th/index/images/pers_22.png"></td>
      <!--<td align="center">0867034678</td> -->
      <!--<td align="center">nuttapon@thothzocial.com</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=28','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">24</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บริษัท อุตสาหกรรมการบิน จำกัด</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-  น.อ.ดร.พิสิฐ  ประเสริฐศรี</td>
      <td align="center" bgcolor="#fff">ที่ปรึกษากรรมการผู้จัดการ</td>
      <td align="center" bgcolor="#fff"><img src="http://co-op.psd.ku.ac.th/index/images/pers_33.png"></td>
      <!--<td align="center">0813468507</td> -->
      <!--<td align="center"></td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=29','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>        <tr bgcolor="#fff">
      <td bgcolor="#fff"><div align="center">25</div></td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;prime solution and service co.,ltd</td>
      <td bgcolor="#fff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นางสาว  อันธิกา  ไวทย์วรศุข</td>
      <td align="center" bgcolor="#fff">senior hr</td>
      <td align="center" bgcolor="#fff"></td>
      <!--<td align="center">0816143183</td> -->
      <!--<td align="center">antika@primes.co.th</td> -->
      <td bgcolor="#fff"><div align="center">
      <? if($row_recordset1['comp_join']=='y') { ?>
        <input name="button" type="button" id="button" onclick="mm_openbrwindow('joiner.php?id=30','win1','width=550,height=500')" value="ข้อมูล"  />
        <? } ?>
      </div></td>
    </tr>    </table>
<br>
<center>
  <table width="350" border="0" cellspacing="0" cellpadding="0" align="right">
    <tr>
      <td width="100px" align="left">remark :</td>
      <td width="50px"><img src="images/pers_33.png" width="25" height="25"></td>
      <td width="50px">= ยินดีเข้าร่วม</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><img src="images/pers_22.png"></td>
      <td>= มีผู้ติดตาม หรือ ส่งผู้แทน</td>
    </tr>
    <tr>
       
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><img src="images/pers_44.png"></td>
      <td>= ไม่เข้าร่วม</td>
    </tr>
  </table>
  <br>
  <br>
  <br>
  <br>
<br>
  <a href="meeting.php"><img src="images/btnmeeting.png" width="200" height="132"></a>
</center>
<br>
<th scope="col"><style type="text/css">
@import url("webfonts/dtacform/stylesheet.css");

body {
	margin-bottom: 0px;
}
body,td,th {
	font-family: dtacform;
	color: #000;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
	color: #060;
}
a:active {
	text-decoration: none;
}
.tblmargin {
	border-bottom-width: 0px;
	position:relative;
	left:0px;
	bottom:0px;
}
</style>
<link href="css/raphaelicons.css" rel="stylesheet" type="text/css">
<body leftmargin="10" topmargin="0">
<table width="90%" border="0">
  <tr>
    <th width="20%" rowspan="2" align="center" bgcolor="#e1e1e1" scope="col"><img src="images/coopfooter.png" alt="" width="162" height="70"></th>
    <th width="40%" rowspan="2" bgcolor="#e1e1e1" class="footer-2" scope="col"><p>อาคารศูนย์เรียนรวม 1 ห้อง 105 ชั้น 1 <br>
      ศูนย์ประสานงานสหกิจศึกษา <br>
      ฝ่ายบริการการศึกษา มหาวิทยาลัยเกษตรศาสตร์<br>
      หมายเลขโทรศัพท์ 02 942 8200 ต่อ 1083 หรือ 1084</p></th>
    <th width="30%" height="21" bgcolor="#e1e1e1" class="contact_tel" scope="col"><span class="icon">m</span> เว็บไซต์ที่เกี่ยวข้อง</th>
  </tr>
  <tr>
    <td height="44%" bgcolor="#e1e1e1" class="font_footer"><p>ภายใน มก.<br>
      <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="http://www.eduserv.ku.ac.th/" target="_blank">ฝ่ายบริการการศึกษา</a><br />
        <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="http://www.eduserv.ku.ac.th/" target="_blank>ฝ่ายบริการการศึกษา มก.</a><br />
          <img src="images/dotcoop.png" width="10" height="9" /> <a href="http://www.registrar.ku.ac.th/" target="_blank">สำนักทะเบียนและประมวลผล</a><br />
        <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="http://www.sa.ku.ac.th/" target="_blank">กองกิจการนิสิต </a><br />
        <img src="images/dotcoop.png" alt=""  width="10" height="9" /> <a href="http://www.ku.ac.th/" target="_blank">มหาวิทยาลัยเกษตรศาสตร์(บางเขน)</a><br /><hr>
      <p>ภายนอก<br>
        <img src="images/dotcoop.png" alt="" width="10" height="9" /><a href="https://tace.sut.ac.th/tace/" target="_blank"> สมาคมสหกิจศึกษาไทย</a><br />
          <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="http://eduserv.ku.ac.th/idealgrad/" target="_blank">เครือข่ายสถาบันอุดมศึกษา</a><br /><hr>
        <img src="images/dotcoop.png" alt="" width="10" height="9" /> <a href="index.php?page=sitemap_coop">site map</a><br />
      </p>
      </p>
  </tr>
  <tr class="footer-2">
    <th height="44" colspan="2" align="right" bgcolor="#ee5353" class="footermeetscoop_r" scope="col">&nbsp;&nbsp; copyright © 2015 cooperative education kasetsart university | &nbsp;</th>
    <th height="44" align="left" bgcolor="#ee5353" class="footermeetscoop_r" scope="col">ติดต่อผู้ดูแลระบบ regtdk@ku.ac.th</th>
  </tr>
</table>
</th>
</body>
</html>
