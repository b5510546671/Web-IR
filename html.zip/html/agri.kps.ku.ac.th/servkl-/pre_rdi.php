<!doctype html public "-//w3c//dtd xhtml 1.0 transitional//en" "http://www.w3.org/tr/xhtml1/dtd/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=windows-874" />
<title>ãðºº§ò¹ºãô¡òãçôªò¡òã ¤³ðà¡éµã ¡óá¾§áê¹</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style5 {font-size: 16px}
-->
</style>
</head>

<body bottommargin="0" leftmargin="0" rightmargin="0" topmargin="0">
<table width="900" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td>
<meta http-equiv="content-type" content="text/html; charset=windows-874" />
<script type="text/javascript">
<!--
function mm_preloadimages() { //v3.0
  var d=document; if(d.images){ if(!d.mm_p) d.mm_p=new array();
    var i,j=d.mm_p.length,a=mm_preloadimages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexof("#")!=0){ d.mm_p[j]=new image; d.mm_p[j++].src=a[i];}}
}

function mm_swapimgrestore() { //v3.0
  var i,x,a=document.mm_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.osrc;i++) x.src=x.osrc;
}

function mm_findobj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexof("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=mm_findobj(n,d.layers[i].document);
  if(!x && d.getelementbyid) x=d.getelementbyid(n); return x;
}

function mm_swapimage() { //v3.0
  var i,j=0,x,a=mm_swapimage.arguments; document.mm_sr=new array; for(i=0;i<(a.length-2);i+=3)
   if ((x=mm_findobj(a[i]))!=null){document.mm_sr[j++]=x; if(!x.osrc) x.osrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<link href="css/style.css" rel="stylesheet" type="text/css">
<body onload="mm_preloadimages('images/bt-home-2.jpg','images/bt-product-2.jpg','images/bt-doc-2.jpg','images/bt-vdo-2.jpg','images/bt-contact-2.jpg','images/bt-login-2.jpg')">
<table width="900" height="300" border="0" cellpadding="0" cellspacing="0" background="images/header.jpg">
	            
  <tr>
    <td align="center" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="22">&nbsp;</td>
      </tr>
      <tr>
        <td height="57" align="right" valign="bottom"><table width="673" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="105"><a href="index.php"><img src="images/bt-home-1.jpg" name="image1" width="105" height="50" border="0" id="image1" onmouseover="mm_swapimage('image1','','images/bt-home-2.jpg',1)" onmouseout="mm_swapimgrestore()"></a></td>
            <td width="105"><a href="product.php"><img src="images/bt-product-1.jpg" name="image2" width="105" height="50" border="0" id="image2" onmouseover="mm_swapimage('image2','','images/bt-product-2.jpg',1)" onmouseout="mm_swapimgrestore()"></a></td>
            <td width="105"><a href="kljournal_detail.php"><img src="images/bt-doc-1.jpg" name="image3" width="105" height="50" border="0" id="image3" onmouseover="mm_swapimage('image3','','images/bt-doc-2.jpg',1)" onmouseout="mm_swapimgrestore()"></a></td>
            <td width="105"><a href="vdo.php"><img src="images/bt-vdo-1.jpg" width="105" height="50" border="0" id="image4" onmouseover="mm_swapimage('image4','','images/bt-vdo-2.jpg',1)" onmouseout="mm_swapimgrestore()"></a></td>
            <td width="105"><img src="images/bt-contact-1.jpg" width="105" height="50" id="image5" onmouseover="mm_swapimage('image5','','images/bt-contact-2.jpg',1)" onmouseout="mm_swapimgrestore()"></td>
            <td width="105"><a href="kl_login.php"><img src="images/bt-login-1.jpg" name="image6" width="105" height="50" border="0" id="image6" onmouseover="mm_swapimage('image6','','images/bt-login-2.jpg',1)" onmouseout="mm_swapimgrestore()"></a>			</td>
            <td width="105">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="205" valign="bottom"><table width="98%" border="0" align="right" cellpadding="0" cellspacing="0">
          <tr>
            <td>&nbsp;</td>
            <td align="right" class="brown13">
			&nbsp;		</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="260" background="images/bg-left.jpg" align="left" valign="top"><meta http-equiv="content-type" content="text/html; charset=windows-874" />
<link href="css/style.css" rel="stylesheet" type="text/css">
<table width="238" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="15">&nbsp;</td>
    <td width="20" height="30" align="center" valign="middle" style="border-bottom:#e5e5e5 1px solid"><img src="images/icon-dot-green.gif" width="11" height="11"></td>
    <td align="left" valign="middle" class="brown13" style="border-bottom:#e5e5e5 1px solid">¢èòçêòã§ò¹çô¨ñâ</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td height="30" align="center" valign="middle" style="border-bottom:#e5e5e5 1px solid"><img src="images/icon-dot-green.gif" width="11" height="11"></td>
    <td align="left" valign="middle" class="brown13" style="border-bottom:#e5e5e5 1px solid"><a href="pre_rdi.php">ãðºº°ò¹¢éíáùå§ò¹çô¨ñâáåð<br>
    ¼å§ò¹êãéò§êãã¤ì á¡. </a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td height="30" align="center" valign="middle" style="border-bottom:#e5e5e5 1px solid"><img src="images/icon-dot-green.gif" width="11" height="11"></td>
    <td align="left" valign="middle" class="brown13" style="border-bottom:#e5e5e5 1px solid"><a href="project_research.php">â¤ã§¡òãçô¨ñâ</a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td height="30">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</td>
            <td align="center" valign="top" background="images/bg-right.jpg"><table width="98%" border="0" align="left" cellpadding="0" cellspacing="0" class="blueleft">

              <tr>
                <td height="30" align="left" valign="middle" class="tahoma18">&nbsp;&nbsp;
				<img src="images/icon-title-green.gif" width="10" height="33" align="absmiddle" />
				ãðºº°ò¹¢éíáùå§ò¹çô¨ñâáåð§ò¹êãéò§êãã¤ì áëòçô·âòåñâà¡éµãèòêµãì </td>
              </tr>
              <tr>
                <td height="5" align="left" style="border-bottom:#e5e5e5 1px solid"><img src="images/blank.gif" width=10 height=5/></td>
              </tr>
              <tr>
                <td height="20" align="left"><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td width="15" height="25" ><img src="images/arrow.gif" width="10" height="11" /></td>
                      <td width="563" height="30" class="brown13"><a href="http://rdi.ku.ac.th/manualkur3/kur3_2550.pdf" target="_blank">¤óá¹ð¹óã¹¡òã¡ãí¡¢éíáùå§ò¹çô¨ñâáåð§ò¹êãéò§êãã¤ì</a></td>
                    </tr>
                    <tr>
                      <td height="25"><img src="images/arrow.gif" width="10" height="11" /></td>
                      <td height="30" class="brown13"><a href="http://research.rdi.ku.ac.th/kur3/login.aspx" target="_blank">àççºä«µìãðºº°ò¹¢éíáùå§ò¹çô¨ñâáåð§ò¹êãéò§êãã¤ì</a></td>
                    </tr>
                    <tr>
                      <td height="25"><img src="images/arrow.gif" width="10" height="11" /></td>
                      <td height="30" class="brown13"><a href="http://rdi.ku.ac.th/" target="_blank">àççºä«µìê¶òºñ¹çô¨ñâáåð¾ñ²¹òáëè§áëòçô·âòåñâà¡éµãèòêµãì</a></td>
                    </tr>
                    <tr>
                      <td height="25">&nbsp;</td>
                      <td height="30">&nbsp;</td>
                    </tr>
                </table></td>
              </tr>
              <tr>
                <td height="50">&nbsp;</td>
              </tr>
              <tr>
                <td height="50">&nbsp;</td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td background="images/bg-left.jpg">&nbsp;</td>
            <td background="images/bg-right.jpg">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="50" align="left"><meta http-equiv="content-type" content="text/html; charset=windows-874" />
<link href="css/style.css" rel="stylesheet" type="text/css">
<table width="899" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="50" align="center" bgcolor="e5e5e5" class="black13">¾ñ²¹òãðººâ´â : ¹.ê.´ç§¡áå ´éç§¨øá¾å ë¹èçâ¼åôµê×èíáåðà·¤â¹âåâõêòãê¹à·è ¤³ðà¡éµã ¡óá¾§áê¹</td>
  </tr>
</table>
</td>
      </tr>

    </table></td>
  </tr>
</table>
</body>
</html>
