<!doctype html public "-//w3c//dtd xhtml 1.0 transitional//en" "http://www.w3.org/tr/xhtml1/dtd/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=windows-874" />
<title>§ò¹ºãô¡òã¡òãèö¡éò</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
<!--
function mm_preloadimages() { //v3.0
  var d=document; if(d.images){ if(!d.mm_p) d.mm_p=new array();
    var i,j=d.mm_p.length,a=mm_preloadimages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexof("#")!=0){ d.mm_p[j]=new image; d.mm_p[j++].src=a[i];}}
}

function mm_swapimgrestore() { //v3.0
  var i,x,a=document.mm_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.osrc;i++) x.src=x.osrc;
}

function mm_findobj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexof("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=mm_findobj(n,d.layers[i].document);
  if(!x && d.getelementbyid) x=d.getelementbyid(n); return x;
}

function mm_swapimage() { //v3.0
  var i,j=0,x,a=mm_swapimage.arguments; document.mm_sr=new array; for(i=0;i<(a.length-2);i+=3)
   if ((x=mm_findobj(a[i]))!=null){document.mm_sr[j++]=x; if(!x.osrc) x.osrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body leftmargin="0" topmargin="0" rightmargin="0" bottommargin="0" onload="mm_preloadimages('images/2014/home02-01.jpg','images/2014/adviser2-01.jpg','images/2014/program2-01.jpg','images/2014/petition2-01.jpg','images/2014/info2-01.jpg','images/2014/calendar2-01.jpg','images/2014/download2-01.jpg','images/2014/login2-01.jpg')">
		<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" background="images/2014/bg_web_eduserv-02.jpg">
  <tr>
    <td align="center" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="200"><link href="css/style.css" rel="stylesheet" type="text/css" />

<table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
    <td height="80" align="left" valign="bottom"><a href="http://agri.kps.ku.ac.th" target="_blank"><img src="images/blank.gif" width="150" height="80" border="0"></a></td>
  </tr>
</table>
</td>
      </tr>
      <tr>
        <td align="center" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="240" align="center" valign="top" style="border-right: solid 2px #d8df20 "><table width="98%" border="0" align="center" cellpadding="5" cellspacing="0">
  <tr>
    <td height="31" align="right" class="black13bold">&nbsp;</td>
  </tr>
  <tr>
    <td height="31" align="right" class="black13bold"><a href="index.php"><img src="images/2014/cur_01.gif" width="148" height="31" border="0" id="image1" onmouseover="mm_swapimage('image1','','images/2014/cur_02.gif',1)" onmouseout="mm_swapimgrestore()" /></a></td>
  </tr>
  <tr>
    <td height="31" align="right" class="black14bold"><a href="cur_bachelor.php"><img src="images/2014/cur01_01.gif" name="image2" width="148" height="31" border="0" id="image2" onmouseover="mm_swapimage('image2','','images/2014/cur02_01.gif',1)" onmouseout="mm_swapimgrestore()" /></a></td>
  </tr>
  <tr>
    <td height="31" align="right" class="black14bold"><a href="cur_master.php"><img src="images/2014/cur01_02.gif" name="image3" width="148" height="31" border="0" id="image3" onmouseover="mm_swapimage('image3','','images/2014/cur02_02.gif',1)" onmouseout="mm_swapimgrestore()" /></a></td>
  </tr>
  <tr>
    <td height="31" align="right" class="black14bold"><a href="cur_doctor.php"><img src="images/2014/cur01_03.gif" name="image4" width="148" height="31" border="0" id="image4" onmouseover="mm_swapimage('image4','','images/2014/cur02_03.gif',1)" onmouseout="mm_swapimgrestore()" /></a></td>
  </tr>
   <!--<tr>
   <td height="31" align="right" class="black14bold"><a href="https://www.regis.ku.ac.th" target="_blank"><img src="images/2014/info1-01.jpg" width="148" height="31" border="0" id="image5" onmouseover="mm_swapimage('image5','','images/2014/info2-01.jpg',1)" onmouseout="mm_swapimgrestore()" /></a></td>
  </tr>
  <tr>
    <td height="31" align="right" class="black14bold"><a href="http://www.agri.kps.ku.ac.th/education/edu_form/educalendar-2559.pdf" target="_blank"><img src="images/2014/calendar1-01.jpg" width="148" height="31" border="0" id="image6" onmouseover="mm_swapimage('image6','','images/2014/calendar2-01.jpg',1)" onmouseout="mm_swapimgrestore()" /></a></td>
  </tr>
  <tr>
    <td height="31" align="right" class="black14bold"><a href="search_form.php" target="_blank"><img src="images/2014/download1-01.jpg" width="148" height="31" border="0" id="image7" onmouseover="mm_swapimage('image7','','images/2014/download2-01.jpg',1)" onmouseout="mm_swapimgrestore()" /></a></td>
  </tr>
  <tr>
    <td height="31" align="right" class="black14bold"><a href="main.php" target="_blank"><img src="images/2014/login1-01.jpg" width="148" height="31" border="0" id="image8" onmouseover="mm_swapimage('image8','','images/2014/login2-01.jpg',1)" onmouseout="mm_swapimgrestore()" /></a></td> 
  </tr>-->
  <tr>
    <td height="31" align="right" class="black14bold">&nbsp;</td>
  </tr>
</table>
</td>
            <td width="769" align="center" valign="top"><table width="99%" border="0" align="center" cellpadding="0" cellspacing="0">
              <form id="form1" name="form1" method="post" action="search_req.php" onsubmit="return checkit(this)" >

                <tr>
                  <td height="30" align="center"><table width="98%" border="0" align="left" cellspacing="0">
                    <tr>
                      <td width="3%" height="40" align="right" class="tahoma18"><img src="images/icon_title.gif" width="10" height="44" /></td>
                      <td height="40" align="left" valign="bottom" class="black20bold" style="border-bottom:#ccc 1px solid"  >ëåñ¡êùµããð´ñº»ãô­­òâ·</td>
                      </tr>
                  </table></td>
                </tr>
                <tr>
                  <td height="10" align="center">&nbsp;</td>
                </tr>
                <tr>
                  <td height="30" align="center"><table width="94%" border="0" align="left" cellpadding="0" cellspacing="0">
                    <tr>
                      <td width="45" height="30">&nbsp;</td>
                      <td align="left" class="black14bold">1. ç·.á. (¡òã»ãñº»ãø§¾ñ¹¸øì¾×ª)</td>
                    </tr>
                    <tr>
                      <td height="30">&nbsp;</td>
                      <td align="left" class="black14bold">2. ç·.á. (¡òã»ãñº»ãø§¾ñ¹¸øìêñµçìáåð¡òã¼åôµêñµçì)</td>
                    </tr>
                    <tr>
                      <td height="30">&nbsp;</td>
                      <td align="left" class="black14bold">3. ç·.á. (¤çòá»åí´àñâ¢í§íòëòãã¹¼åôµ¼å¨ò¡êñµçì)</td>
                    </tr>
                    <tr>
                      <td height="30">&nbsp;</td>
                      <td align="left" class="black14bold">4. ç·.á. (âàª¹èòêµãìáåðà·¤â¹âåâõíòëòãêñµçì)</td>
                    </tr>
                    <tr>
                      <td height="30">&nbsp;</td>
                      <td align="left" class="black14bold">5. ç·.á. (çô¨ñâáåð¾ñ²¹ò¡òãà¡éµã)</td>
                    </tr>
                    <tr>
                      <td height="30">&nbsp;</td>
                      <td align="left" class="black14bold">6. ç·.á. (çô¨ñâáåð¾ñ²¹ò¡òãà¡éµã) ¹ò¹òªòµô</td>
                    </tr>
                    <tr>
                      <td height="30">&nbsp;</td>
                      <td align="left" class="black14bold">7. ç·.á. (çô·âò¡òã¾×ªêç¹)</td>
                    </tr>
                    <tr>
                      <td height="30">&nbsp;</td>
                      <td align="left" class="black14bold">8. ç·.á. (çô·âòèòêµãìáåðà·¤â¹âåâõ¡òã¨ñ´¡òã´ô¹)</td>
                    </tr>
                    <tr>
                      <td height="30">&nbsp;</td>
                      <td align="left" class="black14bold">9. ç·.á. (íòãñ¡¢ò¾×ª)</td>
                    </tr>
                    <tr>
                      <td height="30">&nbsp;</td>
                      <td align="left" class="black14bold">10. ç·.á. (¡òã¨ñ´¡òã¿òãìáêáñâãëáè)</td>
                    </tr>
                    <tr>
                      <td height="30">&nbsp;</td>
                      <td align="left" class="blue14bold">ëåñ¡êùµã·õè¢íãªéãèçá¡ñº¤³ðà¡éµã</td>
                    </tr>
                    <tr>
                      <td height="30">&nbsp;</td>
                      <td align="left" class="black14bold">1. ç·.á. (¡õ¯çô·âò)</td>
                    </tr>
                    <tr>
                      <td height="30">&nbsp;</td>
                      <td align="left" class="black14bold">2. ç·.á. (¾×ªäãè)</td>
                    </tr>
                    <tr>
                      <td height="30">&nbsp;</td>
                      <td align="left" class="black14bold">3. ç·.á. (âã¤¾×ª)</td>
                    </tr>
                  </table></td>
                </tr>
                <tr>
                  <td height="10" align="left">&nbsp;</td>
                </tr>
                <tr>
                  <td height="30" align="center">&nbsp;</td>
                </tr>
              </form>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="100"><link href="css/style.css" rel="stylesheet" type="text/css" />
<table width="96%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="30" align="right" class="gray13bold"><a href="http://qrcode.kaywa.com/img.php?s=5&amp;d=http%3a%2f%2fagri.kps.ku.ac.th" target="_blank"><img src="images/2014/banner_qrcode.jpg" width="54" height="65" border="0" /></a>&nbsp;&nbsp; <a href="https://th-th.facebook.com/agrikps" target="_blank"><img src="images/2014/banner_facebook.jpg" width="54" height="65" border="0" /></a>&nbsp;&nbsp;</td>
  </tr>
  <tr>
    <td height="30" align="right" class="gray13bold">¾ñ²¹òãðººâ´â : ë¹èçâ¼åôµê×èíáåðà·¤â¹âåâõêòãê¹à·è ¤³ðà¡éµã ¡óá¾§áê¹&nbsp;&nbsp;</td>
  </tr>
  <tr>
    <td height="20" align="right" class="gray13">áëòçô·âòåñâà¡éµãèòêµãì  çô·âòà¢µ¡óá¾§áê¹  í.¡óá¾§áê¹  ¨.¹¤ã»°á 73140&nbsp;&nbsp;</td>
  </tr>
  <tr>
    <td height="20" align="right" class="gray13">µô´µèí¼ùé´ùáåãðºº agrdmd@ku.ac.th&nbsp;&nbsp;</td>
  </tr>
</table>
</td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
