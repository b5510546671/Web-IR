<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=windows-874" />
<title>¢èòç - §ò¹»ãðªòêñá¾ñ¹¸ì ¤³ðà¡éµã ¡óá¾§áê¹</title>
<link href="../newscss/styledt.css" rel="stylesheet" type="text/css">
<script language=javascript>
<!--
function changeto(obj,highlightcolor){
obj.style.backgroundcolor = highlightcolor;
}

function tmt_confirm(msg){
document.mm_returnvalue=(confirm(unescape(msg)));
}
//-->
</script>
</head>

<body>
<table width="1000" border="0" align="center" cellspacing="0" style=" outline-style:dashed">
  <tr>
    <td><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
      <tr>
        <td><meta http-equiv="content-type" content="text/html; charset=windows-874" />
<table width="1000" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="19" background="../newsimages/bg-top-01.jpg"><table width="734" border="0" align="right" cellpadding="0" cellspacing="0">
	            
      <tr>
        <td width="100" valign="top">&nbsp;</td>
        <td width="100" valign="top">&nbsp;</td>
        <td align="right" class="whiteleft"><a href="index.php">
		home</a>&nbsp;|&nbsp;
		<a href="news_login.php">login</a>		</td>
        <td width="70">&nbsp;</td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="50" valign="top" background="../newsimages/bg-top-white.gif"><table width="950" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100" valign="top"><a href="news_all.php"><img src="../newsimages/bt-news.gif" width="100" height="45" border="0" /></a></td>
        <td width="100" valign="top"><a href="../newsact/"><img src="../newsimages/bt-activity.gif" width="100" height="45" border="0" /></a></td>
        <td width="100" valign="top"><a href="../../deantalk/"><img src="../newsimages/bt-deantalk.gif" width="100" height="45" border="0" /></a></td>
        <td width="100" valign="top"><a href="../agri_journal/"><img src="../newsimages/bt-journal.gif" width="100" height="45" border="0" /></a></td>
        <td width="100" valign="top"><a href="../booknews/"><img src="../newsimages/bt-book.gif" width="100" height="45" border="0" /></a></td>
        <td width="100" valign="top"><a href="../agri_report/"><img src="../newsimages/bt-report.gif" width="100" height="45" border="0" /></a></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="119" background="../newsimages/bg-top-02.jpg">&nbsp;</td>
  </tr>
</table>
		</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="left" class="gray12blue"><table width="98%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="50%"><input type="hidden" name="" size = "60" value="">                  <img src="../newsimages/blank.gif" width="20" height="10"><img src="../newsimages/icon_gray.gif" width="10" height="10"> <a href="index.php">ë¹éòëåñ¡</a>&nbsp;&gt;&nbsp; <a href="news_all.php">¢èòç</a>
                  </td>
                <td width="50%" align="right" class="gray12bold">&nbsp;</td>
              </tr>
            </table></td>
            <td align="left" valign="top" background="../newsimages/bg-right.jpg">&nbsp;</td>
          </tr>
          <tr>
            <td align="center" valign="top" ><table width="98%" border="0" align="center" cellpadding="3" cellspacing="0">
              <tr>
                <td>
				<form action="news_all.php" method="post"  name="form1" id="form1">
				  <table width="100%" border="0" align="center" cellspacing="0">
                      <tr>
                        <td height="30" align="center" class="orangeh"><!--¢èòç¤³ðà¡éµã ¡óá¾§áê¹ --> </td>
                      </tr>
							  							
                          
                      <tr>
                        <td height="25"><table width="100%" border="0" align="right" cellpadding="2" cellspacing="0" class="greenh">
                            <!--<tr>
                              <td height="3" colspan="7" align="center" bgcolor="#f7f7f7" style="border-top:#999999 1px solid"><img src="../newsimages/blank.gif" width="10" height="3"></td>
                              </tr> -->
                            <tr>
                              <!--<td width="30" height="30" align="center" bgcolor="#f7f7f7" class="gray12bold">åó´ñº</td> 
                              <td width="100" align="left" bgcolor="#f7f7f7" class="gray12bold">»ãðàà·</td>-->
							  <td width="90" height="30" align="center"  class="gray12bold"></td>
                              <td width="200" align="left" class="gray12bold">ëñç¢éí¢èòç</td>
                              <td width="100" align="left" class="gray12bold">â´â</td>
                             <!-- <td width="100" align="left" bgcolor="#f7f7f7" class="gray12bold">çñ¹êôé¹êø´»ãð¡òè</td> -->
							                                <!--<td width="30" align="center" class="gray12bold">á¡éä¢</td>
                              <td width="30" align="center" class="gray12bold">åº</td> -->
							                             </tr>
                            <tr>
                              <td height="3" colspan="7" align="center" style="border-top:#cccccc 1px solid"><img src="../newsimages/blank.gif" width="10" height="3"></td>
                              </tr>
						<tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#fdf3ee')" bgcolor=#fdf3ee height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 28-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1254&prev=news_all.php">¢íàªô­¹ôêôµ ¤³ðà¡éµã ¡óá¾§áê¹ ãèçá¡ô¨¡ããá ¾õèµôç¹éí§ (çôªòà¤áõ ¤ãñé§·õè 1)
</a><br><br></td><td align=left valign=top class=black13blue width=100>êø¹òãõ&nbsp;êçèò§èãõ</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#f9f9f9')" bgcolor=#f9f9f9 height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 23-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1251&prev=news_all.php">¢íàªô­ãèçáà»ç¹à¡õâãµôã¹§ò¹ ãçá¾åñ§ã¨ êò¹ãñ¡áåð¼ù¡¾ñ¹</a><br><br></td><td align=left valign=top class=black13blue width=100>êø¹òãõ&nbsp;êçèò§èãõ</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#fdf3ee')" bgcolor=#fdf3ee height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 23-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1253&prev=news_all.php">àªô­ãèçáµéí¹ãñº...¹òâ¡êàòáëòçô·âòåñâà¡éµãèòêµãì ¤³ð¡ããá¡òãêàòï áåð¼ùéºãôëòã</a><br><br></td><td align=left valign=top class=black13blue width=100>êø¹òãõ&nbsp;êçèò§èãõ</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#f9f9f9')" bgcolor=#f9f9f9 height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 22-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1247&prev=news_all.php">ãòâª×èí¼ùéáõêô·¸ôìêíº¤ñ´àå×í¡à¢éòà»ç¹¾¹ñ¡§ò¹áëòçô·âòåñâ (à§ô¹ãòâä´é)<br />
µóáë¹è§ ¹ñ¡çôªò¡òãèö¡éò êñ§¡ñ´êó¹ñ¡§ò¹àå¢ò¹ø¡òã ¨ó¹ç¹ 1 íñµãò<br />
</a><br><br></td><td align=left valign=top class=black13blue width=100>§ò¹ºãôëòãáåð¸øã¡òã&nbsp;</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#fdf3ee')" bgcolor=#fdf3ee height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 22-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1250&prev=news_all.php">ãñºêáñ¤ã¹ôêôµ·õèµéí§¡òããñº·ø¹¡òãèö¡éòà¤ã×íà¨ãô­âà¤àñ³±ì</a><br><br></td><td align=left valign=top class=black13blue width=100>êø¹òãõ&nbsp;êçèò§èãõ</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#f9f9f9')" bgcolor=#f9f9f9 height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 21-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1245&prev=news_all.php">àªô­ãèçáêáñ¤ã ãñº¡òãêããëò ¤³º´õ¤³ðà¡éµã ¡óá¾§áê¹</a><br><br></td><td align=left valign=top class=black13blue width=100>êø¹òãõ&nbsp;êçèò§èãõ</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#fdf3ee')" bgcolor=#fdf3ee height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 18-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1248&prev=news_all.php">»ãð¡òèêíºãò¤ò¨ñ´«×éí¤ãøàñ³±ì à¤ã×èí§çñ´èñ¡âàò¾¢í§¹éóã¹ãº¾×ª</a><br><br></td><td align=left valign=top class=black13blue width=100>§ò¹¤åñ§áåð¾ñê´ø&nbsp;</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#f9f9f9')" bgcolor=#f9f9f9 height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 18-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1249&prev=news_all.php">»ãð¡òèêíºãò¤ò«×éí¤ãøàñ³±ìã¶á·ã¡àµíãì ¾ãéíáªø´â¤ã§¡ñ¹íéíâ áåðªø´íø»¡ã³ìµô´·éòâã¶á·ã¡àµíãì ¨ó¹ç¹ 2 ¤ñ¹</a><br><br></td><td align=left valign=top class=black13blue width=100>§ò¹¤åñ§áåð¾ñê´ø&nbsp;</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#fdf3ee')" bgcolor=#fdf3ee height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 17-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1243&prev=news_all.php">¼å¡òãêíº¤ñ´àå×í¡à¢éòà»ç¹¾¹ñ¡§ò¹áëòçô·âòåñâà§ô¹ãòâä´é µóáë¹è§¾¹ñ¡§ò¹·ñèçä» êñ§¡ñ´àò¤çôªòêñµçºòå ¨ó¹ç¹ 1 íñµãò</a><br><br></td><td align=left valign=top class=black13blue width=100>§ò¹ºãôëòãáåð¸øã¡òã&nbsp;</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#f9f9f9')" bgcolor=#f9f9f9 height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 17-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1238&prev=news_all.php">íºãáëåñ¡êùµã ¡òã¢âòâ¾ñ¹¸øìäáé¼åàªô§¸øã¡ô¨ ãøè¹·õè 4  çñ¹·õè 1  3 ¡ñ¹âòâ¹ 2560</a><br><br></td><td align=left valign=top class=black13blue width=100>àò¤çôªò¾×ªêç¹&nbsp;</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#fdf3ee')" bgcolor=#fdf3ee height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 17-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1239&prev=news_all.php">ëåñ¡êùµã à·¤¹ô¤¡òã¼åôµáðáèç§¹í¡ä´ù çñ¹·õè 17 ¡ñ¹âòâ¹ 2560 (1200 ºò·/·èò¹)</a><br><br></td><td align=left valign=top class=black13blue width=100>àò¤çôªò¾×ªêç¹&nbsp;</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#f9f9f9')" bgcolor=#f9f9f9 height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 17-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1240&prev=news_all.php">íºãáëåñ¡êùµã  à·¤¹ô¤¡òã¼åôµ½ãñè§àªô§¸øã¡ô¨ ãøè¹·õè 8  (5 ¾.â. 2560)</a><br><br></td><td align=left valign=top class=black13blue width=100>àò¤çôªò¾×ªêç¹&nbsp;</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#fdf3ee')" bgcolor=#fdf3ee height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 17-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1241&prev=news_all.php">à·¤¹ô¤¡òã¼åôµáð¹òç¹í¡ä´ùáåð¡òã¼åôµãºáð¡ãù´àªô§¡òã¤éò ãøè¹·õè 46  47</a><br><br></td><td align=left valign=top class=black13blue width=100>àò¤çôªò¾×ªêç¹&nbsp;</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#f9f9f9')" bgcolor=#f9f9f9 height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 17-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1242&prev=news_all.php">¡òã¨ñ´·ã§áåðµñ´áµè§·ã§¾øèáµé¹äáé¼å ãøè¹·õè 5 (18-19 ¾.â.2560)</a><br><br></td><td align=left valign=top class=black13blue width=100>àò¤çôªò¾×ªêç¹&nbsp;</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#fdf3ee')" bgcolor=#fdf3ee height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 15-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1235&prev=news_all.php">ºãôéñ· íõê·ì àçê·ì «õ´ ¨ó¡ñ´  ãñº¹ôêôµ½ö¡§ò¹</a><br><br></td><td align=left valign=top class=black13blue width=100>êø¹òãõ&nbsp;êçèò§èãõ</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#f9f9f9')" bgcolor=#f9f9f9 height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 02-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1230&prev=news_all.php">¢íàãõâ¹àªô­à¢éòãèçá§ò¹êñáá¹òçôªò¡òã "âí¡òê áåð¤çòá·éò·òâ íòëòãêñµçìä·â 4.0"
áåðãèçááê´§áø·ôµò¨ôµá´è ¼è.´ã.àê¡êá íòµáò§¡ùã</a><br><br></td><td align=left valign=top class=black13blue width=100>êø¹òãõ&nbsp;êçèò§èãõ</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#fdf3ee')" bgcolor=#fdf3ee height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 01-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1228&prev=news_all.php">ãñºêáñ¤ã¤ñ´àå×í¡ºø¤¤åà¢éòà»ç¹¾¹ñ¡§ò¹áëòçô·âòåñâà§ô¹ãòâä´é µóáë¹è§¹ñ¡çôªò¡òãèö¡éò êñ§¡ñ´êó¹ñ¡§ò¹àå¢ò¹ø¡òã¤³ðà¡éµã ¡óá¾§áê¹ ãñº¶ö§çñ¹·õè21ê.¤.2560</a><br><br></td><td align=left valign=top class=black13blue width=100>§ò¹ºãôëòãáåð¸øã¡òã&nbsp;</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#f9f9f9')" bgcolor=#f9f9f9 height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 01-08-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1229&prev=news_all.php">ãòâª×èí¼ùéáõêô·¸ôìêíº¤ñ´àå×í¡à¢éòà»ç¹¾¹ñ¡§ò¹áëòçô·âòåñâà§ô¹ãòâä´é
µóáë¹è§¾¹ñ¡§ò¹·ñèçä» íñµãòàå¢·õè ¾.øõ êñ§¡ñ´ àò¤çôªòêñµçºòå 
</a><br><br></td><td align=left valign=top class=black13blue width=100>§ò¹ºãôëòãáåð¸øã¡òã&nbsp;</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#fdf3ee')" bgcolor=#fdf3ee height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 31-07-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1227&prev=news_all.php">¼å¡òã¤ñ´àå×í¡à¢éòà»ç¹¾¹ñ¡§ò¹áëòçô·âòåñâà§ô¹ãòâä´é µóáë¹è§¹ñ¡çôªò¡òãèö¡éò íñµãòàå¢·õè ¾.116 êñ§¡ñ´êó¹ñ¡§ò¹àå¢ò¹ø¡òã¤³ðà¡éµã ¡óá¾§áê¹</a><br><br></td><td align=left valign=top class=black13blue width=100>§ò¹ºãôëòãáåð¸øã¡òã&nbsp;</td></tr><tr onmouseover="javascript:changeto(this,'#f2b637')" onmouseout="javascript:changeto(this,'#f9f9f9')" bgcolor=#f9f9f9 height="20" class="black13"><td align=left valign=top class=black13blue width=90 ><img src="../newsimages/icon-blue.gif"> [ 26-07-2560 ]</td><td align=left valign=top class=black13blue><a href="news_detail.php?newsp_id=1225&prev=news_all.php">»ãð¡òèãòâª×èííò¨òãâì·õè»ãö¡éò¹ôêôµªñé¹»õ·õè 1 »ãð¨ó»õ¡òãèö¡éò 2560</a><br><br></td><td align=left valign=top class=black13blue width=100>êø¹òãõ&nbsp;êçèò§èãõ</td></tr>                            <tr>
                              <td height="3" colspan="7" align="center" style="border-bottom:#cccccc 1px solid"><img src="../newsimages/blank.gif" width="10" height="3"></td>
                              </tr>
							<tr>
                              <td height="5" colspan="7" align="left" class="gray12bold"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td width="50%">&nbsp;</td>
                                  <td width="50%" align="right" class="gray12or">
								  <br> ë¹éò 1 / 2 [ <a href=?page=2&pagesize=20>¶ñ´ä»</a> ]  [   <a href=?page=1&pagesize=20>1</a>    <a href=?page=2&pagesize=20>2</a>   ] 								  </td>
                                </tr>
                              </table></td>
                              </tr>
                        </table>
                          </td>
                      </tr>
                    </table>
                </form></td>
              </tr>
            </table></td>
            <td width="304" align="left" valign="top" background="../newsimages/bg-right.jpg"><meta http-equiv="content-type" content="text/html; charset=windows-874" />

<link href="../newscss/styledt.css" rel="stylesheet" type="text/css">
<table width="254" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="50" align="center" background="../newsimages/bg-right-blue.jpg" class="whiteleft"><a href="news_all.php">¢èòç¤³ðà¡éµã ¡óá¾§áê¹</a></td>
  </tr>
  <tr>
    <td height="20" align="right" class="gray12bold">&nbsp;</td>
  </tr>
  <tr>
    <td height="30" align="left" valign="middle" class="gray12bold" ><table width="95%" border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
        <td height="30" class="gray12bold" style="border-bottom:#e5e5e5 1px solid "><img src="../newsimages/blank.gif" width="30" height="10" /><a href="news_all.php?type=1">¢èòç»ãðªòêñá¾ñ¹¸ì</a></td>
      </tr>
      <tr>
        <td height="30" class="gray12bold" style="border-bottom:#e5e5e5 1px solid "><img src="../newsimages/blank.gif" width="30" height="10" /><a href="news_all.php?type=2">¢èòç¹ôêôµ/½ö¡§ò¹</a></td>
      </tr>
      <tr>
        <td height="30" class="gray12bold" style="border-bottom:#e5e5e5 1px solid "><img src="../newsimages/blank.gif" width="30" height="10" /><a href="news_all.php?type=3">¢èòç¡òãèö¡éò/·ø¹¡òãèö¡éò</a></td>
      </tr>
      <tr>
        <td height="30" class="gray12bold" style="border-bottom:#e5e5e5 1px solid "><img src="../newsimages/blank.gif" width="30" height="10" /><a href="news_all.php?type=4">¢èòçêñáá¹ò/½ö¡íºãá</a></td>
      </tr>
      <tr>
        <td height="30" class="gray12bold" style="border-bottom:#e5e5e5 1px solid "><img src="../newsimages/blank.gif" width="30" height="10" /><a href="news_all.php?type=5">¢èòçãñºêáñ¤ã§ò¹</a></td>
      </tr>
      <tr>
        <td height="30" class="gray12bold" style="border-bottom:#e5e5e5 1px solid "><img src="../newsimages/blank.gif" width="30" height="10" /><a href="news_all.php?type=6">¢èòçêíºãò¤ò</a></td>
      </tr>
      <tr>
        <td height="30" class="gray12bold" style="border-bottom:#e5e5e5 1px solid "><img src="../newsimages/blank.gif" width="30" height="10" /><a href="news_all.php?type=7">¢èòççôà·èêñá¾ñ¹¸ì</a></td>
      </tr>
      <tr>
        <td height="30" class="gray12bold" style="border-bottom:#e5e5e5 1px solid "><img src="../newsimages/blank.gif" width="30" height="10" /><a href="news_all.php?type=8">¤óêñè§/»ãð¡òè</a></td>
      </tr>
      <tr>
        <td height="30" class="gray12bold" style="border-bottom:#e5e5e5 1px solid "><img src="../newsimages/blank.gif" width="30" height="10" /><a href="news_all.php?type=9">º·¤çòá·ò§çôªò¡òã</a></td>
      </tr>
      <tr>
        <td height="30" class="gray12bold" style="border-bottom:#e5e5e5 1px solid "><img src="../newsimages/blank.gif" width="30" height="10" /><a href="bann_all.php">banner</a></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="20">&nbsp;</td>
  </tr>
  <tr>
    <td height="30"><img src="../newsimages/blank.gif" width="30" height="10"><a href="http://get.adobe.com/reader/" target="_blank"><img src="../newsimages/get_adobe_reader.png" width="158" height="39" border="0"></a></td>
  </tr>
  <tr>
    <td height="30">&nbsp;</td>
  </tr>
</table>
</td>
          </tr>
          <tr>
            <td align="center" valign="top">&nbsp;</td>
            <td align="left" valign="top" background="../newsimages/bg-right.jpg">&nbsp;</td>
          </tr>
        </table></td>
      </tr>

      <tr>
        <td height="77"><meta http-equiv="content-type" content="text/html; charset=windows-874" />
<table width="1000" height="77" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top" background="../newsimages/bg-bottom.jpg"><table width="100%" border="0" align="center" cellspacing="0">
      <tr>
        <td height="30" align="center" valign="middle" class="black12"><strong>¾ñ²¹òãðººâ´â : ¹.ê.´ç§¡áå ´éç§¨øá¾å  ë¹èçâ¼åôµê×èíáåðà·¤â¹âåâõêòãê¹à·è ¤³ðà¡éµã ¡óá¾§áê¹</strong></td>
      </tr>
      <tr>
        <td width="1000" height="30" align="center" valign="middle" class="black12">
          áëòçô·âòåñâà¡éµãèòêµãì  çô·âòà¢µ¡óá¾§áê¹  í.¡óá¾§áê¹  ¨.¹¤ã»°á 73140</td>
      </tr>
    </table></td>
  </tr>
</table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
