<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=windows-874" />
<title>çõ´õ·ñè¹ì¡ô¨¡ããá - §ò¹»ãðªòêñá¾ñ¹¸ì ¤³ðà¡éµã ¡óá¾§áê¹</title>
<link href="../newscss/styledt.css" rel="stylesheet" type="text/css">


	<script type="text/javascript" src="../newscss/jquery.min.js"></script>
	<script>
		!window.jquery && document.write('<script src="jquery-1.4.3.min.js"><\/script>');
	</script>
	<script type="text/javascript" src="./fancybox/jquery.mousewheel-3.0.4.pack.js"></script>
	<script type="text/javascript" src="./fancybox/jquery.fancybox-1.3.4.pack.js"></script>
	<link rel="stylesheet" type="text/css" href="./fancybox/jquery.fancybox-1.3.4.css" media="screen" />
 	<link rel="stylesheet" href="style.css" />
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			*   examples - images
			*/

			$("a#example1").fancybox();

			$("a#example2").fancybox({
				'overlayshow'	: false,
				'transitionin'	: 'elastic',
				'transitionout'	: 'elastic'
			});

			$("a#example3").fancybox({
				'transitionin'	: 'none',
				'transitionout'	: 'none'	
			});

			$("a#example4").fancybox({
				'opacity'		: true,
				'overlayshow'	: false,
				'transitionin'	: 'elastic',
				'transitionout'	: 'none'
			});

			$("a#example5").fancybox();

			$("a#example6").fancybox({
				'titleposition'		: 'outside',
				'overlaycolor'		: '#000',
				'overlayopacity'	: 0.9
			});

			$("a#example7").fancybox({
				'titleposition'	: 'inside'
			});

			$("a#example8").fancybox({
				'titleposition'	: 'over'
			});

			$("a[rel=example_group]").fancybox({
				'transitionin'		: 'none',
				'transitionout'		: 'none',
				'titleposition' 	: 'over',
				'titleformat'		: function(title, currentarray, currentindex, currentopts) {
					return '<span id="fancybox-title-over">image ' + (currentindex + 1) + ' / ' + currentarray.length + (title.length ? ' &nbsp; ' + title : '') + '</span>';
				}
			});

			/*
			*   examples - various
			*/

			$("#various1").fancybox({
				'titleposition'		: 'inside',
				'transitionin'		: 'none',
				'transitionout'		: 'none'
			});

			$("#various2").fancybox();

			$("#various3").fancybox({
				'width'				: '75%',
				'height'			: '75%',
				'autoscale'			: false,
				'transitionin'		: 'none',
				'transitionout'		: 'none',
				'type'				: 'iframe'
			});

			$("#various4").fancybox({
				'padding'			: 0,
				'autoscale'			: false,
				'transitionin'		: 'none',
				'transitionout'		: 'none'
			});
		});
	</script>



<script language=javascript>
<!--
function changeto(obj,highlightcolor){
obj.style.backgroundcolor = highlightcolor;
}

function tmt_confirm(msg){
document.mm_returnvalue=(confirm(unescape(msg)));
}

function chknumber(){
	if (event.keycode<13 || (event.keycode>13 && event.keycode<48) || event.keycode>57) {
		alert("ãêèä´éà©¾òðµñçàå¢");
		event.returnvalue = false;
	}
}

function mm_openbrwindow(theurl,winname,features) { //v2.0
window.open(theurl,winname,features);
}

//-->
</script>



</head>

<body>
<table width="1000" border="0" align="center" cellspacing="0" style=" outline-style:dashed">
  <tr>
    <td><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
      <tr>
        <td><meta http-equiv="content-type" content="text/html; charset=windows-874" />
<table width="1000" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="19" background="../newsimages/bg-top-01.jpg"><table width="950" border="0" cellspacing="0" cellpadding="0">
	            
      <tr>
        <td width="100" valign="top">&nbsp;</td>
        <td width="100" valign="top">&nbsp;</td>
        <td width="100" valign="top">&nbsp;</td>
        <td width="100" valign="top">&nbsp;</td>
        <td width="100" valign="top">&nbsp;</td>
        <td width="100" valign="top">&nbsp;</td>
        <td width="116">&nbsp;</td>
        <td width="212" align="right" class="whiteleft"><a href="index.php">
		home</a>&nbsp;|&nbsp;
		<a href="act_login.php">login</a>		
		</td>
        <td width="22">&nbsp;</td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="50" valign="top" background="../newsimages/bg-top-white.gif"><table width="950" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100" valign="top"><a href="../newsagri/news_all.php"><img src="../newsimages/bt-news.gif" width="100" height="45" border="0" /></a></td>
        <td width="100" valign="top"><a href="index.php"><img src="../newsimages/bt-activity.gif" width="100" height="45" border="0" /></a></td>
        <td width="100" valign="top"><a href="../../deantalk/"><img src="../newsimages/bt-deantalk.gif" width="100" height="45" border="0" /></a></td>
        <td width="100" valign="top"><a href="../agri_journal/"><img src="../newsimages/bt-journal.gif" width="100" height="45" border="0" /></a></td>
        <td width="100" valign="top"><a href="../booknews/"><img src="../newsimages/bt-book.gif" width="100" height="45" border="0" /></a></td>
        <td width="100" valign="top"><a href="../agri_report/"><img src="../newsimages/bt-report.gif" width="100" height="45" border="0" /></a></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="119" background="../newsimages/bg-top-02-act.jpg">&nbsp;</td>
  </tr>
</table>
		</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="left" class="gray12blue">
			<img src="../newsimages/blank.gif" width="20" height="10"><img src="../newsimages/icon_gray.gif" width="10" height="10">
			<a href="clip_all.php">ë¹éòëåñ¡</a> &gt;
			çõ´õ·ñè¹ì¡ô¨¡ããá</td>
            <td align="left" valign="top" background="../newsimages/bg-right.jpg">&nbsp;</td>
          </tr>
          <tr>
            <td align="center" valign="top" ><table width="680" border="0" align="center" cellpadding="3" cellspacing="0"  >
              <tr>
                <td>
				<form action="" method="post" name="form1" id="form1">
				<input type="hidden" name="" size = "60" value="">				  <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td height="50" align="left" class="blackh"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td class="orangeh"><img src="../newsimages/icon-blue.gif"> </td>
                            <td width="40" align="right" class="orangeh">
														</td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td height="10" align="left" bgcolor="#f8f8f8" class="gray12bold">&nbsp;</td>
                      </tr>
                      <tr>
                        <td height="50" align="center" bgcolor="#f8f8f8" class="black"><span class="gray12bold"></span></td>
                      </tr>
                      <tr>
                        <td height="30" bgcolor="#f8f8f8" class="gray12bold"><img src="../newsimages/icon-blue.gif" width="7" height="7"> ãòâåðàíõâ´çõõ´õ·ñè¹ì</td>
                      </tr>
                      <tr>
                        <td height="50" align="left" valign="top" bgcolor="#f8f8f8" class="black"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <td height="30" class="black"><img src="../newsimages/blank.gif" width="30" height="10"></td>
                          </tr>
						 <tr>
						   <td height=30 class=black></td>
						   </tr>
                        </table></td>
                      </tr>
                      <tr>
                        <td height="25">&nbsp;	</td>
                      </tr>
                      <tr>
                        <td height="25">&nbsp;</td>
                      </tr>
                    </table>
                </form></td>
              </tr>
            </table></td>
            <td width="304" align="left" valign="top" background="../newsimages/bg-right.jpg"><meta http-equiv="content-type" content="text/html; charset=windows-874" />

<link href="../newscss/styledt.css" rel="stylesheet" type="text/css">
<table width="254" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="50" align="center" background="../newsimages/bg-right-blue.jpg" class="whiteleft">àò¾¡ô¨¡ããá¤³ðà¡éµã ¡óá¾§áê¹</td>
  </tr>
  <tr>
    <td height="20" align="right" class="gray12bold">&nbsp;</td>
  </tr>
  <tr>
    <td height="30" align="left" valign="middle" class="gray12bold" ><table width="95%" border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
        <td height="30" class="gray12bold" style="border-bottom:#e5e5e5 1px solid "><img src="../newsimages/blank.gif" width="30" height="10" /><a href="index.php">àò¾¡ô¨¡ããá</a></td>
      </tr>
      <tr>
        <td height="30" class="gray12bold" style="border-bottom:#e5e5e5 1px solid "><img src="../newsimages/blank.gif" width="30" height="10" /><a href="clip_all.php">çõ´õ·ñè¹ì¡ô¨¡ããá</a></td>
      </tr>

    </table></td>
  </tr>
  <tr>
    <td height="20">&nbsp;</td>
  </tr>
  <tr>
    <td height="30"><img src="../newsimages/blank.gif" width="30" height="10"><a href="http://get.adobe.com/reader/" target="_blank"></a></td>
  </tr>
  <tr>
    <td height="30">&nbsp;</td>
  </tr>
</table>
</td>
          </tr>
          <tr>
            <td align="center" valign="top">&nbsp;</td>
            <td align="left" valign="top" background="../newsimages/bg-right.jpg">&nbsp;</td>
          </tr>
        </table></td>
      </tr>

      <tr>
        <td height="77"><meta http-equiv="content-type" content="text/html; charset=windows-874" />
<table width="1000" height="77" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top" background="../newsimages/bg-bottom.jpg"><table width="100%" border="0" align="center" cellspacing="0">
      <tr>
        <td height="30" align="center" valign="middle" class="black12"><strong>¾ñ²¹òãðººâ´â : ¹.ê.´ç§¡áå ´éç§¨øá¾å  ë¹èçâ¼åôµê×èíáåðà·¤â¹âåâõêòãê¹à·è ¤³ðà¡éµã ¡óá¾§áê¹</strong></td>
      </tr>
      <tr>
        <td width="1000" height="30" align="center" valign="middle" class="black12">
          áëòçô·âòåñâà¡éµãèòêµãì  çô·âòà¢µ¡óá¾§áê¹  í.¡óá¾§áê¹  ¨.¹¤ã»°á 73140</td>
      </tr>
    </table></td>
  </tr>
</table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
