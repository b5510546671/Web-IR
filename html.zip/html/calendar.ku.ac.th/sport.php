<!doctype html public "-//w3c//dtd xhtml 1.0 transitional//en" "http://www.w3.org/tr/xhtml1/dtd/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=windows-874">

<title>สปอตวิทยุ</title>
<style type="text/css">
<!--
.style1 {
	color: #cc9900
}
body {
	background-color: #ffffff;
}
#apdiv1 {
	position:absolute;
	left:337px;
	top:28px;
	width:99px;
	height:88px;
	z-index:1;
}
-->
</style>
</head>

<body>
<div id="apdiv1">
  <div align="center"><span class="style1"><img src="images/logo.png" width="90" height="87" /></span></div>
</div>
<h3 align="center">ประชาสัมพันธ์ความรู้เกี่ยวกับ</h3>
<h3 align="center">ภัยพิบัติทางธรรมชาติ </h3>
<h2 align="center" class="style1">&quot;ภัยพิบัติ รู้ทัน รับมือได้&quot;</h2>
<p align="center" class="style1">สปอตวิทยุ</p>
<div align="center">

      <h4 align="center">ภารกิจสำคัญ</h4>
    <p style="text-align: center;">
	<embed align="absmiddle" autostart="0" embed=" " height="60" loop="1" pluginspage="http://www.microsoft.com/windows/mediaplayer/download/default.asp" src="http://www.ku.ac.th/sport/sport3.mp3" type="application/x-mplayer2" width="450"></embed></p>
      <h4>เตรียมพร้อมรับมือ</h4>
        <p style="text-align: center;">
	<embed align="absmiddle" autostart="0" embed=" " height="60" loop="1" pluginspage="http://www.microsoft.com/windows/mediaplayer/download/default.asp" src="http://www.ku.ac.th/sport/sport2.mp3" type="application/x-mplayer2" width="450"></embed></p>
      <h4>เพื่อนเตือนภัย</h4>
        <p style="text-align: center;">
	<embed align="absmiddle" autostart="0" embed=" " height="60" loop="1" pluginspage="http://www.microsoft.com/windows/mediaplayer/download/default.asp" src="http://www.ku.ac.th/sport/sport1.mp3" type="application/x-mplayer2" width="450"></embed></p>
  </ul>
</div>
</body>

</html>
