<html>
<head><title>ปฏิทินกิจกรรม มก.</title>
<meta http-equiv="content-type" content="text/html; charset=windows-874">
<link href="carlendar.css" rel="stylesheet" type="text/css">
<script language=javascript type=text/javascript>
<!--

function clearsearch() {
        document.formsearch.q.value = '';
}//-->
</script>
<style type="text/css">
<!--
.style1 {
	font-family: "ms sans serif";
	font-size: 14px;
}
body,td,th {
	font-family: ms sans serif;
}
a {
	font-family: ms sans serif;
}
.style3 {font-family: "ms sans serif"}
.style4 {
	font-size: 14px;
	font-family: "ms sans serif";
}
.style8 {font-weight: bold}
.style9 {color: #ffffff}
.style10 {font-family: "ms sans serif"; color: #ffffff; }
.style7 {font-size: 14px}
.style13 {font-size: 14pt}
.style15 {color: #6d4016}
.style16 {
	font-size: 12pt;
	color: #950000;
}
.style17 {color: #ccff00}
.style18 {color: #950000; font-size: 14px;}
-->
</style>



</head>

<body>


<html>
<head>
	<title></title>
	<meta http-equiv="content-type" content="text/html; charset=windows-874">
    <link href="style/default.css" rel="stylesheet" type="text/css">
    <link href="carlendar.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style8 {
	font-family: "ms sans serif";
	font-size: 14px;
	font-weight: bold;
}
.style11 {font-family: "ms sans serif"; font-size: 14px; font-weight: bold; color: #0033ff; }
.style12 {color: #0033ff}
-->
    </style>
</head>
<body topmargin="0" leftmargin="0" >
<table width="800" align="center" cellpadding="0" cellspacing="0">
	<tr valign="bottom" bordercolor="#ffffff"  class="menu">
		<td width="800" height="122" ><div align="right">
		  <table width="100%"   border="0" align="right"  cellpadding="0" cellspacing="0" bordercolor="#ffffff" bgcolor="#ffffff" class="menu">
          <tr width="800"  >
            <td height="50" colspan="5"   valign="top" ><table width="100%" cellpadding="0" cellspacing="0" background="images/calendarku_banner1.jpg" bgcolor="#9acfcb" >
              <tr>
                <td width="800" height="122" colspan="0" bordercolor="#cccccc" ><br>
                  <br>                  </td>
              </tr>
            </table></td>
            </tr>
          <tr bgcolor="#33cc33" width="760"  >
            <td width="422" height="20"   valign="top" bgcolor="#9acbba" >&nbsp;</td>
            <td width="81"  align="center" bgcolor="#9acbba"><a href="http://www.ku.ac.th" class="style1  "><span class="style11">หน้าหลัก</span></a></td>
            <td width="92"  align="center" bgcolor="#9acbba"><a href="index.php" class="style1 "><span class="style11">ปฏิทินวันนี้</span></a></td>
            <td width="97"align="center" bgcolor="#9acbba" ><a href="indexweeks.php" class="style1 "><span class="style11">ปฏิทินสัปดาห์นี้</span></a></td>
            <td width="86" align="center" bgcolor="#9acbba"><a href="indexmonth.php" class="style1 "><span class="style11">ปฏิทินเดือนนี้</span></a></td>
            </tr>
        </table>
	  </div>	</td>
	</tr>
</table>
<table width="800" border="0" align="center" cellpadding="0" cellspacing="0">
  
    <td width="800" height="450" bgcolor="#ffffff" valign="top"><table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0">
      <tr valign="top">
        <td width="5%" rowspan="5" bgcolor="#99cccc">
		  <div align="center" class="style15"><style type="text/css">

#popitmenu{
position: absolute;
background-color: #1758b7;
border:1px solid #f7f7f7;
font: normal 12px ms sans serif;
line-height: 18px;
z-index: 100;
visibility: hidden;
}

#popitmenu a{
text-decoration: none;
padding-left: 6px;
color: white;
display: block;
}

#popitmenu a:hover{ /*hover background color*/
background-color: black;
}

                          </style>
                          <script type="text/javascript">

/***********************************************
* pop-it menu- ? dynamic drive (www.dynamicdrive.com)
* this notice must stay intact for legal use
* visit http://www.dynamicdrive.com/ for full source code
***********************************************/

var defaultmenuwidth="140px" //set default menu width.

var linkset=new array()
//specify menu sets and their links. follow syntax laid out

linkset[0]='<a href="/indexweeks.php?today=28&dfmonth=7&dfyear=2017">คลิกเพื่อเลือกปฏิทินกิจกรรมประจำสัปดาห์ของ<br>เดือนก่อนหน้า</a>'

linkset[1]='<a href="/indexweeks.php?today=28&dfmonth=9&dfyear=2017">คลิกเพื่อเลือกปฏิทินกิจกรรมประจำสัปดาห์ของเดือนถัดไป</a>'

//linkset[1]+='<a href="http://news.bbc.co.uk">bbc news</a>'
//linkset[1]+='<a href="http://www.washingtonpost.com">washington post</a>'

////no need to edit beyond here

var ie5=document.all && !window.opera
var ns6=document.getelementbyid

if (ie5||ns6)
document.write('<div id="popitmenu" onmouseover="clearhidemenu();" onmouseout="dynamichide(event)"></div>')

function iecompattest(){
return (document.compatmode && document.compatmode.indexof("css")!=-1)? document.documentelement : document.body
}

function showmenu(e, which, optwidth){
if (!document.all&&!document.getelementbyid)
return
clearhidemenu()
menuobj=ie5? document.all.popitmenu : document.getelementbyid("popitmenu")
menuobj.innerhtml=which
menuobj.style.width=(typeof optwidth!="undefined")? optwidth : defaultmenuwidth
menuobj.contentwidth=menuobj.offsetwidth
menuobj.contentheight=menuobj.offsetheight
eventx=ie5? event.clientx : e.clientx
eventy=ie5? event.clienty : e.clienty
//find out how close the mouse is to the corner of the window
var rightedge=ie5? iecompattest().clientwidth-eventx : window.innerwidth-eventx
var bottomedge=ie5? iecompattest().clientheight-eventy : window.innerheight-eventy
//if the horizontal distance isn't enough to accomodate the width of the context menu
if (rightedge<menuobj.contentwidth)
//move the horizontal position of the menu to the left by it's width
menuobj.style.left=ie5? iecompattest().scrollleft+eventx-menuobj.contentwidth+"px" : window.pagexoffset+eventx-menuobj.contentwidth+"px"
else
//position the horizontal position of the menu where the mouse was clicked
menuobj.style.left=ie5? iecompattest().scrollleft+eventx+"px" : window.pagexoffset+eventx+"px"
//same concept with the vertical position
if (bottomedge<menuobj.contentheight)
menuobj.style.top=ie5? iecompattest().scrolltop+eventy-menuobj.contentheight+"px" : window.pageyoffset+eventy-menuobj.contentheight+"px"
else
menuobj.style.top=ie5? iecompattest().scrolltop+event.clienty+"px" : window.pageyoffset+eventy+"px"
menuobj.style.visibility="visible"
return false
}

function contains_ns6(a, b) {
//determines if 1 element in contained in another- by brainjar.com
while (b.parentnode)
if ((b = b.parentnode) == a)
return true;
return false;
}

function hidemenu(){
if (window.menuobj)
menuobj.style.visibility="hidden"
}

function dynamichide(e){
if (ie5&&!menuobj.contains(e.toelement))
hidemenu()
else if (ns6&&e.currenttarget!= e.relatedtarget&& !contains_ns6(e.currenttarget, e.relatedtarget))
hidemenu()
}

function delayhidemenu(){
delayhide=settimeout("hidemenu()",500)
}

function clearhidemenu(){
if (window.delayhide)
cleartimeout(delayhide)
}

if (ie5||ns6)
document.onclick=hidemenu

                          </script>
		    <br>
              <br>
          </div></td>
        <td width="74%" rowspan="4" valign="top"><span class="style15">
                                  </span>
          <table width="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#fafafa">
              <tr>
                <td height="22" bgcolor="#ffffff" class="style15">
                  <table width="100%" border="0" align="left" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                    <tr>
                      <td  align="left" valign="top" bgcolor="#66cccc"><b><span class="style16">ปฏิทินกิจกรรม ประจำสัปดาห์ที่ 35  พ.ศ. 2560
</span> </b></td>
                    </tr>
                </table></td>
              </tr>
              <tr>
                <td height="12" class="style15"><img width="400" height="1"></td>
              </tr>
                            <tr>
                <td height="118" class="style15">			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				12 กรกฎาคม พ.ศ. 2560 ถึง 31 สิงหาคม พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--0-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   สำนักบริการคอมพิวเตอร์ รับสมัครพนักงานมหาวิทยาลัยเงินงบประมาณ ตำแหน่ง วิศวกร</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        08:30-16:30 น.                                       </span></td>
                                      <td width="79%" class="style4">สำนักบริการคอมพิวเตอร์  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/job-12-07-60.pdf"  target = "_blank">job-12-07-60.pdf</a><a href = "" target =" _blank"></a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				20 กรกฎาคม พ.ศ. 2560 ถึง 30 สิงหาคม พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--1-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   รับสมัครคัดเลือกเพื่อจ้างและแต่งตั้งบุคคลเข้าเป็็นพนักงานมหาวิทยาลัย ตำแหน่งวิศวกรไฟฟ้า</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        08:30-16:30 น.                                       </span></td>
                                      <td width="79%" class="style4">สถาบันค้นคว้าและพัฒนาผลิตผลทางการเกษตรฯ  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/"  target = "_blank"></a><a href = "www.kapi.ku.ac.th" target =" _blank">www.kapi.ku.ac.th</a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				01 สิงหาคม พ.ศ. 2560 ถึง 31 สิงหาคม พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--2-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   รับสมัครบุคคลเพื่อคัดเลือกเป็นพนักงานมหาวิทยาลัย ตำแหน่งอาจารย์ จำนวน 2 อัตรา</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        08:30-16:30 น.                                       </span></td>
                                      <td width="79%" class="style4">ภาควิชาส่งเสริมและนิเทศศาสตร์เกษตร คณะเกษตร  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/jobaa.pdf"  target = "_blank">jobaa.pdf</a><a href = "" target =" _blank"></a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            <tr>
                        <td><!--2-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   ประกาศสำนักการกีฬา เรื่อง รับสมัครตำแหน่งช่างไฟฟ้า</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        09:00-15:30 น.                                       </span></td>
                                      <td width="79%" class="style4">  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/job60-07-01.pdf"  target = "_blank">job60-07-01.pdf</a><a href = "" target =" _blank"></a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				04 สิงหาคม พ.ศ. 2560 ถึง 31 สิงหาคม พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--3-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   รับสมัครบุคคลเพื่อคัดเลือกบรรจุเป็นพนักงานมหาวิทยาลัยเงินรายได้</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        09:00-16:00 น.                                       </span></td>
                                      <td width="79%" class="style4">คณะวนศาสตร์  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/"  target = "_blank"></a><a href = "http://www.forest.ku.ac.th/webdev3" target =" _blank">http://www.forest.ku.ac.th/webdev3</a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				04 สิงหาคม พ.ศ. 2560 ถึง 01 กันยายน พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--4-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   ประกาศคณะเทคนิคการสัตวแพทย์ เรื่องรับสมัครลูกจ้างโครงการตำแหน่งนักวิทยาศาสตร์ จำนวน 2 อัตรา</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        ไม่ระบุเวลา                                      </span></td>
                                      <td width="79%" class="style4">  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/"  target = "_blank"></a><a href = "http://anatomy.vet.ku.ac.th/vtku/inews/photo/1284.pdf" target =" _blank">http://anatomy.vet.ku.ac.th/vtku/inews/photo/1284.pdf</a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				07 สิงหาคม พ.ศ. 2560 ถึง 31 สิงหาคม พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--5-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   คณะมนุษยศาสตร์ มก. รับสมัครพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่ง เจ้าหน้าที่บริหารงานทั่วไป สังกัดภาควิชาภาษาต่างประเทศ จำนวน 1 อัตรา</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        08:30-16:00 น.                                       </span></td>
                                      <td width="79%" class="style4">  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/human_recruit_adminofficeforeignlang60.pdf"  target = "_blank">human_recruit_adminofficeforeignlang60.pdf</a><a href = "" target =" _blank"></a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				07 สิงหาคม พ.ศ. 2560 ถึง 02 กันยายน พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--6-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   ประกาศคณะเทคนิคการสัตวแพทย์ เรื่องรับสมัครพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่งนักวิทยาศาสตร์ จำนวน 1 อัตรา</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        ไม่ระบุเวลา                                      </span></td>
                                      <td width="79%" class="style4">  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/"  target = "_blank"></a><a href = "http://anatomy.vet.ku.ac.th/vtku/inews/view.php?id_view=1285" target =" _blank">http://anatomy.vet.ku.ac.th/vtku/inews/view.php?id_view=1285</a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				08 สิงหาคม พ.ศ. 2560 ถึง 30 สิงหาคม พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--7-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   คณะอุตสาหกรรมเกษตร ขอประกาศรายชื่อผู้มีสิทธิเข้ารับการสอบข้อเขียน พนักงานมหาวิทยาลัยเงินงบประมาณ ตำแหน่งเจ้าหน้าที่บริหารงานทั่วไป ระดับปฏิบัติการ</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        ไม่ระบุเวลา                                      </span></td>
                                      <td width="79%" class="style4">สำนักงานเลขานุการ คณะอุตสาหกรรมเกษตร  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/oos0014.pdf"  target = "_blank">oos0014.pdf</a><a href = "" target =" _blank"></a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				08 สิงหาคม พ.ศ. 2560 ถึง 31 สิงหาคม พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--8-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   คณะวิศวกรรมศาสตร์  รับสมัคร นักวิเคราะห์นโยบายและแผน 1 อัตรา / ผู้ปฏิบัติงานบริหาร 1 อัตรา</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        09:00-16:30 น.                                       </span></td>
                                      <td width="79%" class="style4">  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/analysis for web.pdf"  target = "_blank">analysis for web.pdf</a><a href = "" target =" _blank"></a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				09 สิงหาคม พ.ศ. 2560 ถึง 01 กันยายน พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--9-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   คณะสัตวแพทยศาสตร์รับสมัครพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่งเจ้าหน้าที่บริหารงานทั่วไป จำนวน 1 อัตรา</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        09:00-15:00 น.                                       </span></td>
                                      <td width="79%" class="style4">คณะสัตวแพมยศาสตร์  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/ijmtzg0lc4hs.pdf"  target = "_blank">ijmtzg0lc4hs.pdf</a><a href = "" target =" _blank"></a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				16 สิงหาคม พ.ศ. 2560 ถึง 28 สิงหาคม พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--10-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   รับสมัครเข้ารับการสรรหาผู้สำนักทะเบียนและประมวลผล</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        08:30-16:30 น.                                       </span></td>
                                      <td width="79%" class="style4">  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/"  target = "_blank"></a><a href = "http://www.person.ku.ac.th/" target =" _blank">http://www.person.ku.ac.th/</a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				16 สิงหาคม พ.ศ. 2560 ถึง 31 สิงหาคม พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--11-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   สำนักงานประกันคุณภาพประกาศผลการคัดเลือกพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่งนักวิชาการคอมพิวเตอร์</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        ไม่ระบุเวลา                                      </span></td>
                                      <td width="79%" class="style4">  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/job notice 1.2560.pdf"  target = "_blank">job notice 1.2560.pdf</a><a href = "" target =" _blank"></a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				22 สิงหาคม พ.ศ. 2560 ถึง 01 กันยายน พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--12-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   คณะสัตวแพทยศาสตร์ประกาศเรียกสำรองเพื่อเข้าปฏิบัติงานเป็นลูกจ้างชั่วคราวโครงการร้านค้าเกษตรเพ็ทช็อพ ตำแหน่งพนักงานขายสินค้า จำนวน 3 อัตรา และตำแหน่งพนักงานบัญชี จำนวน 1 อัตรา</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        08:30-00:00 น.                                       </span></td>
                                      <td width="79%" class="style4">คณะสัตวแพมยศาสตร์  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/pezmzt0mlva8.pdf"  target = "_blank">pezmzt0mlva8.pdf</a><a href = "" target =" _blank"></a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				25 สิงหาคม พ.ศ. 2560 ถึง 31 สิงหาคม พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--13-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   คณะมนุษยศาสตร์ มก. ประกาศรายชื่อผู้สอบผ่านการคัดเลือกเป็นพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่ง เจ้าหน้าที่บริหารงานทั่วไป สังกัดภาควิชาภาษาตะวันออก</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        09:00-16:00 น.                                       </span></td>
                                      <td width="79%" class="style4">  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/eastlang_listnameadminoffice60.pdf"  target = "_blank">eastlang_listnameadminoffice60.pdf</a><a href = "" target =" _blank"></a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				25 สิงหาคม พ.ศ. 2560 ถึง 01 กันยายน พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--14-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   สำนักบริการคอมพิวเตอร์ ประกาศผลการคัดเลือก พนักงานมหาวิทยาลัยเงินรายได้</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        08:30-16:00 น.                                       </span></td>
                                      <td width="79%" class="style4">สำนักบริการคอมพิวเตอร์  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/job_ocs_25_8_60.pdf"  target = "_blank">job_ocs_25_8_60.pdf</a><a href = "" target =" _blank"></a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                            			
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>
                          <div align="left">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                <td  align="left" valign="top" bgcolor="#97ecec"><div align="left"><strong>วันที่</strong><b>
				31 สิงหาคม พ.ศ. 2560 
             </b></div></td>
                </tr>
                            </table>

							
                        </div></td>
                      </tr>
                                            <tr>
                        <td><!--15-->
                            <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                              <tr>
                                <td align="left" valign="middle" bgcolor="#fafafa"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td colspan="2"><span class="style4">
                                  <b>   รายชื่อผู้มีสิทธิสอบคัดเลือกเพื่อจ้างเป็นพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่งนักวิชาการและบัญชี</b>   
                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td width="21%" valign="top"><span class="style4">
                                        09:00-15:30 น.                                       </span></td>
                                      <td width="79%" class="style4">ห้องประชุม 6 ชั้น 2 อาคารสารนิเทศ50ปี  </td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><span class="style4">
                                        <a href = "file/job_finance 28082560.pdf"  target = "_blank">job_finance 28082560.pdf</a><a href = "" target =" _blank"></a>                                      </span></td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top"><img width="400" height="1"></td>
                                    </tr>
                                </table></td>
                              </tr>
                          </table></td>
                      </tr>
                                                              </table></td>
              </tr>
                        </table></td>
        <td width="21%" rowspan="5" bgcolor="#99cccc"><a href="/indexweeks.php?today=28&dfmonth=9&dfyear=2017">
          </a>
             <table width="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td valign="top"> <!--<script language="javascript">

		function clearsearch(theform) {
        document.formsearch.q.value = '';
		
}

</script>-->
<script language="javascript">

<!--

       function validateinfo3 (theform8)
       {
                if (theform8.q.value =="")
                {
                  alert ("กรุณาป้อน  \"คำที่ต้องการค้นหา\" ");
                  theform8.q .focus();
                  return (false);
                 }
                 return (true);
      }   
//-->
</script>
<form  action="indexfoundword.php" method="post"  onsubmit="return validateinfo3(this)" name= "formsearch">
<!--<input type=text onclick="clearsearch();"  size=20 maxlength=255 value="??????????????" name=q>    
<input  type="text" onclick="clearsearch();" size=15 maxlength=255   name=q>  -->
<div align="left">
  <input   name=q  type="text" onclick="validateinfo3 ();" size=20 maxlength=225>  
  <input name="submit" type="submit" value="ค้นหา">
  <input type=hidden name=ie value=windows-874>
 <!--     <input type=hidden name=domains value="http://calendar.ku.ac.th/">
	   <input type=hidden name=sitesearch value="http://calendar.ku.ac.th/">-->
</div>
</form> 
<div align="center"><span class="style18">  ปฏิทินกิจกรรม<strong>รายสัปดาห์</strong><br>
  สามารถเลือกดูสัปดาห์<br>
  ที่ต้องการได้จากปฏิทิน</span>
                  
                </div></td>
              </tr>
              <tr>
                <td><table border="0" bordercolor="black" width="170" class="sample">
                  <tr bgcolor="#c5f5c5" class="norm">
                    <td width="24" height="23" align="center" valign="bottom"  bgcolor='#66cccc'> <a href="/indexweeks.php?today=28&dfmonth=7&dfyear=2017" onmouseover="showmenu(event,linkset[0])" onmouseout="delayhidemenu()"><img src="images/ar_l.gif" width="16" height="15" border="0"></a> </td>
                    <td width="120" height="23" colspan="5" align="center" bgcolor='#66cccc'> สิงหาคม&nbsp; 2560 </td>
                    <td width="24" height="23" align="center" valign="bottom" bgcolor='#66cccc'> <a href="/indexweeks.php?today=28&dfmonth=9&dfyear=2017" onmouseover="showmenu(event,linkset[1])" onmouseout="delayhidemenu()"><img src="images/ar_r.gif" width="16" height="15" border="0"></a></td>
                  <tr>
                  <tr>
                    <td width="24" align="center" class="sunday">อา</td>
                    <td width="24" align="center" class="norm">จ</td>
                    <td width="24" align="center" class="norm">อ</td>
                    <td width="24" align="center" class="norm">พ</td>
                    <td width="24" align="center" class="norm">พฤ</td>
                    <td width="24" align="center" class="norm">ศ</td>
                    <td width="24" align="center" class="norm">ส</td>
                  </tr>
                  <td width="24" align="center" class="sunday">&nbsp;</td>
<td width="24" align="center" class="norm">&nbsp;</td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=1&dfmonth=8&dfyear=2017>1</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=2&dfmonth=8&dfyear=2017>2</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=3&dfmonth=8&dfyear=2017>3</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=4&dfmonth=8&dfyear=2017>4</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=5&dfmonth=8&dfyear=2017>5</a></td>
<tr>
<td width="24" align="center" class="sunday"><a href=/indexweeks.php?today=6&dfmonth=8&dfyear=2017>6</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=7&dfmonth=8&dfyear=2017>7</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=8&dfmonth=8&dfyear=2017>8</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=9&dfmonth=8&dfyear=2017>9</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=10&dfmonth=8&dfyear=2017>10</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=11&dfmonth=8&dfyear=2017>11</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=12&dfmonth=8&dfyear=2017>12</a></td>
</tr>
<tr>
<td width="24" align="center" class="sunday"><a href=/indexweeks.php?today=13&dfmonth=8&dfyear=2017>13</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=14&dfmonth=8&dfyear=2017>14</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=15&dfmonth=8&dfyear=2017>15</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=16&dfmonth=8&dfyear=2017>16</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=17&dfmonth=8&dfyear=2017>17</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=18&dfmonth=8&dfyear=2017>18</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=19&dfmonth=8&dfyear=2017>19</a></td>
</tr>
<tr>
<td width="24" align="center" class="sunday"><a href=/indexweeks.php?today=20&dfmonth=8&dfyear=2017>20</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=21&dfmonth=8&dfyear=2017>21</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=22&dfmonth=8&dfyear=2017>22</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=23&dfmonth=8&dfyear=2017>23</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=24&dfmonth=8&dfyear=2017>24</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=25&dfmonth=8&dfyear=2017>25</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=26&dfmonth=8&dfyear=2017>26</a></td>
</tr>
<tr>
<td width="24" align="center" class="sunday"><a href=/indexweeks.php?today=27&dfmonth=8&dfyear=2017>27</a></td>
<td width="24" align="center" class="today"><a href=/indexweeks.php?today=28&dfmonth=8&dfyear=2017>28</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=29&dfmonth=8&dfyear=2017>29</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=30&dfmonth=8&dfyear=2017>30</a></td>
<td width="24" align="center" class="norm"><a href=/indexweeks.php?today=31&dfmonth=8&dfyear=2017>31</a></td>
<td width="24" align="center" class="norm">&nbsp;</td>
<td width="24" align="center" class="norm">&nbsp;</td>
</tr>
                </table></td>
              </tr>
            </table>
            </a>
			
<style type="text/css">
<!--
.style1 {
	color: #ece9d8;
	font-weight: bold;
}
.style6 {font-size: 14px; font-family: "ms sans serif"; color: #666666; }
.style7 {color: #000000}
.style8 {font-size: 10px}
-->
</style>
<script language="javascript">

<!--

       function validateinfo1 (theform4)
       {
                if (theform4.select_month.value =="")
                {
                  alert ("กรุณาเลือก \"เดือน\" ");
                // theform1.select_month .focus();
                  return (false);
                 }
				    if (theform4.select_year.value =="")
                {
                  alert ("กรุณาเลือก\"ปี\" ");
                //  theform1.category.focus();
                  return (false);
                 }
                if (theform4.category.value =="")
                {
                  alert ("กรุณาเลือก\"ประเภทข่าว\" ");
                //  theform1.category.focus();
                  return (false);
                 }
                 return (true);
      }   
//-->
</script>
<form action = "indexfoundnews2.php" method = "post" onsubmit="return validateinfo1(this)" name= "formsearch">
<!--<form  action="indexfoundnews.php" id="select3" name=formsearch>  -->
<!--<input type=text onclick="clearsearch();"  size=20 maxlength=255 value="??????????????" name=q>    -->

  <div align="left">
    <select name="select_month"  id="select1">
      <option>ข่าวกิจกรรมเดือน</option>
      <option value="-01-01">มกราคม</option>
      <option value="-02-01">กุมภาพันธ์</option>
      <option value="-03-01">มีนาคม</option>
      <option value="-04-01">เมษายน</option>
      <option value="-05-01">พฤษภาคม</option>
      <option value="-06-01">มิถุนายน</option>
      <option value="-07-01">กรกฎาคม</option>
      <option value="-08-01">สิงหาคม</option>
      <option value="-09-01">กันยายน</option>
      <option value="-10-01">ตุลาคม</option>
      <option value="-11-01">พฤศจิกายน</option>
      <option value="-12-01">ธันวาคม</option>
    </select>
    <select name="select_year" id="select"><br /><br />
	 <option value="2017">2560</option>
    <option value="2016">2559</option>
     <option value="2015">2558</option>
     <option value="2014">2557</option> 
     <option value="2013">2556</option>
     <option value="2012">2555</option>
     <option value="2011">2554</option>
	 <option value="2010">2553</option>
	  <option value="2009">2552</option>
      <option value="2008">2551</option>
	  <option value="2007">2550</option>
      <option value="2006">2549</option>
      <option value="2005">2548</option>
    </select>
    <br>
    <select name="category" id="select2">
      <option>เลือกประเภทข่าว/กิจกรรม</option>
      <option value="ทุนวิจัย">ทุนวิจัย</option>
      <option value="ทุนการศึกษา">ทุนการศึกษา</option>
      <option value="ศึกษาต่อ">ศึกษาต่อ</option>
      <option value="ประกาศผลสอบ">ประกาศผลสอบ</option>
      <option value="ฝึกอบรม">ฝึกอบรม</option>
      <option value="สัมมนา">สัมมนา</option>
      <option value="ประชุม">ประชุม</option>
      <option value="ประชุมวิชาการ">ประชุมวิชาการ</option>
	  <option value="บรรยายพิเศษ">บรรยายพิเศษ</option>
      <option value="รับสมัครงานในมหาวิทยาลัย">รับสมัครงานในมหาวิทยาลัย</option>
      <option value="สมัครงานภายนอก">สมัครงานภายนอก</option>
      <option value="ประกาศผลสมัครงาน">ประกาศผลสมัครงาน</option>
      <option value="กิจกรรมนิสิต">กิจกรรมนิสิต</option>
      <option value="โครงการกิจกรรม">โครงการกิจกรรม</option>
      <option value="นิทรรศการ">นิทรรศการ</option>
      <option value="ประกวด/แข่งขัน">ประกวด/แข่งขัน</option>
      <option value="กีฬา">กีฬา</option>
      <option value="ศาสนาและศิลปวัฒนธรรม">ศาสนาและศิลปวัฒนธรรม</option>
      <option value="กิจกรรมครบรอบวันสำคัญ">กิจกรรมครบรอบวันสำคัญ</option>
      <option value="สินค้าและบริการ">สินค้าและบริการ</option>
      <option value="วาระผู้บริหาร">วาระผู้บริหาร</option>
      <option value="จัดซื้อ/จัดจ้าง">จัดซื้อ/จัดจ้าง</option>
      <option value="ข้อมูลน่าสนใจ">ข้อมูลน่าสนใจ</option>
      <option value="ประกาศทั่วไปของหน่วยงาน">ประกาศทั่วไปของหน่วยงาน</option>
      <option value="อื่น ๆ">อื่น ๆ</option>
    </select>
 
    <input name="submit" type="submit" value="ค้นหาข่าว" style="border-style: solid 2 px;border-color:  #ffcc33 #ff0033 #ff0033 #ffcc33;background-color: #ff3366;color: #fff" >
    <input type=hidden name=ie value=windows-874>
    <!--  <input type=hidden name=domains value="http://calendar.ku.ac.th/">
       <input type=hidden name=sitesearch value="http://calendar.ku.ac.th/">-->
  </div>
</form> 
            <br>
            <table width="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td><div align="center"><span class="style7 style8"><img src="../images/_banners/calendar_pic.gif" width="32" height="32"></span></div></td>
              </tr>
              <tr>
                <td><div align="center"><span class="style7 style8"><a href="manual.pdf">คู่มือการใช้งาน <br>
        ระบบปฏิทินกิจกรรม มก</a>. </span></div></td>
              </tr>
              <tr>
                <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td><a href="http://calendar.ku.ac.th/accountable.php" class="style7">
                        <li>ตรวจสอบรายชื่อผู้แทนหน่วยงาน </li>
                      </a> </td>
                    </tr>
                    <tr>
                      <td><div align="left"><a href="form_calendar.doc" class="style7">
                          <li>ดาวน์โหลดแบบฟอร์มแจ้งชื่อ<br>
                บัญชีเครือข่ายผู้รับผิดชอบการ<br>
                ประชาสัมพันธ์ข่าวสารผ่านเว็บ </li>
                      </a> </div></td>
                    </tr>
                </table></td>
              </tr>
            </table>
            <br>
            
       
    <br>
        <br>        </td>
      </tr>
      <tr valign="top">
        
      </tr>
 
      <tr valign="top">        </tr>
      <tr valign="top" bgcolor="#339966">
        
      </tr>
    </table></td>
  </tr>

</table>


<table width="800" height="146" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="132" bgcolor="#3dcf89"><div align="center"><span class="style17 style8 style3 style1"><b><br>
            <span class="style13 style3 style9">มหาวิทยาลัยเกษตรศาสตร์</span></b> <span class="style10">&nbsp;</span>
              <span class="style9">
              <!--begin web stat code-->
              <!-- end webstat code -->
              </span></span><span class="style4"><br>
        <b>เลขที่ 50 ถนนพหลโยธิน แขวงลาดยาว เขตจตุจักร กรุงเทพฯ 10900<br>
        </b><br>
        โทรศัพท์ 0-2579-0113 , 0-2942-8500-11<br>
        โทรสาร 0-2942-8988<br>
        <a 
      href="mailto:www@ku.ac.th">ติดต่อผู้ดูแลระบบ</a><br>
        ปรับปรุงล่าสุด :
        <!-- #begindate format:am1 -->february 23, 2008<!-- #enddate -->
        <br>
        <br>
    </span></div></td>
  </tr>
</table>
</body></html>
