<html>
<head><title>ปฏิทินกิจกรรม มก.</title>
<meta http-equiv="content-type" content="text/html; charset=windows-874">
<link href="carlendar.css" rel="stylesheet" type="text/css">
<script language=javascript type=text/javascript>
<!--

function clearsearch() {
        document.formsearch.q.value = '';
}
//-->
</script>
<style type="text/css">
<!--
.style1 {
	font-family: "ms sans serif";
	font-size: 14px;
}
body,td,th {
	font-family: ms sans serif;
}
a {
	font-family: ms sans serif, tahoma, sans-serif;
}
.style3 {font-family: "ms sans serif"}
.style4 {
	font-size: 14px;
	font-family: "ms sans serif";
}
.style7 {font-size: 14px}
.style8 {font-weight: bold}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style13 {color: #ffffff}
.style15 {font-size: 14px; color: #003399; }
.style16 {color: #336699}
.style18 {	color: #ff0000;
	font-weight: bold;
}
.style11 {color: #0000ff; font-size: 14px;}
-->
</style>



</head>

<body>
 <html>
<head>
	<title></title>
	<meta http-equiv="content-type" content="text/html; charset=windows-874">
    <link href="style/default.css" rel="stylesheet" type="text/css">
    <link href="carlendar.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style8 {
	font-family: "ms sans serif";
	font-size: 14px;
	font-weight: bold;
}
.style11 {font-family: "ms sans serif"; font-size: 14px; font-weight: bold; color: #0033ff; }
.style12 {color: #0033ff}
-->
    </style>
</head>
<body topmargin="0" leftmargin="0" >
<table width="800" align="center" cellpadding="0" cellspacing="0">
	<tr valign="bottom" bordercolor="#ffffff"  class="menu">
		<td width="800" height="122" ><div align="right">
		  <table width="100%"   border="0" align="right"  cellpadding="0" cellspacing="0" bordercolor="#ffffff" bgcolor="#ffffff" class="menu">
          <tr width="800"  >
            <td height="50" colspan="5"   valign="top" ><table width="100%" cellpadding="0" cellspacing="0" background="images/calendarku_banner1.jpg" bgcolor="#9acfcb" >
              <tr>
                <td width="800" height="122" colspan="0" bordercolor="#cccccc" ><br>
                  <br>                  </td>
              </tr>
            </table></td>
            </tr>
          <tr bgcolor="#33cc33" width="760"  >
            <td width="422" height="20"   valign="top" bgcolor="#9acbba" >&nbsp;</td>
            <td width="81"  align="center" bgcolor="#9acbba"><a href="http://www.ku.ac.th" class="style1  "><span class="style11">หน้าหลัก</span></a></td>
            <td width="92"  align="center" bgcolor="#9acbba"><a href="index.php" class="style1 "><span class="style11">ปฏิทินวันนี้</span></a></td>
            <td width="97"align="center" bgcolor="#9acbba" ><a href="indexweeks.php" class="style1 "><span class="style11">ปฏิทินสัปดาห์นี้</span></a></td>
            <td width="86" align="center" bgcolor="#9acbba"><a href="indexmonth.php" class="style1 "><span class="style11">ปฏิทินเดือนนี้</span></a></td>
            </tr>
        </table>
	  </div>	</td>
	</tr>
</table>
<table width="800" border="0" align="center" cellpadding="0" cellspacing="0">
  
    <td width="800" height="424" bgcolor="#ffffff" valign="top"><table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0">
      <tr valign="top">
        <td width="24%" height="100%" rowspan="5" valign="top" bgcolor="#99cccc">		  <div align="center"><style type="text/css">

#popitmenu{
position: absolute;
background-color: #1758b7;
border:1px solid #f7f7f7;
font: normal 12px ms sans serif;
line-height: 18px;
z-index: 100;
visibility: hidden;
}

#popitmenu a{
text-decoration: none;
padding-left: 6px;
color: white;
display: block;
}

#popitmenu a:hover{ /*hover background color*/
background-color: black;
}

                          </style>
                          <script type="text/javascript">

/***********************************************
* pop-it menu- ? dynamic drive (www.dynamicdrive.com)
* this notice must stay intact for legal use
* visit http://www.dynamicdrive.com/ for full source code
***********************************************/

var defaultmenuwidth="140px" //set default menu width.

var linkset=new array()
//specify menu sets and their links. follow syntax laid out

linkset[0]='<a href="/indexshotnews.php?today=28&dfmonth=7&dfyear=2017">คลิกเพื่อเลือกปฏิทินกิจกรรมประจำเดือนก่อนหน้า</a>'

linkset[1]='<a href="/indexshotnews.php?today=28&dfmonth=9&dfyear=2017">คลิกเพื่อเลือกปฏิทินกิจกรรมประจำเดือนถัดไป</a>'

//linkset[1]+='<a href="http://news.bbc.co.uk">bbc news</a>'
//linkset[1]+='<a href="http://www.washingtonpost.com">washington post</a>'

////no need to edit beyond here

var ie5=document.all && !window.opera
var ns6=document.getelementbyid

if (ie5||ns6)
document.write('<div id="popitmenu" onmouseover="clearhidemenu();" onmouseout="dynamichide(event)"></div>')

function iecompattest(){
return (document.compatmode && document.compatmode.indexof("css")!=-1)? document.documentelement : document.body
}

function showmenu(e, which, optwidth){
if (!document.all&&!document.getelementbyid)
return
clearhidemenu()
menuobj=ie5? document.all.popitmenu : document.getelementbyid("popitmenu")
menuobj.innerhtml=which
menuobj.style.width=(typeof optwidth!="undefined")? optwidth : defaultmenuwidth
menuobj.contentwidth=menuobj.offsetwidth
menuobj.contentheight=menuobj.offsetheight
eventx=ie5? event.clientx : e.clientx
eventy=ie5? event.clienty : e.clienty
//find out how close the mouse is to the corner of the window
var rightedge=ie5? iecompattest().clientwidth-eventx : window.innerwidth-eventx
var bottomedge=ie5? iecompattest().clientheight-eventy : window.innerheight-eventy
//if the horizontal distance isn't enough to accomodate the width of the context menu
if (rightedge<menuobj.contentwidth)
//move the horizontal position of the menu to the left by it's width
menuobj.style.left=ie5? iecompattest().scrollleft+eventx-menuobj.contentwidth+"px" : window.pagexoffset+eventx-menuobj.contentwidth+"px"
else
//position the horizontal position of the menu where the mouse was clicked
menuobj.style.left=ie5? iecompattest().scrollleft+eventx+"px" : window.pagexoffset+eventx+"px"
//same concept with the vertical position
if (bottomedge<menuobj.contentheight)
menuobj.style.top=ie5? iecompattest().scrolltop+eventy-menuobj.contentheight+"px" : window.pageyoffset+eventy-menuobj.contentheight+"px"
else
menuobj.style.top=ie5? iecompattest().scrolltop+event.clienty+"px" : window.pageyoffset+eventy+"px"
menuobj.style.visibility="visible"
return false
}

function contains_ns6(a, b) {
//determines if 1 element in contained in another- by brainjar.com
while (b.parentnode)
if ((b = b.parentnode) == a)
return true;
return false;
}

function hidemenu(){
if (window.menuobj)
menuobj.style.visibility="hidden"
}

function dynamichide(e){
if (ie5&&!menuobj.contains(e.toelement))
hidemenu()
else if (ns6&&e.currenttarget!= e.relatedtarget&& !contains_ns6(e.currenttarget, e.relatedtarget))
hidemenu()
}

function delayhidemenu(){
delayhide=settimeout("hidemenu()",500)
}

function clearhidemenu(){
if (window.delayhide)
cleartimeout(delayhide)
}

if (ie5||ns6)
document.onclick=hidemenu

                          </script>
		   
		                <style type="text/css">
<!--
.style1 {
	color: #ece9d8;
	font-weight: bold;
}
.style6 {font-size: 14px; font-family: "ms sans serif"; color: #666666; }
.style7 {color: #000000}
.style8 {font-size: 10px}
-->
</style>
<script language="javascript">

<!--

       function validateinfo (theform9)
       {
                if (theform9.username.value =="")
                {
                  alert ("กรุณาป้อน  \"username\" ");
                  theform9.username .focus();
                  return (false);
                 }
                if (theform9.password.value =="")
                {
                  alert ("กรุณาป้อน \"password\" ");
                  theform9.password.focus();
                  return (false);
                 }
                 return (true);
      }   
//-->
</script>
<body onload = "document.formlogin.username.focus();">
<!--<form name="portallogin" action="portallogin.php" method="post" target="_top" onsubmit="return validateinfo(this)">-->
<form action = "http://calendar.ku.ac.th/login.php" method = "post" onsubmit="return validateinfo(this)" name= "formlogin">
<!--<form action="welcome.php" method="post">-->
<!--<form action = "http://calendar.ku.ac.th/login.php" method = "post" name = "formlogin" target="_top">-->
<table width="145" height="109" border="1" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="159" height="107"><table width="70%" height="105" align="center" cellpadding="0" cellspacing="0">
          <tr bgcolor="#33cc99">
            <td colspan="2"><div align="center" class="style1">
              <div align="left" class="style7">
                <div align="center">สำหรับเจ้าหน้าที่</div>
              </div>
            </div></td>
          </tr>
          <tr bgcolor="#f2f2f2">
            <td width="57"><span class="style6"> <span class="style8">username</span> : </span></td>
            <td width="99"><input name="username" type="text" id="username" size="15"></td>
          </tr>
          <tr bgcolor="#f2f2f2">
            <td><span class="style6"> <span class="style8">password </span>: </span></td>
            <td><input name="password" type="password" id="password" size="15"></td>
          </tr>
        </table>
        <div align="center"></div></td>
      </tr>
  </table>
	
	<div align="center">
	
	
	  <input name="submit" type="submit" value="log in">

<input name="submit1" type="reset" value="clear">
</div>
</form>
	<hr>
	<table width="100%"  border="0" cellpadding="0" cellspacing="0">

      <tr>
        <td><table width="100%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#99ccff">
      <tr>
        <td><table width="100%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#99ccff">
          <tr>
            <td bgcolor="#0066cc"><div align="center"><span class="style19 style13">เว็บไซด์แนะนำ</span></div></td>
          </tr>
        </table></td>
      </tr>
    </table>
	</td>
      </tr>
    </table>
       <div align="center">
         <div align="center"><a href="http://www.thaiornamentalplant.org/"><img src="images/smp.jpg" alt="สมาคมไม้ประดับแห่งประเทศไทย" width="137" height="93" border="1"></a><br>
             <a href="http://www.cit.uni.net.th/"><br>
             </a><a href="http://www.cit.uni.net.th/"></a>
             <hr align="center">
             <a href="http://www.chinavut.com/eng/contest/razr_iboard.php"></a>
             <!--      <div class="style15">
	        <a href="http://peebthonggame.sut.ac.th"><img src="images/banner_peepthong.jpg" width="137" height="69" border="0"><br>
	        </a>
	        <hr align="center">  -->
             <a href="images/aw-easyflyer.jpg"></a><a href="http://library.senate.go.th/"><img src="images/library.gif" alt="ระบบห้องสมุดอิเล็กทรอนิกส์วุฒิสภา" width="137" height="55" border="0"></a>
             <hr align="center">
             <a href="http://www.kamlangjai.or.th/view.php?docid=216"></a><a href="http://jobmatching.gcc.go.th/website/home.aspx"><img src="images/banner_gccjob.jpg" width="137" height="75" border="0"></a>
             <hr align="center">
             <a href="http://www.rd.go.th/publish/40459.0.html"></a><a href="http://www.mua.go.th/"><img src="images/banner_mua_education2009.jpg" alt="โครงการ &quot;2552 ปีแห่งคุณภาพการอุดมศึกษาไทย&quot;" width="150" height="50" border="0"><br>
             </a>
             <hr align="center">
             <a href="http://www.kmutnb.ac.th/"></a><a href="http://www.ndmi.or.th"></a><a href="http://www.ndmi.or.th"><a href="http://www.ndmi.or.th"><img src="http://www.ndmi.or.th/banner/little_banner_muse.gif" alt="สถาบันพิพิธภัณ์การเรียนรู้" width="150" height="50" border="0"></a><br>
             <hr align="center">
             <a href="http://www.ywc.in.th"><img src="images/160-120.gif" width="130" height="76" border="1"><br>
             <br>
             </a>
             <hr align="center">
           <a href="http://www.ywc.in.th"></a> </div>
         </div>
         <div align="center">
           <div class="style15"><a href="http://www.thaiecac.net"><img src="images/banner_tecac1.gif" width="130" height="68" border="1"></a> </div>
           <span class="style15">
           <hr align="center">
         </span> </div>
         <div align="center">
           <div class="style15"><a href="http://www.thaicyberu.go.th/"><img src="images/banner_tcu.jpg" alt="ศูนย์กลางความรู้แห่งชาติ" width="130" height="50" border="1"></a> </div>
           <span class="style15">
           <hr align="center">
         </span> </div>
         <div class="style15">
           <div align="center"><a href="http://www.tkc.go.th/"><img src="images/banner_tkc.gif" alt="ศูนย์กลางความรู้แห่งชาติ" width="130" height="66" border="0"></a> </div>
         </div>
         <div align="center"><span class="style15"> </span></div>
         <span class="style15">
         <hr align="center">
         <div align="center"><a href="http://www.ictapprentice.net"><img src="images/ict.jpg" alt="ศูนย์ประสานงานการฝึกประสบการณ์ด้านไอซีที ออนไลน์" width="130" height="68" border="1"></a><br>
         </div>
         </span>
         <hr align="center">
         </div>
         <div align="center">
         <!-- <div align="center"><a href="http://www.sci.tsu.ac.th/gen-conf2007/"><img src="images/gen-conf2007.jpg" width="132" height="70" border="1"></a></div>
		<hr align="center">
		</span>        <div align="center">  -->
         <div align="center"><a href="http://www.ipthailand.org/dip/index.php?option=com_content&task=view&id=242&itemid=509&lang=th" target="_blank" ><img src= "images/font.gif" alt="ฟอนต์" width="130" height="82"   border="0"></a> <br>
             <span class="style15"> </span></div>
         <span class="style15">
         <hr>
         </span> </span> <a href="http://www.lc.hum.ku.ac.th/index2.htm" target="_blank" ><img src ="images/kulc.gif" alt="ศูนย์ภาษา คณะมนุษยศาสตร์ขอเชิญชวน  สมัครเรียนโครงการอบรมภาษาต่างประเทศ  วันที่ 14 พย. 2548 -19 มีค. 2549" width="130" height="82" border="0"></a><br>
         <span class="style15">
         <hr>
         <a href="http://kaewkaset.kustaff.ku.ac.th/chinnasee/" target="_blank" ><img src= "http://calendar.ku.ac.th/images/chin.jpg" alt="เชิญผู้มีจิตศรัทธาเช่าบูชา พระพุทธชินสีห์จำลอง"  width="120" height="70" border="1"></a> <br>
         <hr>
         <a href="http://www.psdb.ku.ac.th/government/" target="_blank" ><img src= "http://www.ku.ac.th/images/sai2.gif" alt="http://kucity.kasetsart.org ศูนย์ข่าวชุมชน ม.เกษตรฯ"  width="120" height="70" border="1"></a> <br>
         <hr>
         <a href="http://kucity.kasetsart.org/scripts/kucitywww/kucitywww.exe/www" target="_blank" ><img src= "http://www.ku.ac.th/images/kunewlocal.gif" alt="http://kucity.kasetsart.org ศูนย์ข่าวชุมชน ม.เกษตรฯ"  width="120" height="70" border="1"></a> <br>
         <hr>
         <!--a href="http://kits.ku.ac.th" target="_blank" ><img src= "http://wwwnews.ku.ac.th/images/logo_kits.gif" alt="ห้องปฏิบัติการคอมพิวเตอร์และอินเทอร์เน็ต  ศูนย์เรียนรู้ตามอัธยาศัย ศูนย์กิจกรรมไอทีแห่งใหม่" border=0></a><br>
          <span class="style15">
          <hr-->
         </span> <a href="http://kuhistory.ku.ac.th/" target="_blank" ><img src ="http://www.ku.ac.th/images/sm_history60.gif" alt="หอประวัติ มหาวิทยาลัยเกษตรศาสตร์" border="0"></a><br>
         <span class="style15">
         <hr>
         </span>
         <div align="center">
         <!--a href="http://www.ku.ac.th/e-magazine" target="_blank" ><img src = "http://wwwnews.ku.ac.th/images/sm_emag.gif" alt="ku-emagazine นิตยสารออนไลน์รายเดือน มีข่าวสารเกี่ยวกับด้านเกษตร ไอที และเรื่องน่ารู้" border="0"></a> <br>
            </div>
        <hr align="left"-->
         <div align="center"><a href="http://www.thaifoodtoworld.com/" target="_blank" ><img src="images/thaifood.gif" alt="ครัวไทยสู่ครัวโลก"  width="132" height="63" border="1"></a></div>
         <hr align="left">
         <!--	    <div align="center"><a href="http://www.apcseet.com/" target="_blank" ><img src="http://calendar.ku.ac.th/image/apcseet_logo_120_70.gif" alt="apcseet 2007" border="1"></a></div>
      <hr align="left">
-->
         <div align="center"><a href="http://www.eldc.go.th/" target="_blank" ><img src="http://calendar.ku.ac.th/image/eldc.gif" alt="ศูนย์พัฒนาความสามารถในการใช้ภาษาอังกฤษ" border="1"></a></div>
         <hr align="left">
         <div align="center"><a href="http://www.teenet.info/" target="_blank" ><img src="http://calendar.ku.ac.th/images/teenet.gif" alt="search engin" border="1"></a></div>
         <hr align="left">
         <div align="center"><a href="http://www.thaicyberu.go.th/" target="_blank" ><img src="http://calendar.ku.ac.th/image/tcu.gif" alt="มหาวิทยาลัยไซเบอร์ไทย" border="1"></a></div>
         <hr align="left">
         <div align="center"><a href="http://www.ipthailand.org/" target="_blank"><img src="http://calendar.ku.ac.th/images/dip.gif" alt="กรมทรัพย์สินทางปัญญา" border="1"></a></div>
         <hr align="left">
       </div>
      <hr align="left">  </td>
        <td width="53%" height="100%" rowspan="4" valign="top" bgcolor="f7f7f7">              <table width="100%" hight"80%" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td >                  <table width="100%" hight"91%" border="0" align="left" cellpadding="0" cellspacing="0" bordercolorlight="#cccccc" bordercolordark="white" class="sample">
                      <tr>
                        <td width="91%"  align="left" valign="top" bgcolor="#33cc99"><b>ปฏิทินกิจกรรม ประจำวันที่ 28 สิงหาคม  พ.ศ. 2560</b></td>
                        <td width="9%"  align="left" valign="top" bgcolor="#33cc99"><a href="index.php"><a href="http://calendar.ku.ac.th/index.php?today=28&dfmonth=08&dfyear=2017" target="_top"><img src="../images/button01.gif" border="0"></a></a></td>
                      </tr>
                  </table></td>
                </tr>
                <tr>
                  <td height="12"><img width="400" height="1"></td>
                </tr>
                                <tr>
                  <td height="61"><table width="100%"  hight"100%" border="0" cellspacing="0" cellpadding="0">
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครเข้าศึกษาต่อระดับปริญญาโท สาขาเศรษฐศาสตร์สหกรณ์ (ภาคพิเศษ) รุ่นที่ 16</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-16:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://www.grad.eco.ku.ac.th/" target =" _blank">http://www.grad.eco.ku.ac.th/</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>สำนักบริการคอมพิวเตอร์ ประกาศผลการคัดเลือก พนักงานมหาวิทยาลัยเงินรายได้</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-16:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/job_ocs_25_8_60.pdf"  target = "_blank">job_ocs_25_8_60.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>ขอขยายการรับสมัครบุคคลเพื่อสอบคัดเลือกเป็นพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่งนักวิชาการเงินและบัญชี</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-15:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "www.finance.ku.ac.th" target =" _blank">www.finance.ku.ac.th</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>คณะมนุษยศาสตร์ มก. ประกาศรายชื่อผู้สอบผ่านการคัดเลือกเป็นพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่ง เจ้าหน้าที่บริหารงานทั่วไป สังกัดภาควิชาภาษาตะวันออก</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-16:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/eastlang_listnameadminoffice60.pdf"  target = "_blank">eastlang_listnameadminoffice60.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>คณะสัตวแพทยศาสตร์ขยายเวลารับสมัครพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่งนักวิทยาศาสตร์ จำนวน 1 อัตรา</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-15:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/odyizu0vhs0p.pdf"  target = "_blank">odyizu0vhs0p.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>คณะสิ่งแวดล้อม ขอประกาศ รายชื่อผู้มีสิทธิสอบคัดเลือกพนักงานมหาวิทยาลัยเงินรายได้  ตำแหน่งเจ้าหน้าที่วิจัย</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">ไม่ระบุเวลา								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/20170823110918491.pdf"  target = "_blank">20170823110918491.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>คณะสิ่งแวดล้อม ขอประกาศรายชื่อผู้มีสิทธิสอบคัดเลือกพนักงานมหาวิทยาลัยเงินรายได้  ตำแหน่งเจ้าหน้าที่บริหารงานทั่วไป</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">ไม่ระบุเวลา								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/20170823110927299.pdf"  target = "_blank">20170823110927299.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>คณะสัตวแพทยศาสตร์ประกาศเรียกสำรองเพื่อเข้าปฏิบัติงานเป็นลูกจ้างชั่วคราวโครงการร้านค้าเกษตรเพ็ทช็อพ ตำแหน่งพนักงานขายสินค้า จำนวน 3 อัตรา และตำแหน่งพนักงานบัญชี จำนวน 1 อัตรา</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-00:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/pezmzt0mlva8.pdf"  target = "_blank">pezmzt0mlva8.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>คณะสัตวแพทยศาสตร์รับสมัครพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่งนักวิทยาศาสตร์ จำนวน 8 อัตรา และตำแหน่งพนักงานทั่วไป จำนวน 4 อัตรา</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-15:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/khdvzt0mb34p.pdf"  target = "_blank">khdvzt0mb34p.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>mce เปิดรับสมัครนิสิตใหม่(ภาคพิเศษ) รุ่นที่ 16 เข้าศึกษาต่อปริญญาโท สาขาวิชาเศรษฐศาสตร์สหกรณ์(ภาคพิเศษ)</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-20:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://grad.eco.ku.ac.th" target =" _blank">http://grad.eco.ku.ac.th</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>สถาบันวิจัยและพัฒนาแห่ง มก. ประกาศรับสมัครพนักงานมหาวิทยาลัยตำแหน่ง ช่างเทคนิค</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-16:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://www3.rdi.ku.ac.th/?p=38253" target =" _blank">http://www3.rdi.ku.ac.th/?p=38253</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครเข้ารับการสรรหาผู้สำนักทะเบียนและประมวลผล</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-16:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://www.person.ku.ac.th/" target =" _blank">http://www.person.ku.ac.th/</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>สำนักงานประกันคุณภาพประกาศผลการคัดเลือกพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่งนักวิชาการคอมพิวเตอร์</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">ไม่ระบุเวลา								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/job notice 1.2560.pdf"  target = "_blank">job notice 1.2560.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่งเจ้าหน้าที่บริหารงานทั่วไป สังกัดภาควิชาเทคโนโลยีอุตสาหกรรมเกษตร</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-15:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/ait0002.pdf"  target = "_blank">ait0002.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>คณะสัตวแพทยศาสตร์ขยายเวลาการรับสมัครบุคคลเพื่อคัดเลือกเป็นพนักงานมหาวิทยาลัยสายวิชาการ ตำแหน่งอาจารย์ จำนวน 1 อัตรา</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-15:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/eknqzh0ldn8w.pdf"  target = "_blank">eknqzh0ldn8w.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครเข้าศึกษาต่อระดับปริญญาโท สาขาเศรษฐศาสตร์สหกรณ์ (ภาคพิเศษ) รุ่นที่ 16</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-16:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://www.grad.eco.ku.ac.th/" target =" _blank">http://www.grad.eco.ku.ac.th/</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครบุคคลเพื่อคัดเลือกเป็นพนักงานมหาวิทยาลัย ตำแหน่งอาจารย์ จำนวน 2 อัตรา</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-16:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/jobaa.pdf"  target = "_blank">jobaa.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>ประกาศคณะเศรษฐศาสตร์ เรื่อง รับสมัครคัดเลือกเพื่อบรรจุพนักงานมหาวิทยาลัย ตำแหน่งอาจารย์ จำนวน 2 อัตรา สังกัดภาควิชาเศรษฐศาสตร์</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-16:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://eco.ku.ac.th/2560/08/econ3.pdf" target =" _blank">http://eco.ku.ac.th/2560/08/econ3.pdf</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>คณะสัตวแพทยศาสตร์รับสมัครพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่งเจ้าหน้าที่บริหารงานทั่วไป จำนวน 1 อัตรา</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-15:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/ijmtzg0lc4hs.pdf"  target = "_blank">ijmtzg0lc4hs.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>คณะอุตสาหกรรมเกษตร ขอประกาศรายชื่อผู้มีสิทธิเข้ารับการสอบข้อเขียน พนักงานมหาวิทยาลัยเงินงบประมาณ ตำแหน่งเจ้าหน้าที่บริหารงานทั่วไป ระดับปฏิบัติการ</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">ไม่ระบุเวลา								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/oos0014.pdf"  target = "_blank">oos0014.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>คณะวิศวกรรมศาสตร์  รับสมัคร นักวิเคราะห์นโยบายและแผน 1 อัตรา / ผู้ปฏิบัติงานบริหาร 1 อัตรา</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-16:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/analysis for web.pdf"  target = "_blank">analysis for web.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>ประกาศคณะเทคนิคการสัตวแพทย์ เรื่องรับสมัครพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่งนักวิทยาศาสตร์ จำนวน 1 อัตรา</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">ไม่ระบุเวลา								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://anatomy.vet.ku.ac.th/vtku/inews/view.php?id_view=1285" target =" _blank">http://anatomy.vet.ku.ac.th/vtku/inews/view.php?id_view=1285</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>คณะมนุษยศาสตร์ มก. รับสมัครพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่ง เจ้าหน้าที่บริหารงานทั่วไป สังกัดภาควิชาภาษาต่างประเทศ จำนวน 1 อัตรา</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-16:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/human_recruit_adminofficeforeignlang60.pdf"  target = "_blank">human_recruit_adminofficeforeignlang60.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>เชิญสำรองที่นั่ง และเข้าฟังการบรรยาย แนะนำหลักสูตร (open house)                       mecon รุ่นที่ 27</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-20:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://grad.eco.ku.ac.th" target =" _blank">http://grad.eco.ku.ac.th</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>mecon เปิดรับสมัครนิสิต เข้าศึกษาต่อปริญญาโท สาขาวิชาเศรษฐศาสตร์ ประจำปี พ.ศ. 2560</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-20:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://grad.eco.ku.ac.th" target =" _blank">http://grad.eco.ku.ac.th</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>ขยายเวลาการรับสมัครพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่งเจ้าหน้าที่บริหารงานทั่วไป สังกัดโครงการหลักสูตรปริญญาตรี สาขาอุตสาหกรรมเกษตร ภาคพิเศษ</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-15:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/oos0013.pdf"  target = "_blank">oos0013.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>โครงการปริญญาโท สาขาวิชาวิทยาการคอมพิวเตอร์ ภาคพิเศษ เปิดรับสมัครนิสิตใหม่ ปีการศึกษา 2560</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">ไม่ระบุเวลา								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>ประกาศคณะเทคนิคการสัตวแพทย์ เรื่องรับสมัครลูกจ้างโครงการตำแหน่งนักวิทยาศาสตร์ จำนวน 2 อัตรา</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">ไม่ระบุเวลา								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://anatomy.vet.ku.ac.th/vtku/inews/photo/1284.pdf" target =" _blank">http://anatomy.vet.ku.ac.th/vtku/inews/photo/1284.pdf</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครบุคคลเพื่อคัดเลือกบรรจุเป็นพนักงานมหาวิทยาลัยเงินรายได้</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-16:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://www.forest.ku.ac.th/webdev3" target =" _blank">http://www.forest.ku.ac.th/webdev3</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>ประกาศสำนักการกีฬา เรื่อง รับสมัครตำแหน่งช่างไฟฟ้า</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-15:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/job60-07-01.pdf"  target = "_blank">job60-07-01.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>mecon เปิดรับสมัครนิสิต เข้าศึกษาต่อปริญญาโท สาขาวิชาเศรษฐศาสตร์ ภาคพิเศษ รุ่นที่ 27</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-20:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://grad.eco.ku.ac.th" target =" _blank">http://grad.eco.ku.ac.th</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>ประกาศรับสมัครเพื่อคัดเลือกบุคคลเข้าบรรจุเป็นพนักงานมหาวิทยาลัย ตำแหน่งอาจารย์</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-16:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/econ3.pdf"  target = "_blank">econ3.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครบุคคลเพื่อสอบคัดเลือกเป็นพนักงานมหาวิทยาลัยเงินรายได้</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-16:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/mkinter.pdf"  target = "_blank">mkinter.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครบุคคลเพื่อสอบคัดเลือกเป็นพนักงานมหาวิทยาลัยเงินงบประมาณแผ่นดิน</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-16:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/secx25072560.pdf"  target = "_blank">secx25072560.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครบุคคลเพื่อสอบคัดเลือกเป็นพนักงานมหาวิทยาลัยเงินรายได้</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-16:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/sec25072560.pdf"  target = "_blank">sec25072560.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>ภาควิชาวิทยาการคอมพิวเตอร์ คณะวิทยาศาสตร์ รับสมัครพนักงานมหาวิทยาลัยเงินรายได้ ตำแหน่ง นักวิชาการคอมพิวเตอร์</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">ไม่ระบุเวลา								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/com201760.pdf"  target = "_blank">com201760.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครคัดเลือกเพื่อจ้างและแต่งตั้งบุคคลเข้าเป็็นพนักงานมหาวิทยาลัย ตำแหน่งวิศวกรไฟฟ้า</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-16:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "www.kapi.ku.ac.th" target =" _blank">www.kapi.ku.ac.th</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครเข้าศึกษาต่อระดับปริญญาโท สาขาเศรษฐศาสตร์สหกรณ์ (ภาคพิเศษ) รุ่นที่ 16</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-16:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://www.grad.eco.ku.ac.th/" target =" _blank">http://www.grad.eco.ku.ac.th/</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>สำนักบริการคอมพิวเตอร์ รับสมัครพนักงานมหาวิทยาลัยเงินงบประมาณ ตำแหน่ง วิศวกร</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-16:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/job-12-07-60.pdf"  target = "_blank">job-12-07-60.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครเข้าศึกษาต่อปริญาโท สาขาวิชาเศรษฐศาสตร์สหกรณ์</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">09:00-16:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/mce 16.jpg"  target = "_blank">mce 16.jpg</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครเข้าศึกษาต่อระดับปริญญาโท สาขาเศรษฐศาสตร์สหกรณ์ (ภาคพิเศษ) รุ่นที่ 16</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-16:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://www.grad.eco.ku.ac.th/" target =" _blank">http://www.grad.eco.ku.ac.th/</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>รับสมัครผู้จบปริญญาตรีทุกสาขา ศึกษาต่อ ป.โท mce รุ่นที่ 16 ประจำปี พ.ศ.2560</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-20:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/admission  mce_v 16_2560.pdf"  target = "_blank">admission  mce_v 16_2560.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>mbe เปิดรับสมัครนิสิต เข้าศึกษาต่อปริญญาโท สาขาวิชาเศรษฐศาสตร์ธุรกิจ</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-21:00 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/"  target = "_blank"></a><a href = "http://grad.eco.ku.ac.th" target =" _blank">http://grad.eco.ku.ac.th</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>การอบรมผู้ควบคุมการใช้วัตถุอันตรายเพื่อใช้รับจ้าง (ดำเนินการโดย ภาควิชากีฏวิทยา คณะเกษตร มหาวิทยาลัยเกษตรศาสตร์)</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">ไม่ระบุเวลา								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/ento.pdf"  target = "_blank">ento.pdf</a><a href = "www.ento.age.ku.ac.th" target =" _blank">www.ento.age.ku.ac.th</a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>ประกาศรับสมัครงาน ภาควิชากีฏวิทยา</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">ไม่ระบุเวลา								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/applicationento.pdf"  target = "_blank">applicationento.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                      

                      <tr>
                        <td>
                          <table width="100%" border="0" cellpadding="0" cellspacing="0"  class="sample">
                            <tr>
                              <td align="left" valign="middle" bgcolor="#f7f7f7">
							  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="style4"><b>การบริการวิเคราะห์แมลง ภาควิชากีฏวิทยา คณะเกษตร มหาวิทยาลัยเกษตรศาสตร์ บางเขน</b></td>
                                </tr>
                                <tr>
                                  <td height="18" valign="top" class="style4">08:30-16:30 น. 								  </td>
                                </tr>
								  <tr>
                                  <td class="style4"><a href = "file/identify.pdf"  target = "_blank">identify.pdf</a><a href = "" target =" _blank"></a></td>
                                </tr>
								
                              </table>                                            </td>
                            </tr>
                        </table></td>
                      </tr>
                                                              </table></td>
                </tr>
                          </table>          </td><td width="18%" rowspan="5" bgcolor="#99cccc" valign=top><a href="/indexshotnews.php?today=28&dfmonth=9&dfyear=2017">
          </a>
            <table width="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td valign="top">
                  <div align="center">
                    <!--<script language="javascript">

		function clearsearch(theform) {
        document.formsearch.q.value = '';
		
}

</script>-->
<script language="javascript">

<!--

       function validateinfo3 (theform8)
       {
                if (theform8.q.value =="")
                {
                  alert ("กรุณาป้อน  \"คำที่ต้องการค้นหา\" ");
                  theform8.q .focus();
                  return (false);
                 }
                 return (true);
      }   
//-->
</script>
<form  action="indexfoundword.php" method="post"  onsubmit="return validateinfo3(this)" name= "formsearch">
<!--<input type=text onclick="clearsearch();"  size=20 maxlength=255 value="??????????????" name=q>    
<input  type="text" onclick="clearsearch();" size=15 maxlength=255   name=q>  -->
<div align="left">
  <input   name=q  type="text" onclick="validateinfo3 ();" size=20 maxlength=225>  
  <input name="submit" type="submit" value="ค้นหา">
  <input type=hidden name=ie value=windows-874>
 <!--     <input type=hidden name=domains value="http://calendar.ku.ac.th/">
	   <input type=hidden name=sitesearch value="http://calendar.ku.ac.th/">-->
</div>
</form> 
                </div></td></tr>
              <tr>
                <td><div align="center"><span class="style11"> </span></div>
                    <table width="170" border="0" align="right" bordercolor="black" class="sample">
                      <tr bgcolor="#c5f5c5" class="norm">
                        <td width="24" height="25" align="center" valign="bottom"  bgcolor='#33cc99'><a href="/indexshotnews.php?today=28&dfmonth=7&dfyear=2017" onmouseover="showmenu(event,linkset[0])" onmouseout="delayhidemenu()"><img src="images/ar_l.gif" width="16" height="15" border="0"></a> </td>
                        <td width="120" height="25" colspan="5" align="center" bgcolor='#33cc99'> สิงหาคม&nbsp; 2560 </td>
                        <td width="24" height="25" align="center" valign="bottom" bgcolor='#33cc99'> <a href="/indexshotnews.php?today=28&dfmonth=9&dfyear=2017" onmouseover="showmenu(event,linkset[1])" onmouseout="delayhidemenu()"><img src="images/ar_r.gif" width="16" height="15" border="0"></a> </td>
                      <tr>
                      <tr>
                        <td width="24" align="center" class="sunday">อา</td>
                        <td width="24" align="center" class="norm">จ</td>
                        <td width="24" align="center" class="norm">อ</td>
                        <td width="24" align="center" class="norm">พ</td>
                        <td width="24" align="center" class="norm">พฤ</td>
                        <td width="24" align="center" class="norm">ศ</td>
                        <td width="24" align="center" class="norm">ส</td>
                      </tr>
                      <td width="24" align="center" class="sunday">&nbsp;</td>
<td width="24" align="center" class="norm">&nbsp;</td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=1&dfmonth=8&dfyear=2017>1</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=2&dfmonth=8&dfyear=2017>2</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=3&dfmonth=8&dfyear=2017>3</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=4&dfmonth=8&dfyear=2017>4</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=5&dfmonth=8&dfyear=2017>5</a></td>
<tr>
<td width="24" align="center" class="sunday"><a href=/indexshotnews.php?today=6&dfmonth=8&dfyear=2017>6</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=7&dfmonth=8&dfyear=2017>7</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=8&dfmonth=8&dfyear=2017>8</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=9&dfmonth=8&dfyear=2017>9</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=10&dfmonth=8&dfyear=2017>10</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=11&dfmonth=8&dfyear=2017>11</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=12&dfmonth=8&dfyear=2017>12</a></td>
</tr>
<tr>
<td width="24" align="center" class="sunday"><a href=/indexshotnews.php?today=13&dfmonth=8&dfyear=2017>13</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=14&dfmonth=8&dfyear=2017>14</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=15&dfmonth=8&dfyear=2017>15</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=16&dfmonth=8&dfyear=2017>16</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=17&dfmonth=8&dfyear=2017>17</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=18&dfmonth=8&dfyear=2017>18</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=19&dfmonth=8&dfyear=2017>19</a></td>
</tr>
<tr>
<td width="24" align="center" class="sunday"><a href=/indexshotnews.php?today=20&dfmonth=8&dfyear=2017>20</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=21&dfmonth=8&dfyear=2017>21</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=22&dfmonth=8&dfyear=2017>22</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=23&dfmonth=8&dfyear=2017>23</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=24&dfmonth=8&dfyear=2017>24</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=25&dfmonth=8&dfyear=2017>25</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=26&dfmonth=8&dfyear=2017>26</a></td>
</tr>
<tr>
<td width="24" align="center" class="sunday"><a href=/indexshotnews.php?today=27&dfmonth=8&dfyear=2017>27</a></td>
<td width="24" align="center" class="today"><a href=/indexshotnews.php?today=28&dfmonth=8&dfyear=2017>28</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=29&dfmonth=8&dfyear=2017>29</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=30&dfmonth=8&dfyear=2017>30</a></td>
<td width="24" align="center" class="norm"><a href=/indexshotnews.php?today=31&dfmonth=8&dfyear=2017>31</a></td>
<td width="24" align="center" class="norm">&nbsp;</td>
<td width="24" align="center" class="norm">&nbsp;</td>
</tr>
                  </table></td>
              </tr>
  <td><form name="selectform">
    </form></td>
            </table>            
            
<style type="text/css">
<!--
.style1 {
	color: #ece9d8;
	font-weight: bold;
}
.style6 {font-size: 14px; font-family: "ms sans serif"; color: #666666; }
.style7 {color: #000000}
.style8 {font-size: 10px}
-->
</style>
<script language="javascript">

<!--

       function validateinfo1 (theform4)
       {
                if (theform4.select_month.value =="")
                {
                  alert ("กรุณาเลือก \"เดือน\" ");
                // theform1.select_month .focus();
                  return (false);
                 }
				    if (theform4.select_year.value =="")
                {
                  alert ("กรุณาเลือก\"ปี\" ");
                //  theform1.category.focus();
                  return (false);
                 }
                if (theform4.category.value =="")
                {
                  alert ("กรุณาเลือก\"ประเภทข่าว\" ");
                //  theform1.category.focus();
                  return (false);
                 }
                 return (true);
      }   
//-->
</script>
<form action = "indexfoundnews2.php" method = "post" onsubmit="return validateinfo1(this)" name= "formsearch">
<!--<form  action="indexfoundnews.php" id="select3" name=formsearch>  -->
<!--<input type=text onclick="clearsearch();"  size=20 maxlength=255 value="??????????????" name=q>    -->

  <div align="left">
    <select name="select_month"  id="select1">
      <option>ข่าวกิจกรรมเดือน</option>
      <option value="-01-01">มกราคม</option>
      <option value="-02-01">กุมภาพันธ์</option>
      <option value="-03-01">มีนาคม</option>
      <option value="-04-01">เมษายน</option>
      <option value="-05-01">พฤษภาคม</option>
      <option value="-06-01">มิถุนายน</option>
      <option value="-07-01">กรกฎาคม</option>
      <option value="-08-01">สิงหาคม</option>
      <option value="-09-01">กันยายน</option>
      <option value="-10-01">ตุลาคม</option>
      <option value="-11-01">พฤศจิกายน</option>
      <option value="-12-01">ธันวาคม</option>
    </select>
    <select name="select_year" id="select"><br /><br />
	 <option value="2017">2560</option>
    <option value="2016">2559</option>
     <option value="2015">2558</option>
     <option value="2014">2557</option> 
     <option value="2013">2556</option>
     <option value="2012">2555</option>
     <option value="2011">2554</option>
	 <option value="2010">2553</option>
	  <option value="2009">2552</option>
      <option value="2008">2551</option>
	  <option value="2007">2550</option>
      <option value="2006">2549</option>
      <option value="2005">2548</option>
    </select>
    <br>
    <select name="category" id="select2">
      <option>เลือกประเภทข่าว/กิจกรรม</option>
      <option value="ทุนวิจัย">ทุนวิจัย</option>
      <option value="ทุนการศึกษา">ทุนการศึกษา</option>
      <option value="ศึกษาต่อ">ศึกษาต่อ</option>
      <option value="ประกาศผลสอบ">ประกาศผลสอบ</option>
      <option value="ฝึกอบรม">ฝึกอบรม</option>
      <option value="สัมมนา">สัมมนา</option>
      <option value="ประชุม">ประชุม</option>
      <option value="ประชุมวิชาการ">ประชุมวิชาการ</option>
	  <option value="บรรยายพิเศษ">บรรยายพิเศษ</option>
      <option value="รับสมัครงานในมหาวิทยาลัย">รับสมัครงานในมหาวิทยาลัย</option>
      <option value="สมัครงานภายนอก">สมัครงานภายนอก</option>
      <option value="ประกาศผลสมัครงาน">ประกาศผลสมัครงาน</option>
      <option value="กิจกรรมนิสิต">กิจกรรมนิสิต</option>
      <option value="โครงการกิจกรรม">โครงการกิจกรรม</option>
      <option value="นิทรรศการ">นิทรรศการ</option>
      <option value="ประกวด/แข่งขัน">ประกวด/แข่งขัน</option>
      <option value="กีฬา">กีฬา</option>
      <option value="ศาสนาและศิลปวัฒนธรรม">ศาสนาและศิลปวัฒนธรรม</option>
      <option value="กิจกรรมครบรอบวันสำคัญ">กิจกรรมครบรอบวันสำคัญ</option>
      <option value="สินค้าและบริการ">สินค้าและบริการ</option>
      <option value="วาระผู้บริหาร">วาระผู้บริหาร</option>
      <option value="จัดซื้อ/จัดจ้าง">จัดซื้อ/จัดจ้าง</option>
      <option value="ข้อมูลน่าสนใจ">ข้อมูลน่าสนใจ</option>
      <option value="ประกาศทั่วไปของหน่วยงาน">ประกาศทั่วไปของหน่วยงาน</option>
      <option value="อื่น ๆ">อื่น ๆ</option>
    </select>
 
    <input name="submit" type="submit" value="ค้นหาข่าว" style="border-style: solid 2 px;border-color:  #ffcc33 #ff0033 #ff0033 #ffcc33;background-color: #ff3366;color: #fff" >
    <input type=hidden name=ie value=windows-874>
    <!--  <input type=hidden name=domains value="http://calendar.ku.ac.th/">
       <input type=hidden name=sitesearch value="http://calendar.ku.ac.th/">-->
  </div>
</form> 
            <br>
            <table width="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td><div align="center"><span class="style7 style8"><img src="../images/_banners/calendar_pic.gif" width="32" height="32"></span></div></td>
              </tr>
              <tr>
                <td><div align="center"><span class="style7 style8"><a href="calendar_manual.doc">คู่มือการใช้งาน <br>
        ระบบปฏิทินกิจกรรม มก</a>. </span></div></td>
              </tr>
              <tr>
                <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td><a href="http://calendar.ku.ac.th/accountable.php" class="style7">
                        <li>ตรวจสอบรายชื่อผู้แทนหน่วยงาน </li>
                      </a> </td>
                    </tr>
                    <tr>
                      <td><div align="left"><a href="form_calendar.doc" class="style7">
                          <li>ดาวน์โหลดแบบฟอร์มแจ้งชื่อ<br>
                บัญชีเครือข่ายผู้รับผิดชอบการ<br>
                ประชาสัมพันธ์ข่าวสารผ่านเว็บ </li>
                      </a> </div></td>
                    </tr>
                    <tr>
            
                    </tr>
                    <tr>
                      <td valign="top"><br>
                        <div align="center">
                          <hr align="left">
                          <div align="left" class="style18">nontrinet </div>
                        </div>
                        <div align="left"><span class="style7"> <a href="http://www.ku.ac.th/nontrinet/index.html"> <span class="style16">
                          <li type=square>about nontrinet </li>
                          </span></a><br>
                          <a href="http://www.ku.ac.th/nontrifaq/"> <span class="style16">
                          <li type=square>nontri faq </li>
                          </span></a><br>
                          <a href="https://webmail.ku.ac.th/horde/imp/login.php"> <span class="style16">
                          <li type=square>nontri webmail </li>
                          </span></a><br>
                          <a href="https://nontri.ku.ac.th/tools/"> <span class="style16">
                          <li type=square>nontri server tools </li>
                          </span></a><br>
                          <a href="http://web.ku.ac.th/cert/"> <span class="style16">
                          <li type=square>nontri certificate</li>
                          </span> </a><br>
                          <a href="http://account.ku.ac.th/nontri/"> <span class="style16">
                          <li type=square>query nontri account </li>
                          </span></a><br>
                          <a href="http://info.ku.ac.th/"> <span class="style16">
                          <li type=square>check modem usage </li>
                          </span></a><br>
                          <a href="http://www.cpc.ku.ac.th/service/account.htm"> <span class="style16">
                          <li type=square>nontri account</li>
                          </span></a></span>
                            <hr align="left">
                            <span class="style18">service</span><br>
                            <a href="http://pirun.ku.ac.th/index.html"> <span class="style16">
                            <li type=square>pirun server </li>
                            </span></a> <span class="style18"><br>
                            </span> <a href="http://web.ku.ac.th/"><span class="style16">
                            <li type=square>web server </li>
                            </span></a> <span class="style18"><br>
                            </span> <a href="http://ftp.ku.ac.th/"> <span class="style16">
                            <li type=square>ftp server </li>
                            </span></a> <span class="style18"><br>
                            </span> <a href="http://radio.ku.ac.th/"> <span class="style16">
                            <li type=square>ku radio </li>
                            </span></a> <span class="style18"><br>
                            </span> <a href="http://kuwin.ku.ac.th/"><span class="style16">
                            <li type=square>ku win </li>
                          </span></a></div>
                      <br>
                      <hr align="left">
                      <p align="center">&nbsp;</p>
                      <p align="center">&nbsp;                      </p></td>
                    </tr>
                </table></td>
              </tr>
            </table>
            </td>
      </tr>
      <tr valign="top">
        
      </tr>
 
      <tr valign="top">        </tr>
      <tr valign="top" bgcolor="#339966">
        
      </tr>
    </table></td>
  </tr>
</table>
<table width="800" height="146" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="132" bgcolor="#3dcf89"><div align="center"><span class="style17 style8 style3 style1"><b><br>
            <b><span class="style13 style3">สำนักบริการคอมพิวเตอร์ มหาวิทยาลัยเกษตรศาสตร์</span></b> <span class="style3">&nbsp;</span>
            <!--begin web stat code-->
            <!-- end webstat code -->
        <span class="style4"><br>
        </span></b></span><span class="style4 style3 style17"><span class="style4"><br>
โทรศัพท์ 0-2562-0951-6 ต่อ 2514,2902,2903<br>
โทรสาร 0-2562-0957</span></span><span class="style17 style8 style3 style1"><b><span class="style4"><br>
</span></b><span class="style4"><a 
      href="mailto:www@ku.ac.th">ติดต่อผู้ดูแลระบบ</a></span><b><span class="style4"><br>
</span></b></span><span class="style4 style3 style17"><span class="style4">ปรับปรุงล่าสุด :
<!-- #begindate format:am1 -->march 30, 2010<!-- #enddate -->
        </span></span><span class="style4"><br>
        <br>
    </span></div></td>
  </tr>
</table>
</body></html>
