<?
session_start();
$session=session_id();
$time=time();
$time_check=$time-600; //กำหนดเวลาในที่นี้ผมกำหนด 10 นาที

?>
<!doctype html public "-//w3c//dtd xhtml 1.0 transitional//en" "http://www.w3.org/tr/xhtml1/dtd/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en"><!-- instancebegin template="/templates/index-2010-04.dwt.php" codeoutsidehtmlislocked="false" -->
<head>
    <!--
    created by artisteer v2.2.0.17376
    base template (without user's data) checked by http://validator.w3.org : "this page is valid xhtml 1.0 transitional"
    -->
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="x-ua-compatible" content="ie=emulateie7" />
    <!-- instancebegineditable name="doctitle" -->
    <title>ศูนย์เทคโนโลยีชีวภาพเกษตร : center for agricultural biotechnology (cab)</title>
    <!-- instanceendeditable -->
<script type="text/javascript" src="script.js"></script>

    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />
    <!--[if ie 6]><link rel="stylesheet" href="style.ie6.css" type="text/css" media="screen" /><![endif]-->
    <!--[if ie 7]><link rel="stylesheet" href="style.ie7.css" type="text/css" media="screen" /><![endif]-->
    <style type="text/css">
<!--
#apdiv1 {
	position:absolute;
	left:1104px;
	top:205px;
	width:167px;
	height:28px;
	z-index:1;
	clip: rect(auto,auto,auto,890);
}
#apdiv2 {
	position:absolute;
	left:868px;
	top:229px;
	width:153px;
	height:32px;
	z-index:1;
}
#apdiv3 {
	position:absolute;
	left:1000px;
	top:240px;
	width:66px;
	height:31px;
	z-index:1;
}
.style2 {color: #9e6f00}
#apdiv4 {
	position:absolute;
	width:221px;
	height:46px;
	z-index:1;
	left: 1037px;
	top: 143px;
}
-->
    </style>
    <script src="../scripts/ac_runactivecontent.js" type="text/javascript"></script>
    <!-- instancebegineditable name="head" --><!-- instanceendeditable -->
</head>
<body>
<div id="art-page-background-simple-gradient">
    </div>
    <div id="art-page-background-glare">
        <div id="art-page-background-glare-image"></div>
    </div>
    <div id="art-main">
<div class="art-sheet">
            <div class="art-sheet-tl"></div>
            <div class="art-sheet-tr"></div>
            <div class="art-sheet-bl"></div>
            <div class="art-sheet-br"></div>
            <div class="art-sheet-tc"></div>
            <div class="art-sheet-bc"></div>
            <div class="art-sheet-cl"></div>
            <div class="art-sheet-cr"></div>
            <div class="art-sheet-cc"></div>
            <div class="art-sheet-body">
  <div class="art-header">
                    <div class="art-header-jpeg"></div>
                    <div class="art-logo">
                    </div>
                </div>
                <div class="art-contentlayout">
                  <div class="art-sidebar1">
                    <div class="art-block">
                      <div class="art-block-tl"></div>
                      <div class="art-block-tr"></div>
                      <div class="art-block-bl"></div>
                      <div class="art-block-br"></div>
                      <div class="art-block-tc"></div>
                      <div class="art-block-bc"></div>
                      <div class="art-block-cl"></div>
                      <div class="art-block-cr"></div>
                      <div class="art-block-cc"></div>
                      <div class="art-block-body">
                        <div class="art-blockheader">
                          <div class="art-header-tag-icon">
                            <div class="t">เกี่ยวกับศูนย์ฯ</div>
                          </div>
                        </div>
                        <div class="art-blockcontent">
                          <div class="art-blockcontent-tl"></div>
                          <div class="art-blockcontent-tr"></div>
                          <div class="art-blockcontent-bl"></div>
                          <div class="art-blockcontent-br"></div>
                          <div class="art-blockcontent-tc"></div>
                          <div class="art-blockcontent-bc"></div>
                          <div class="art-blockcontent-cl"></div>
                          <div class="art-blockcontent-cr"></div>
                          <div class="art-blockcontent-cc"></div>
                          <div class="art-blockcontent-body">
                            <div>
                              <ul class="style2">
                                <li class="style2"><a href="index.php">หน้าแรก</a></li>
                                <li><a href="aboutme.php">เกี่ยวกับศูนย์ฯ</a></li>
                                <li><a href="vision.php">วิสัยทัศน์/เป้าหมายทางวิชาการ</a></li>
                                <li><a href="http://www.cab.kps.ku.ac.th/cab-2009-06/organiz.html" target="_blank">โครงสร้างองค์กร</a></li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="art-block-body">
                        <div class="art-blockheader">
                          <div class="art-header-tag-icon">
                            <div class="t">บริการทางวิชาการ</div>
                          </div>
                        </div>
                        <div class="art-blockcontent">
                          <div class="art-blockcontent-tl"></div>
                          <div class="art-blockcontent-tr"></div>
                          <div class="art-blockcontent-bl"></div>
                          <div class="art-blockcontent-br"></div>
                          <div class="art-blockcontent-tc"></div>
                          <div class="art-blockcontent-bc"></div>
                          <div class="art-blockcontent-cl"></div>
                          <div class="art-blockcontent-cr"></div>
                          <div class="art-blockcontent-cc"></div>
                          <div class="art-blockcontent-body">
                            <div>
                              <ul>
                                <li><a href="course.php">หลักสูตรที่เปิดสอน</a></li>
                                <li><a href="prof.php">บุคลากรด้านวิชาการ</a></li>
                                <li><a href="research.php">งานวิจัย และห้องปฏิบัติการ</a></li>
                                <li><a href="services.php">งานบริการจำแนกเชื้อแบคทีเรีย</a></li>
                                <li><a href="services.php">บริการไนโตรเจนเหลว</a></li>
                                <li><a href="http://cab.ku.ac.th/tools_science/" target="_blank">บริการเครื่องมือวิทยาศาสตร์</a></li>
                                <li><a href="http://www.cab.kps.ku.ac.th/cab-2010-04/images/natural_water_droplet.jpg" target="_blank">จำหน่ายน้ำบริสุทธิ์ ชนิด type-i</a></li>
                                <li><a href="http://cab.ku.ac.th/cab-2010-04/doc/agcipherannouce.pdf" target="_blank">บริการงานมวลผลด้าน bioinformatics</a></li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="art-block">
                      <div class="art-block-tl"></div>
                      <div class="art-block-tr"></div>
                      <div class="art-block-bl"></div>
                      <div class="art-block-br"></div>
                      <div class="art-block-tc"></div>
                      <div class="art-block-bc"></div>
                      <div class="art-block-cl"></div>
                      <div class="art-block-cr"></div>
                      <div class="art-block-cc"></div>
                      <div class="art-block-body">
                        <div class="art-blockheader">
                          <div class="art-header-tag-icon">
                            <div class="t">ผลงานทางวิชาการ</div>
                          </div>
                        </div>
                        <div class="art-blockcontent">
                          <div class="art-blockcontent-tl"></div>
                          <div class="art-blockcontent-tr"></div>
                          <div class="art-blockcontent-bl"></div>
                          <div class="art-blockcontent-br"></div>
                          <div class="art-blockcontent-tc"></div>
                          <div class="art-blockcontent-bc"></div>
                          <div class="art-blockcontent-cl"></div>
                          <div class="art-blockcontent-cr"></div>
                          <div class="art-blockcontent-cc"></div>
                          <div class="art-blockcontent-body">
                            <div>
                              <div>
                                <ul>
                                  <li><a href="http://it.cab.kps.ku.ac.th/db_cab/program_project/paper_presentationslist.php?cmd=resetall" target="_blank">การนำเสนอผลงานทางวิชาการ</a></li>
                                  <li><a href="http://it.cab.kps.ku.ac.th/db_cab/program_project/paper_publicationslist.php?cmd=resetall" target="_blank">ผลการวิจัยสิ่งตีพิมพ์</a></li>
                                  <li><a href="http://www.cab.kps.ku.ac.th/db_cab/program_project/thesislist.php" target="_blank">วิทยานิพนธ์นิสิต ที่สำเร็จการศึกษา</a><br />
                                </li>
                                </ul>
</div>
                      </div>
                          </div>
                        </div>
                      </div>
                      <div class="art-block-body">
                        <div class="t"><strong>การอ้างถึงการสนับสนุนจาก<br />
                        ศูนย์ความเป็นเลิศ</strong></div>
                        <div class="art-blockcontent">
                          <div class="art-blockcontent-tr"></div>
                          <div class="art-blockcontent-body">
                            <div>
                              <div>
                                <ul>
                                  <li><a href="doc/refer_cab.pdf" target="_blank">นิสิตหลักสูตรเทคโนโลยีชีวภาพเกษตร</a></li>
                                  <li><a href="doc/refer_join.pdf" target="_blank">นิสิตสถาบันร่วม, ภาคีสมาชิก และนิสิตวิชารอง</a><br />
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="art-block-body">
                        <div class="art-blockheader">
                          <div class="art-header-tag-icon">
                            <div class="t">ลิงค์ที่น่าสนใจ</div>
                          </div>
                        </div>
                        <div>
                          <div align="center">
                            <p align="center"><a href="http://158.108.144.50/db_cab/program_project" target="_blank"><img src="images/baner_database.jpg" alt="ฐานข้อมูล" width="182" height="60" /></a></p>
                            <p align="center"><a href="download.php"><img src="images/banner_download.jpg" alt="" width="182" height="60" /></a></p>
                            <p align="center"><a href="reports_index.php"><img src="images/banner_reports_year.jpg" alt="รายงานประจำปี" width="182" height="60" border="0" /></a><br />
                              <br />
                              <a href="http://www.perdo.or.th/" target="_blank"><img src="images/banner_perdo.jpg" alt="" width="182" height="60" /><br />
                              <br />
                                </a><a href="http://www.cab.kps.ku.ac.th/cab-2009-06/sub_connect.php" target="_blank"><img src="images/banner_subconnect.jpg" width="182" height="60" /></a><br />
                            </p>
                            <p><a href="http://www.cab.kps.ku.ac.th/cab-2009-06/connection.php" target="_blank"><img src="images/banner_sub_network.jpg" width="182" height="60" /><br />
                            </a><br />
                              <a href="http://www.grad.ku.ac.th" target="_blank"><img src="images/banner_graduate_school.jpg" alt="บัณฑิตวิทยาลัย" width="182" height="60" /></a><br />
                              <br />
                              <a href="http://breedserve.cab.kps.ku.ac.th/" target="_blank"><img src="images/cabdbtool_banner.png" width="181" height="60" /></a><br />
                              </p>
                            <p><a href="http://www.cab.ku.ac.th/suntaree/" target="_blank"><img src="images/banner_plantbiophysics.jpg" alt="" width="182" height="60" /></a></p>
                            <p><a href="http://it.cab.kps.ku.ac.th/cab_live" target="_blank"><img src="images/banner_cablive.jpg" width="182" height="60" /></a></p>
<p><a href="http://cab.kps.ku.ac.th/db_cab/tb_journal/tb_journallist.php" target="_blank"><img src="images/banner_journal.jpg" alt="รายชื่อวารสารที่ใช้เป็นเกณฑ์สำเร็จการศึกษา" width="182" height="60" border="0" /></a></p>
                            <p><a href="http://www.cab.kps.ku.ac.th/freezer" target="_blank"><img src="images/freezer.gif" alt="ฐานข้อมูลการจัดเก็บตัวอย่าง ด้วยตู้แช่แข็ง" width="182" height="60" /></a></p>
                            <p><a href="http://158.108.144.14/db_repair" target="_blank"><img src="images/repire_services.jpg" width="182" height="60"  alt="ระบบแจ้งซ่อมบำรุง"/></a></p>
                            <p><a href="http://www.ku.ac.th" target="_blank"><img src="images/banner_ku.jpg" alt="มหาวิทยาลัยเกษตรศาสตร์" width="182" height="60" /></a></p>
                            <p><a href="https://webmail.ku.ac.th/roundcube/" target="_blank"><img src="images/banner_kuwebmail.jpg" alt="ku webmail" width="182" height="60" /></a></p>
                            <p><a href="http://get.adobe.com/reader/" target="_blank"><img src="images/baner_acrobat.jpg" alt="get adobe reader" width="182" height="60" /></a></p>
                            <p><a href="http://cab.kps.ku.ac.th/cab-2010-04/01555661/index.html" target="_blank"><img src="images/banner-2015-02-12-002.jpg" width="182" height="60" /></a><br />
                            </p>
</div>
                        </div>
                      </div>
                      <div class="art-block-body">
                        <div class="art-blockheader">
                          <div class="art-header-tag-icon">
                            <div class="t">ติดต่อเรา</div>
                          </div>
                        </div>
                        <div class="art-blockcontent">
                          <div class="art-blockcontent-tl"></div>
                          <div class="art-blockcontent-tr"></div>
                          <div class="art-blockcontent-bl"></div>
                          <div class="art-blockcontent-br"></div>
                          <div class="art-blockcontent-tc"></div>
                          <div class="art-blockcontent-bc"></div>
                          <div class="art-blockcontent-cl"></div>
                          <div class="art-blockcontent-cr"></div>
                          <div class="art-blockcontent-cc"></div>
                          <div class="art-blockcontent-body">
                            <div> 
                              <p align="center"><a href="http://www.cab.kps.ku.ac.th/photoactivity/admin/login.php" target="_blank"><img src="images/banner-admin.jpg" alt="" width="182" height="60" /></a></p>
                              <p align="center"><a href="cab_map.php"><img src="images/banner_cabmap.jpg" alt="แผนที่สถานที่ตั้งของศูนย์ฯ" width="169" height="60" /></a></p>
                              <p align="center"><a href="http://www.facebook.com/agbio.perdo" target="_blank"><img src="images/ag-bioperdofacebook.jpg" alt="ag-bio perdo facebook" width="137" height="84" /></a></p>
                              <p><a href="mailto:kps.cab@ku.ac.th"><img src="images/email-marketing.jpg" alt="mail to me" border="0" style="margin: 0 auto;display:block;width:95%" /></a> e-mail : <a href="mailto:kps.cab@ku.ac.th">kps.cab@ku.ac.th</a><br />
                                สำนักงาน บางเขน :<br />
                                tel. 0-2942-8361<br /> 
                                0-2942-7133<br />
                                fax.0-2942-8258<br />
                                <br />
                                สำนักงาน กำแพงแสน :<br />
                                tel. 0-3435 3217 ถึง 20<br />
                                fax.0-3435 3222<br />
                              moblie 09 1774 0091</p>
                              <p></p>
<p>จำนวนผู้เข้าชมเว็บ <b>10210</b> <script type="text/javascript" language="javascript1.1" src="http://tracker.stats.in.th/tracker.php?uid=21160"></script><noscript><a target="_blank" href="http://www.stats.in.th/">www.stats.in.th</a></noscript> <br />
                              (นับตั้งแต่ 04/05/2553)<br />
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
      <div class="art-content">
          <div class="art-post"><!-- instancebegineditable name="editregion3" -->
                          <div class="art-post-body">
                            <div class="art-post-inner">
                              <h2 align="center" class="art-postheadericon-wrapper">งานบริการ<br />
                              </h2>
                              <div class="art-postcontent">
                                <table class="table" width="100%">
                                  <tr>
                                    <td valign="top"><p>&nbsp;</p>
                                      <ul>
                                        <li>การให้บริการจัดจำแนกเชื้อแบคทีเรีย ด้วยระบบ maldi-biotyper </li>
                                        <li> การให้บริการไนโตรเจนเหลวภายในวิทยาเขตกำแพงแสน</li>
                                        <li> การให้บริการด้านเครื่องมือทางวิทยาศาสตร์</li>
                                      </ul>
                                      <p>&nbsp;</p>
                                      <ul>
                                        <li><strong>การให้บริการจัดจำแนกเชื้อแบคทีเรีย ด้วยระบบ maldi-biotyper </strong><br />
                                          &nbsp;&nbsp;&nbsp;&nbsp; ใช้หลักการของ maldi ms หรือ matrix assisted laser desorption/ ionization mass spectrometry ซึ่งเป็นการตรึงโปรตีนหรือเปปไทด์กับผลึกของ matrix (crystalline matrix) และยิงแสงเลเซอร์ลงบนตัวอย่างโปรตีนให้เกิดการแตกตัวเป็นไอออน แล้วเคลื่อนที่ไปตามท่อสุญญากาศที่มีสนามไฟฟ้า โดยสารที่มวลโมเลกุลน้อยจะเคลื่อนที่ไปได้เร็วกว่าสารที่มีมวลโมเลกุลมาก และตกกระทบกับตัวตรวจจับ (detector) ระยะเวลาที่ไอออนเคลื่อนที่ไปตกกระทบกับตัวตรวจจับ เรียกกว่า time-of-flight (tof) ได้เป็น m/z peak เรียงตัวกันเรียกว่า peptide mass fingerprint (pmf) ช่วงระหว่าง 4,000 &ndash; 8,000 m/z หรือประมาณ 2,000 &ndash; 20,000 daltons   แล้วจึงนำ pmf ที่ได้เปรียบเทียบกับฐานข้อมูลในโปรแกรม maldi-biotypertm <br />
                                          <br />
                                          <strong>ชนิดตัวอย่างที่ส่งตรวจ:</strong> เชื้อแบคทีเรียบริสุทธิ์<br />
                                          <br />
                                          <strong>อัตราค่าบริการ: </strong>ค่าบริการ 1 ตัวอย่าง 3600 บาท ตัวอย่างต่อไป ตัวอย่างละ 600 บาท<br />
                                          <br />
                                          <strong>ระยะเวลาดำเนินการ:</strong> ประมาณ 7 วัน <br />
                                          <br />
                                        <strong>หมายเหตุ: </strong>ในการจัดจำแนกเชื้อ อาจจะไม่สามารถจัดจำแนกเชื้อได้ เนื่องจากจำกัดด้วยฐานข้อมูล และการจัดจำแนกเชื้อด้วยเทคนิคเพียงอย่างเดียวไม่สามารถนำไปใช้อ้างอิงชนิดของเชื้อแบคทีเรียได้ 100 เปอร์เซ็นต์</li>
                                      </ul>
<p><img src="images/img-001.jpg" width="559" height="308" /><br />
  <img src="images/img-002.jpg" width="606" height="494" /><br />
  <img src="images/img-003.jpg" width="203" height="411" /><img src="images/img-004.jpg" width="416" height="305" /></p>
                                      <ul>
                                        <li><strong>การให้บริการไนโตรเจนเหลวภายในวิทยาเขตกำแพงแสน</strong><br />
                                          <br />       
                                          ตามที่ศูนย์เทคโนโลยีชีวภาพเกษตรได้แจ้งการให้บริการไนโตรเจนเหลวภายในวิทยาเขตกำแพงแสนนั้น   ทางศูนย์ขอชี้แจ้งระบบการให้บริการดังนี้</li>
                                      </ul>
                                      <p>วันจันทร์ และ วันพฤหัสบดี  เวลา 08.30 - 09.30 น.<br />
                                      *เริ่มให้บริการวันดังกล่าวตั้งแต่ สิงหาคม 2558 นี้</p>
                                      <p>* เว้นวันหยุดราชการ โดยให้ถือปฏิบัติตามเวลาดั่งกล่าว</p>
                                      <p>อัตราบริการ 35 บาท ต่อ 1 กิโลกรัม <br />
                                        * กรณีที่ท่านเติมไม่ถึง 10 กิโลกรัม   ทางศูนย์จะคิดอัตราบริการในจำนวน 10 กิโลกรัม</p>
                                      <p>     ทางศูนย์จะรับชำระเป็นเงินสด แต่ถ้าเป็นกรณีโอนเงินระหว่างหน่วยงาน   ทางศูนย์ฯ จะตัดยอดที่ต้องชำระ ณ วันสิ้นเดือนของทุกเดือน   แล้วก็จะแจ้งเก็บเงินโดยทำเรื่องการขอให้หน่วยงานโอนเงินให้ทางศูนย์   ตามใบแจ้งการโอนเงิน ที่ฝ่ายการเงินศูนย์เทคโนโลยีชีวภาพเกษตร ชั้น 1   อาคารปฏิบัติการศูนย์เทคโนโลยีชีวภาพเกษตร มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน   จ.นครปฐม</p>
                                      <p> </p>
                                      <ul>
                                        <li><strong>การให้บริการด้านเครื่องมือทางวิทยาศาสตร์</strong></li>
                                      </ul>
                                      <p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>ศูนย์เทคโนโลยีชีวภาพเกษตร   ในฐานะเป็นศูนย์วิจัยระดับแนวหน้าของประเทศและภูมิภาคในสาขาเทคโนโลยีชีวภาพเกษตร   ที่นักวิจัยสามารถดำเนินกิจกรรมวิจัยในทางกว้างและลึก   ศูนย์ได้จัดบริการเครื่องมือพร้อมให้บริการแก่นิสิตและคณาจารย์ เช่น   ultracentrifuge, hi-speed centrifuge, pcr., real-time pcr, fluorescence   microscope, compound microscopes , 2-d gel electrophoresis, particle gene gun   system, digital camera for microscope, elisa reader and washer, electroporation   system, gel documentation and analysis system, pulse-field gel electrophoresis,   freeze dryer, -80 freezer, รวมถึงเครื่องมือวัดค่าทางสรีรวิทยา เช่น   photosynthesis system , chlorophyll meter, ohmmeter system, flow control unit,   plan water status console set, tensiometer set, potentiometer, dendrometer set   and components, agro-metrological workstation, portable leaf area meter ฯลฯ</p>
                                    <p>          สนใจรายละเอียดเพิ่มเติม <a href="../tools_science/" target="_blank">คลิกที่นี้</a></p></td>
                                  </tr>
                                  <tr>
                                    <td valign="top">&nbsp;</td>
                                  </tr>
                                </table>
                              </div>
                              <div class="cleared"></div>
                            </div>
                        </div>
                        <!-- instanceendeditable --></div>
<div class="art-post"><!-- instancebegineditable name="editregion4" -->
  <div class="art-post-body">
    <div class="art-post-inner">
      <h2 class="art-postheadericon-wrapper"><img src="images/natural_water_drople_resizet.jpg" width="600" height="450" /></h2>
      <div class="art-postcontent">
        <p>&nbsp;</p>
      </div>
      <div class="cleared"></div>
    </div>
  </div>
<!-- instanceendeditable --></div>
                  </div>
                    <div align="center"></div>
<div class="art-sidebar2"></div>
              </div>
  <div class="cleared"></div><div class="art-footer">
                    <div class="art-footer-inner">
                    <div class="art-footer-text">
                            <p>สำนักงาน บางเขน : อาคารพิพิธภัณฑ์แมลง 60 ปี มหาวิทยาลัยเกษตรศาสตร์ บางเขน จตุจักร กรุงเทพฯ 10900<br />
                            โทรศัพท์ 0 2942 8361, 0 2942 7133 โทรสาร 0 2942 8258</p>
                            <p>สำนักงาน กำแพงแสน : ศูนย์เทคโนโลยีชีวภาพเกษตร มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน เลขที่ 1 หมู่ 6 ต.กำแพงแสน อ.กำแพงแสน จ. นครปฐม 73140<br />
                              โทรศัพท์ 0 3435 3217 ถึง 20 โทรสาร 0 3435 3222 มือถือ 09 1774 0091<br />
                            </p>
                    </div>
        </div>
        <div class="art-footer-background"></div>
                </div>
            </div>
        </div>
        <div class="cleared"></div>
</div>
    
    </body>
<!-- instanceend --></html>
