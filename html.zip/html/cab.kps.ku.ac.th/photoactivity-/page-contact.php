<!doctype html public "-//w3c//dtd xhtml 1.0 transitional//en" "http://www.w3.org/tr/xhtml1/dtd/xhtml1-transitional.dtd"[]>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en">
<head>

    <!--
    created by artisteer v3.1.0.48375
    base template (without user's data) checked by http://validator.w3.org : "this page is valid xhtml 1.0 transitional"
    -->
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>ข่าวการอบรม - สัมมนา</title>



    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />
    <!--[if ie 6]><link rel="stylesheet" href="style.ie6.css" type="text/css" media="screen" /><![endif]-->
    <!--[if ie 7]><link rel="stylesheet" href="style.ie7.css" type="text/css" media="screen" /><![endif]-->
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
    <script type="text/javascript" src="jquery.js"></script>
    <script type="text/javascript" src="script.js"></script>
   <style type="text/css">
.art-post .layout-item-0 { padding-right: 10px;padding-left: 10px; }
   .ie7 .art-post .art-layout-cell {border:none !important; padding:0 !important; }
   .ie6 .art-post .art-layout-cell {border:none !important; padding:0 !important; }
   </style>

</head>
<body>
<div id="art-main">
    <div class="cleared reset-box"></div>
<div class="art-bar art-nav">
<div class="art-nav-outer">
<div class="art-nav-wrapper">
<div class="art-nav-inner">
	<ul class="art-hmenu">
		<li>
			<a href="./index.php" class="active">ข่าวการอบรม - สัมมนา</a>
		</li>	
		<li>
			<a href="./page-activity.php">ประมวลภาพกิจกรรม</a>
		</li>	
		<li>
			<a href="./page-admin.php">สำหรับเจ้าหน้าที่</a>
		</li>	
		<li>
			<a href="./page-contact.php">ติดต่อ - สอบถาม</a>
		</li>	
	</ul>
</div>
</div>
</div>
</div>
<div class="cleared reset-box"></div>
<div class="art-box art-sheet">
        <div class="art-box-body art-sheet-body">
            <div class="art-layout-wrapper">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
                        <div class="art-layout-cell art-content">
<div class="art-box art-post">
    <div class="art-box-body art-post-body">
<div class="art-post-inner art-article">
                                <h2 class="art-postheader">ติดต่อ - สอบถาม </h2><div class="art-postcontent">
  <div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 100%;">
        <p><strong>สำนักงาน บางเขน </strong></p>
        <p>อาคารพิพิธภัณฑ์แมลง 60 ปี มหาวิทยาลัยเกษตรศาสตร์ บางเขน   จตุจักร กรุงเทพฯ 10900<br />
          โทรศัพท์ 0 2942 8361, 0 2942 7133 โทรสาร 0 2942   8258</p>
        <p>&nbsp;</p>
        <p><strong>สำนักงาน กำแพงแสน</strong> </p>
        <p>ศูนย์เทคโนโลยีชีวภาพเกษตร มหาวิทยาลัยเกษตรศาสตร์   วิทยาเขตกำแพงแสน อ.กำแพงแสน จ.นครปฐม 73140<br />
          โทรศัพท์ 0 3428 2494 ถึง 7 โทรสาร   0 3428 2498</p>
    </div>
    </div>
</div>

                </div>
                <div class="cleared"></div>
                </div>

		<div class="cleared"></div>
    </div>
</div>

                          <div class="cleared"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="cleared"></div>
            <div class="art-footer">
                <div class="art-footer-body">
                            <div class="art-footer-text">
                                <p>center for agricultural biotechnology(cab)</p>
                                                            </div>
                    <div class="cleared"></div>
                </div>
            </div>
    		<div class="cleared"></div>
        </div>
    </div>
    <div class="cleared"></div>
    <p class="art-page-footer">&nbsp;</p>
    <div class="cleared"></div>
</div>

</body>
</html>
