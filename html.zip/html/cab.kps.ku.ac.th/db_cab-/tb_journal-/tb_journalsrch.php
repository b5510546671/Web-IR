<!doctype html public "-//w3c//dtd html 4.01 transitional//en" "http://www.w3.org/tr/html4/loose.dtd">
<html>
<head>
	<title>รายชื่อวารสารที่ใช้เป็นเกณฑ์การสำเร็จการศึกษา ระดับปริญญาโท และปริญญาเอก สาขาเทคโนโลยีชีวภาพเกษตร</title>
<link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/2.9.0/build/menu/assets/skins/sam/menu.css">
<link rel="stylesheet" type="text/css" href="phpcss/ewmenu.css">
<link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/2.9.0/build/container/assets/skins/sam/container.css">
<link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/2.9.0/build/resize/assets/skins/sam/resize.css">
<link rel="stylesheet" type="text/css" href="phpcss/projectz.css">
<!-- *** note: include additional jquery css files here *** -->
<script type="text/javascript" src="http://yui.yahooapis.com/2.9.0/build/utilities/utilities.js"></script>
<script type="text/javascript" src="http://yui.yahooapis.com/2.9.0/build/container/container-min.js"></script>
<script type="text/javascript" src="http://yui.yahooapis.com/2.9.0/build/resize/resize-min.js"></script>
<script type="text/javascript" src="http://yui.yahooapis.com/2.9.0/build/menu/menu.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<!-- *** note: include additional jquery js files here *** -->
<script type="text/javascript">
<!--
var ew_language_id = "en";
var ew_date_separator = "/"; 
if (ew_date_separator == "") ew_date_separator = "/"; // default date separator
var ew_upload_allowed_file_ext = "gif,jpg,jpeg,bmp,png,doc,xls,pdf,zip"; // allowed upload file extension
var ew_field_sep = ", "; // default field separator

// ajax settings
var ew_record_delimiter = "\r";
var ew_field_delimiter = "|";
var ew_lookup_file_name = "ewlookup8.php"; // lookup file name
var ew_auto_suggest_max_entries = 10; // auto-suggest max entries

// common javascript messages
var ew_addopt_button_submit_text = "เพิ่ม";
var ew_email_export_button_submit_text = "ส่งรหัสผ่าน";
var ew_button_cancel_text = "ยกเลิก";
var ewtooltipdiv;
var ew_tooltiptimer = null;

//-->
</script>
<script type="text/javascript" src="phpjs/ewp8.js"></script>
<script type="text/javascript" src="phpjs/userfn8.js"></script>
<script type="text/javascript">
<!--
var ewlanguage = new ew_language({"deleteconfirmmsg":"ต้องการลบใช่หรือไม่?","deletemulticonfirmmsg":"ต้องการลบใช่หรือไม่?","enternewpassword":"กรุณากรอกรหัสผ่านใหม่","enteroldpassword":"กรุณากรอกรหัสผ่านเดิม","enterpassword":"กรุณากรอกรหัสผ่าน","enterpwd":"กรุณากรอกรหัสผ่าน","enterrequiredfield":"กรุณากรอกข้อมูล","enterusername":"please enter username","entervalidatecode":"please enter the validation code shown","entersenderemail":"please enter sender email","enterpropersenderemail":"exceed maximum sender email count or email address incorrect","enterrecipientemail":"please enter recipient email","enterproperrecipientemail":"exceed maximum recipient email count or email address incorrect","enterproperccemail":"exceed maximum cc email count or email address incorrect","enterproperbccemail":"exceed maximum bcc email count or email address incorrect","entersubject":"please enter subject","enteruid":"กรุณากรอกรหัสผู้ใช้","entervalidemail":"กรุณากรอกอีเมล์ที่ถูกต้อง","exporttoemail":"email","hidehighlight":"ซ่อนการเน้นข้อความ","incorrectemail":"incorrect email","incorrectfield":"incorrect field","incorrectfloat":"incorrect floating point number","incorrectguid":"incorrect guid","incorrectinteger":"incorrect integer","incorrectphone":"incorrect phone number","incorrectregexp":"regular expression not matched","incorrectrange":"number must be between %1 and %2","incorrectssn":"incorrect social security number","incorrecttime":"incorrect time (hh:mm:ss)","incorrectzip":"incorrect zip code","invalidrecord":"invalid record! key is null","loading":"loading...","mismatchpassword":"รหัสผ่านไม่ตรงกัน","noaddrecord":"ไม่มีการเพิ่มข้อมูลใด ๆ","nofieldselected":"ไม่มีการเลือกข้อมูล","norecordselected":"ไม่มีข้อมูลใดถูกเลือก","sendemailsuccess":"ส่ง email สำเร็จแล้ว","showhighlight":"แสดงการเน้นข้อความ","userleveladministratorname":"ชื่อระดับของผู้ใช้สำหรับระดับ -1 ต้องเป็น 'administrator' เท่านั้น","userlevelidinteger":"รหัสระดับของผู้ใช้ต้องเป็นเลขจำนวนเต็ม","userleveldefaultname":"ชื่อระดับของผู้ใช้สำหรับระดับ 0 ต้องเป็น 'default' เท่านั้น","userlevelidincorrect":"ขอบเขตของรหัสระดับผู้ใช้ต้องมากกว่า 0","userlevelnameincorrect":"ขอบเขตของชื่อระดับของผู้ใช้ต้องไม่ใช่ 'administrator' หรือ 'default'","wrongfiletype":"ไม่สามารถใช้ไฟล์ชนิดนี้ได้"});
//-->
</script>
<script language="javascript" type="text/javascript">
<!--

// write your client script here, no need to add script tags.
//-->

</script>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="generator" content="phpmaker v8.0.2">
</head>
<body class="yui-skin-sam">
<div class="ewlayout">
	<!-- header (begin) --><!-- *** note: only licensed users are allowed to change the logo *** -->
  <div class="ewheaderrow"><img src="phpimages/bg_blank.jpg" alt="" border="0"></div>
	<!-- header (end) -->
<div class="ewmenurow">
<!-- begin main menu -->
<div class="phpmaker">
<div id="rootmenu" class="yuimenubar yuimenubarnav"><div class="bd first-of-type">
<ul  class="first-of-type">
<li class="yuimenubaritem first-of-type"><a class="yuimenubaritemlabel" href="tb_journallist.php">รายชื่อวารสาร</a></li>
<li class="yuimenubaritem"><a class="yuimenubaritemlabel" href="login.php">เข้าสู่ระบบ</a></li>
</ul>
</div></div>
</div>
<!-- end main menu -->
<script type="text/javascript">
<!--

// init the menu
var rootmenu = new yahoo.widget.menubar("rootmenu", { autosubmenudisplay: true, hidedelay: 750, lazyload: true });
rootmenu.render();        

//-->
</script>
</div>
	<!-- content (begin) -->
  <table cellspacing="0" class="ewcontenttable">
		<tr>
	    <td class="ewcontentcolumn">
			<!-- right column (begin) -->
				<p class="phpmaker ewtitle"><b>รายชื่อวารสารที่ใช้เป็นเกณฑ์การสำเร็จการศึกษา ระดับปริญญาโท และปริญญาเอก สาขาเทคโนโลยีชีวภาพเกษตร</b></p>
<script type="text/javascript">
<!--

// create page object
var tb_journal_search = new ew_page("tb_journal_search");

// page properties
tb_journal_search.pageid = "search"; // page id
tb_journal_search.formid = "ftb_journalsearch"; // form id
var ew_page_id = tb_journal_search.pageid; // for backward compatibility

// extend page with validate function for search
tb_journal_search.validatesearch = function(fobj) {
	ew_postautosuggest(fobj);
	if (this.validaterequired) {
		var infix = "";

		// call form custom validate event
		if (!this.form_customvalidate(fobj))
			return false;
	}
	for (var i=0; i<fobj.elements.length; i++) {
		var elem = fobj.elements[i];
		if (elem.name.substring(0,2) == "s_" || elem.name.substring(0,3) == "sv_")
			elem.value = "";
	}
	return true;
}

// extend page with form_customvalidate function
tb_journal_search.form_customvalidate =  
 function(fobj) { // do not change this line!

 	// your custom validation code here, return false if invalid. 
 	return true;
 }
tb_journal_search.validaterequired = true; // uses javascript validation

//-->
</script>
<script type="text/javascript">
<!--
var ew_dhtmleditors = [];

//-->
</script>
<script language="javascript" type="text/javascript">
<!--

// write your client script here, no need to add script tags.
//-->

</script>
<p class="phpmaker ewtitle">ค้นหา&nbsp;  </p>
<p class="phpmaker"><a href="tb_journallist.php">กลับไปหน้ารายการ</a></p>
<p class="ewerrormessage">failed to connect to db_journal at 158.108.144.4. error: unknown database 'db_journal'</p><form name="ftb_journalsearch" id="ftb_journalsearch" action="tb_journalsrch.php" method="post" onsubmit="return tb_journal_search.validatesearch(this);">
<p>
<input type="hidden" name="t" id="t" value="tb_journal">
<input type="hidden" name="a_search" id="a_search" value="s">
<table cellspacing="0" class="ewgrid"><tr><td class="ewgridcontent">
<div class="ewgridmiddlepanel">
<table cellspacing="0" class="ewtable">
	<tr id="r_journal_name">
		<td class="ewtableheader">ชื่อวารสาร</td>
		<td class="ewsearchoprcell">ประกอบด้วย<input type="hidden" name="z_journal_name" id="z_journal_name" value="like"></td>
		<td>
			<div style="white-space: nowrap;">
				<span class="phpmaker">
<textarea name="x_journal_name" id="x_journal_name" cols="70" rows="4"></textarea>
</span>
			</div>
		</td>
	</tr>
	<tr id="r_journal_type">
		<td class="ewtableheader">ประเภท</td>
		<td class="ewsearchoprcell">=<input type="hidden" name="z_journal_type" id="z_journal_type" value="="></td>
		<td>
			<div style="white-space: nowrap;">
				<span class="phpmaker">
<div id="tp_x_journal_type" class="ewtemplate"><label><input type="radio" name="x_journal_type" id="x_journal_type" value="{value}"></label></div>
<div id="dsl_x_journal_type" data-repeatcolumn="5" class="ewitemlist">
</div>
<input type="hidden" name="s_x_journal_type" id="s_x_journal_type" value="ncbqss9q0wujk_6fhmcztfqww9x73zxnwtj2wiaczdpn6upx_0n84f4qsxmtbgpgay8tx4lozvbion2mhge9scad5qjn2ddse6sbyhabjw_l5sgnkgwfqyg5wv-ptsuedufcqxmg75pcokuyyciqd9hogdm.">
<input type="hidden" name="lft_x_journal_type" id="lft_x_journal_type" value="">
</span>
			</div>
		</td>
	</tr>
	<tr id="r_in_db">
		<td class="ewtableheader">อยู่ในฐานข้อมูล</td>
		<td class="ewsearchoprcell">ประกอบด้วย<input type="hidden" name="z_in_db" id="z_in_db" value="like"></td>
		<td>
			<div style="white-space: nowrap;">
				<span class="phpmaker">
<input type="text" name="x_in_db" id="x_in_db" size="30" maxlength="50" value="">
</span>
			</div>
		</td>
	</tr>
</table>
</div>
</td></tr></table>
<p>
<input type="submit" name="action" id="action" value="ค้นหา">
<input type="button" name="reset" id="reset" value="ยกเลิก" onclick="ew_clearform(this.form);">
</form>
<script language="javascript" type="text/javascript">
<!--
ew_updateopts([['x_journal_type','x_journal_type',false]]);

//-->
</script>
<script language="javascript" type="text/javascript">
<!--

// write your table-specific startup script here
// document.write("page loaded");
//-->

</script>
				<p>&nbsp;</p>			
			<!-- right column (end) -->
				    </td>	
		</tr>
	</table>
	<!-- content (end) -->	
	<!-- footer (begin) --><!-- *** note: only licensed users are allowed to remove or change the following copyright statement. *** -->
	<div class="ewfooterrow">	
		<div class="ewfootertext">&nbsp;center for agricultural biotechnology (cab)</div>
		<!-- place other links, for example, disclaimer, here -->		
	</div>
	<!-- footer (end) -->	
</div>
<div class="yui-tt" id="ewtooltipdiv" style="visibility: hidden; border: 0px;" name="ewtooltipdivdiv"></div>
<script type="text/javascript">
<!--
ewdom.getelementsbyclassname(ew_table_class, "table", null, ew_setuptable); // init the table
ewdom.getelementsbyclassname(ew_grid_class, "table", null, ew_setupgrid); // init grids
ew_inittooltipdiv(); // init tooltip div

//-->
</script>
<script language="javascript" type="text/javascript">
<!--

// write your global startup script here
// document.write("page loaded");
//-->

</script>
</body>
</html>
