<!doctype html public "-//w3c//dtd xhtml 1.0 transitional//en" "http://www.w3.org/tr/xhtml1/dtd/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv='x-ua-compatible' content='ie=emulateie7' />
<title>กองบริการการศึกษา</title>
<script type='text/javascript' src='script.js'></script>

<script language=javascript>
function exconfirm()
	{
	  if (confirm("are you sure !!! "))
	  {
	  } else {
	  	history.go(0);
	  }
	}
</script>
    <link rel='stylesheet' href='style.css' type='text/css' media='screen' />
    <!--[if ie 6]><link rel='stylesheet' href='style.ie6.css' type='text/css' media='screen' /><![endif]-->
    <!--[if ie 7]><link rel='stylesheet' href='style.ie7.css' type='text/css' media='screen' /><![endif]-->
</head>
<body>
<div id='art-page-background-simple-gradient'>
    </div>
    <div id='art-main'>
        <div class='art-sheet'>
            <div class='art-sheet-tl'></div>
            <div class='art-sheet-tr'></div>
            <div class='art-sheet-bl'></div>
            <div class='art-sheet-br'></div>
            <div class='art-sheet-tc'></div>
            <div class='art-sheet-bc'></div>
            <div class='art-sheet-cl'></div>
            <div class='art-sheet-cr'></div>
            <div class='art-sheet-cc'></div>
            <div class='art-sheet-body'>
                <div class='art-header'>
                    <div class='art-header-jpeg'></div>
                    <div class='art-logo'>
                        <h1 id='name-text' class='art-logo-name'><a href='#'></a></h1>
                        <div id='slogan-text' class='art-logo-text'></div>
                    </div>
                </div>
				
				
				<span class="art-show-text">ขั้นตอนการสมัครสมาชิก</span>
                <div class='art-contentlayout'>
					<ul><h5><a href="manual_user1.doc">ขั้นตอนที่ 1 <img src=images/iconword.jpg /></a> ลงทะเบียนสมัครสมาชิก
	เพื่อให้ผู้เสนอผลงานวิจัยได้รับสิทธิในการใช้ระบบ โดยบันทึกข้อมูลส่วนตัวให้สมบูรณ์และถูกต้อง ระบบจะออกบัญชีผู้ใช้ให้โดยอัตโนมัติ และแจ้งไปยังผู้สมัครผ่านทางอีเมลที่ได้ระบุไว้ สมาชิกสามารถใช้ชื่อและรหัสผ่านในการติดต่อกับระบบได้ในลำดับต่อไป 
<p><a href="manual_user2.doc">ขั้นตอนที่ 2 <img src=images/iconword.jpg /></a> ส่งผลงาน
	เพื่ออัพโหลดไฟล์ผลงาน และบันทึกข้อมูลรายละเอียดของผลงานผ่านระบบ  (รูปแบบเอกสารของผลงานต้องเป็นไปตามมาตรฐานที่กำหนด)
<p><a href="manual_user3.doc">ขั้นตอนที่ 3 <img src=images/iconword.jpg /></a> ติดตามสถานภาพของผลงาน (ผลการพิจารณา)</p>
				  </h5></ul>
<center><a href=manual_user.doc></a>
</center>
<p align="center"><input  type="button" id="submit" value="กลับหน้าหลัก" onclick="location.href='index.php'"></p>

 
              </div>

                <div class='cleared'></div><div class='art-footer'>
                    <div class='art-footer-inner'>
                        <a href='#' class='art-rss-tag-icon' title='rss'></a>
                        <div class='art-footer-text'>
                            <p><a href='#'>contact us</a> | <a href='#'>terms of use</a> | <a href='#'>trademarks</a>
                                | <a href='#'>privacy statement</a><br />
                                copyright ๏ฟฝ 2009 ---. all rights reserved.</p>
                        </div>
                    </div>
                    <div class='art-footer-background'></div>
                </div>
            </div>
        </div>
        <div class='cleared'></div>
        																																																																														<p class='art-page-footer'>created with <a href='http://webbuildinginfo.com/'>how to build website</a> and <a href='http://photozzle.com'>photographers directory</a>.</p>
    </div>
    
<!-- <div style='text-align: center; font-size: 0.75em;'>design downloaded from <a href='http://www.freewebtemplates.com/'>free website templates</a>.</div></body> --></body><!-- </body> -->
</html>


