<!doctype html public "-//w3c//dtd xhtml 1.0 transitional//en" "http://www.w3.org/tr/xhtml1/dtd/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />

<title>à¸£à¸²à¸¢à¸à¸·à¹à¸­à¸à¸¹à¹à¹à¸à¹à¸à¸«à¸à¸±à¸à¸ªà¸·à¸­</title>
<link rel="stylesheet" href="http://ag-ebook.lib.ku.ac.th/templates/yoo_air/css/template.css" type="text/css" />
<link rel="stylesheet" href="http://ag-ebook.lib.ku.ac.th/templates/yoo_air/css/styles/green.css" type="text/css" />
<link rel="stylesheet" href="http://ag-ebook.lib.ku.ac.th/templates/yoo_air/css/custom.css" type="text/css" />
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=lobster" type="text/css" />
</head>

<body id="page" bgcolor="ffffdc" onload="document.body.style.overflow='hidden'">

<div class="item">
<h1 class="title" >à¸à¸±à¸à¸à¸¶à¸à¸à¸­à¸à¹à¸à¹à¸à¸à¸´à¸ à¹: à¸«à¸à¹à¸² à¸¢à¸² à¸ªà¸¡à¸¸à¸à¹à¸à¸£ à¹à¸à¸¥à¹à¸à¸±à¸§</h1>
<div id="system" class="">		
<br />				
<div class="content"><p style="text-align: center;"><a href="http://ag-ebook.lib.ku.ac.th/index.php?view=weblink&catid=37&id=1&option=com_weblinks" target="_blank"><img src="cover/2010-000-0001.png" border="0" width="150" height="150" style="box-shadow: 0px 0px 10px 4px rgba(119, 119, 119, 0.75);" /></a><br /><br /><span style="color:#00f">(à¸à¸¥à¸´à¸à¸à¸µà¹à¸à¸à¹à¸à¸·à¹à¸­à¹à¸à¸´à¸à¸«à¸à¸±à¸à¸ªà¸·à¸­à¸­à¸´à¹à¸¥à¹à¸à¸à¸£à¸­à¸à¸´à¸à¸ªà¹)</span></p>

<table border="0" cellspacing="0" cellpadding="0" width="90%" align="center">
<tbody>
<tr height="30">
<td width="28%" align="right" valign="top">à¸à¸·à¹à¸­à¹à¸£à¸·à¹à¸­à¸</td><td width="2%" align="center" valign="top">:</td><td width="60%" valign="top">à¸à¸±à¸à¸à¸¶à¸à¸à¸­à¸à¹à¸à¹à¸à¸à¸´à¸ à¹: à¸«à¸à¹à¸² à¸¢à¸² à¸ªà¸¡à¸¸à¸à¹à¸à¸£ à¹à¸à¸¥à¹à¸à¸±à¸§</td></tr>

<tr height="30"><td align="right" valign="top">à¸à¸µà¸à¸µà¹à¸à¸±à¸à¸à¸´à¸¡à¸à¹</td><td align="center" valign="top">:</td><td valign="top">2551</td></tr><tr height="30"><td align="right" valign="top">isbn</td><td align="center" valign="top">:</td><td valign="top">978-974-451-938-2</td></tr><tr height="30"><td align="right" valign="top">à¸à¸·à¹à¸­à¸à¸¹à¹à¹à¸à¹à¸</td><td align="center" valign="top">:</td><td valign="top">à¸ªà¸¸à¸ à¸²à¸ à¸£à¸à¹ à¸à¸´à¸à¸´à¸à¸£</td></tr><tr height="30"><td align="right" valign="top">à¸à¸£à¸£à¸à¸²à¸à¸´à¸à¸²à¸£</td><td align="center" valign="top">:</td><td valign="top">à¸ªà¸¸à¸ à¸²à¸ à¸£à¸à¹ à¸à¸´à¸à¸´à¸à¸£</td></tr><tr height="30"><td align="right" valign="top">à¸à¸³à¸à¸§à¸à¸«à¸à¹à¸²</td><td align="center" valign="top">:</td><td valign="top">118&nbsp;&nbsp;à¸«à¸à¹à¸²</td></tr><tr height="30"><td align="right" valign="top">à¸«à¸à¹à¸§à¸¢à¸à¸²à¸à¸à¸±à¸à¸à¸´à¸¡à¸à¹</td><td align="center" valign="top">:</td><td valign="top">à¸¡à¸¹à¸¥à¸à¸´à¸à¸´à¹à¸£à¸à¸à¸¢à¸²à¸à¸²à¸¥à¹à¸à¹à¸²à¸à¸£à¸°à¸¢à¸²à¸­à¸ à¸±à¸¢à¹à¸à¸¨à¸£</td></tr><tr height="30"><td align="right" valign="top">à¸à¸³à¸ªà¸³à¸à¸±à¸</td><td align="center" valign="top">:</td><td valign="top">à¸ªà¸¡à¸¸à¸à¹à¸à¸£;à¸à¸£à¸à¸à¹à¸³;à¸à¸°à¹à¸¡à¹à¸;à¸à¸£à¸­à¸à¸à¸±à¸à¸ªà¸µ;à¹à¸à¸£à¸·à¸­à¸«à¸¡à¸²à¸à¹à¸­à¸¢;à¹à¸à¸à¸à¸£à¸°à¸­à¸­à¸¡;à¹à¸à¸·à¸­à¸¢;à¹à¸à¹à¹à¸¡à¹à¸£à¸¹à¹à¸¥à¹à¸¡;à¸à¸¥à¸²à¹à¸«à¸¥à¹à¸à¸·à¸­à¸;à¸à¸±à¸à¸à¸°à¸ªà¸±à¸;à¸à¸±à¸à¸à¸²à¸à¸à¹à¸³;à¸à¸±à¸à¸à¸£à¸²à¸à¸«à¸±à¸§à¹à¸«à¸§à¸;à¸à¸±à¸à¸à¸²à¹à¸à¹à¸;à¸£à¸²à¸à¸ªà¸²à¸¡à¸ªà¸´à¸;à¸¥à¸¹à¸à¹à¸à¹à¹à¸;à¸§à¹à¸²à¸à¸«à¸­à¸¡;à¸§à¹à¸²à¸à¸«à¸­à¸¡à¹à¸à¸;à¸«à¸à¹à¸²à¸à¸­à¸à¸à¸¥à¹à¸­à¸;à¸«à¸à¹à¸²à¸à¸±à¸à¸à¸¹à¸à¸²à¸§;à¸«à¸à¸²à¸;à¸­à¹à¸²à¸«à¸¥à¸§à¸;à¹à¸­à¸·à¹à¸­à¸à¸«à¸¡à¸²à¸¢à¸à¸²;à¸ªà¸£à¸£à¸à¸à¸¸à¸à¸à¸²à¸à¸¢à¸²;à¸à¸²à¸£à¹à¸à¹à¸¢à¸²à¸ªà¸¡à¸¸à¸à¹à¸à¸£;à¸­à¸²à¸«à¸²à¸£;à¸à¸²à¸£à¸£à¸±à¸à¸©à¸²à¹à¸£à¸;à¸ªà¸²à¸£à¸ªà¸à¸±à¸;à¸à¸²à¸£à¹à¸à¹à¸à¸£à¸°à¹à¸¢à¸à¸à¹;à¸à¸§à¸²à¸¡à¹à¸à¹à¸à¸à¸´à¸©;à¸à¸³à¸£à¸±à¸à¸¢à¸²</td></tr><tr height="30"><td align="right" valign="top">à¸à¸³à¸à¸§à¸à¸à¸²à¸£à¹à¸à¸´à¸à¸­à¹à¸²à¸</td><td align="center" valign="top">:</td><td valign="top">2,616 à¸à¸£à¸±à¹à¸</td></tr><!--
<tr height="30"><td align="right" valign="top">à¸à¸³à¸ªà¸³à¸à¸±à¸</td><td align="center" valign="top">:</td><td valign="top">à¸ªà¸¡à¸¸à¸à¹à¸à¸£;à¸à¸£à¸à¸à¹à¸³;à¸à¸°à¹à¸¡à¹à¸;à¸à¸£à¸­à¸à¸à¸±à¸à¸ªà¸µ;à¹à¸à¸£à¸·à¸­à¸«à¸¡à¸²à¸à¹à¸­à¸¢;à¹à¸à¸à¸à¸£à¸°à¸­à¸­à¸¡;à¹à¸à¸·à¸­à¸¢;à¹à¸à¹à¹à¸¡à¹à¸£à¸¹à¹à¸¥à¹à¸¡;à¸à¸¥à¸²à¹à¸«à¸¥à¹à¸à¸·à¸­à¸;à¸à¸±à¸à¸à¸°à¸ªà¸±à¸;à¸à¸±à¸à¸à¸²à¸à¸à¹à¸³;à¸à¸±à¸à¸à¸£à¸²à¸à¸«à¸±à¸§à¹à¸«à¸§à¸;à¸à¸±à¸à¸à¸²à¹à¸à¹à¸;à¸£à¸²à¸à¸ªà¸²à¸¡à¸ªà¸´à¸;à¸¥à¸¹à¸à¹à¸à¹à¹à¸;à¸§à¹à¸²à¸à¸«à¸­à¸¡;à¸§à¹à¸²à¸à¸«à¸­à¸¡à¹à¸à¸;à¸«à¸à¹à¸²à¸à¸­à¸à¸à¸¥à¹à¸­à¸;à¸«à¸à¹à¸²à¸à¸±à¸à¸à¸¹à¸à¸²à¸§;à¸«à¸à¸²à¸;à¸­à¹à¸²à¸«à¸¥à¸§à¸;à¹à¸­à¸·à¹à¸­à¸à¸«à¸¡à¸²à¸¢à¸à¸²;à¸ªà¸£à¸£à¸à¸à¸¸à¸à¸à¸²à¸à¸¢à¸²;à¸à¸²à¸£à¹à¸à¹à¸¢à¸²à¸ªà¸¡à¸¸à¸à¹à¸à¸£;à¸­à¸²à¸«à¸²à¸£;à¸à¸²à¸£à¸£à¸±à¸à¸©à¸²à¹à¸£à¸;à¸ªà¸²à¸£à¸ªà¸à¸±à¸;à¸à¸²à¸£à¹à¸à¹à¸à¸£à¸°à¹à¸¢à¸à¸à¹;à¸à¸§à¸²à¸¡à¹à¸à¹à¸à¸à¸´à¸©;à¸à¸³à¸£à¸±à¸à¸¢à¸²</td></tr>
-->

</tbody>
</table>

<br />

<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr><td align="right" valign="middle">
<span style="color:#263679">à¸à¹à¸²à¸à¹à¸²à¸à¸à¸­à¸à¸«à¸à¸±à¸à¸ªà¸·à¸­à¹à¸¥à¹à¸¡à¸à¸µà¹ à¹à¸à¸£à¸à¸à¸</span>&nbsp;</td>
<td align="left" valign="middle" width="50">
<a href="vote.php?url=http://ag-ebook.lib.ku.ac.th/ebooks/item.php&book_id=2010-000-0001"><img src="image/like-buton.png" height="40" /></a></td></tr>
</table>
</div>
</div></div>						
									
</body>
</html>