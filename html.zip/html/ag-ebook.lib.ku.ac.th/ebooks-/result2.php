<!doctype html public "-//w3c//dtd xhtml 1.0 transitional//en" "http://www.w3.org/tr/xhtml1/dtd/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>à¸£à¸²à¸¢à¸à¸·à¹à¸­à¸«à¸à¸±à¸à¸ªà¸·à¸­à¸à¸²à¸¡à¸«à¸¡à¸§à¸</title>
<link rel="stylesheet" href="http://ag-ebook.lib.ku.ac.th/templates/yoo_air/css/template.css" type="text/css" />
<link rel="stylesheet" href="http://ag-ebook.lib.ku.ac.th/templates/yoo_air/css/styles/green.css" type="text/css" />
<link rel="stylesheet" href="http://ag-ebook.lib.ku.ac.th/templates/yoo_air/css/custom.css" type="text/css" />
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=lobster" type="text/css" />
<script type="text/javascript" src="scripts/jquery.js"></script>
<script type="text/javascript">
 function popo() {
   
	   $("#popo").fadein(1500);

 }
</script>
</head>

<body bgcolor="ffffdc" onload="popo()">





<h1 class="title"><a href="browsesub.php" title="">à¸£à¸²à¸¢à¸à¸·à¹à¸­à¸«à¸à¸±à¸à¸ªà¸·à¸­à¸à¸²à¸¡à¸«à¸¡à¸§à¸</a><span style="color:#333; font-style:italic;">&nbsp;|&nbsp;à¸à¸£à¸°à¸à¸²à¸à¸ªà¸¡à¹à¸à¹à¸à¸à¸£à¸°à¹à¸à¹à¸²à¸­à¸¢à¸¹à¹à¸«à¸±à¸§</span></h1>
<div id="system" class="">
<form action="result2.php" name="inform" method="get">
<div align="center">
<input type="text" name="search" value="" size="60" maxlength="150" />&nbsp;&nbsp;
      <input type="image" src="image/kon1.png" title="à¸à¹à¸à¸«à¸²" value="à¸à¹à¸à¸«à¸²" name="advancesearch" align="absbottom">
   &nbsp;|&nbsp; <a href="result2.php?sub="><img src="image/kon2.png" align="absbottom" /></a></div>	
   <input type="hidden" name="sub" value="" />
</form>

<center>
<div class="pagination">
<strong>1</strong><a class="" href="result2.php?p=2" title="2">2</a><a class="" href="result2.php?p=3" title="3">3</a><a class="" href="result2.php?p=4" title="4">4</a><a class="" href="result2.php?p=5" title="5">5</a><a class="" href="result2.php?p=6" title="6">6</a><a class="" href="result2.php?p=7" title="7">7</a><a class="" href="result2.php?p=8" title="8">8</a><a class="" href="result2.php?p=9" title="9">9</a><a class="" href="result2.php?p=10" title="10">10</a><a class="" href="result2.php?p=11" title="11">11</a><a class="next" href="result2.php?p=2" title="â»">â»</a><a class="last" href="result2.php?p=83" title="à¸ªà¸¸à¸à¸à¹à¸²à¸¢">à¸ªà¸¸à¸à¸à¹à¸²à¸¢</a>

</div></center>
	
	<div class="filter">
<table class="zebra"  width="90%" border="0" cellspacing="0" cellpadding="0">
<thead>
<tr height="30"><th align="right" width="5%">#</th>
<th align="left">
<a href="result2.php?p=1&sub=&sort=title2 desc"><img src="image/sort_asc.png" />&nbsp;à¸à¸·à¹à¸­à¸«à¸à¸±à¸à¸ªà¸·à¸­</a>
(à¸à¸ 1,658 à¸£à¸²à¸¢à¸à¸²à¸£ à¹à¸ªà¸à¸à¸£à¸²à¸¢à¸à¸²à¸£à¸à¸µà¹ 1-20)</th>
<th align="center" width="10%">
<a href="result2.php?p=1&sort=issue desc">à¸à¸µà¸à¸´à¸¡à¸à¹<br>(à¸.à¸¨.)</a></th>
<th align="center" width="10%">
<a href="result2.php?p=1&sort=hits desc">à¸à¸³à¸à¸§à¸à¸à¸²à¸£à¸­à¹à¸²à¸(à¸à¸£à¸±à¹à¸)</a></th>
</tr></thead>
<tbody id="popo" style="display:none;">
<tr class="odd"><td align="right">1</td><td><a href="item.php?id=2011-015-0037">"à¸à¸­à¸¡" à¸à¸­à¸¡à¸¢à¸¸à¹à¸ à¸à¸£à¸°à¸à¸´à¸à¸à¸à¹à¸ªà¸¡à¹à¸à¹à¸à¸à¸£à¸°à¹à¸à¹à¸²à¸¥à¸¹à¸à¹à¸à¸­ à¹à¸à¹à¸²à¸à¹à¸²à¸à¸¸à¸¬à¸²à¸ à¸£à¸à¸§à¸¥à¸±à¸¢à¸¥à¸±à¸à¸©à¸à¹: à¹à¸£à¸·à¹à¸­à¸à¸à¹à¸²à¸£à¸¹à¹à¹à¸à¸µà¹à¸¢à¸§à¸à¸±à¸à¸à¸¥à¸²à¸à¸­à¸¡à¸à¸²à¸à¸±à¸§à¸£à¹</a></td><td align="center">2531</td><td align="center">1,033</td></tr><tr class="even"><td align="right">2</td><td><a href="item.php?id=2011-015-0036">(à¹à¸¡à¸·à¹à¸­à¸à¸¥à¸²) à¹à¸à¸§à¸à¸²à¸à¸à¸ªà¸§à¸£à¸£à¸à¹ à¸à¸£à¸°à¸à¸´à¸à¸à¸à¹à¸ªà¸¡à¹à¸à¹à¸à¸à¸£à¸°à¹à¸à¹à¸²à¸¥à¸¹à¸à¹à¸à¸­ à¹à¸à¹à¸²à¸à¹à¸²à¸à¸¸à¸¬à¸²à¸ à¸£à¸à¸§à¸¥à¸±à¸¢à¸¥à¸±à¸à¸©à¸à¹: à¸à¸²à¸£à¹à¸à¸²à¸°à¹à¸¥à¸µà¹à¸¢à¸à¸à¸¥à¸²à¹à¸à¸§à¸à¸² à¸à¸¹à¹à¸¡à¸·à¸­à¸à¸²à¸£à¹à¸¥à¸µà¹à¸¢à¸à¸à¸¥à¸²à¸à¸¹à¹à¸à¹à¸³à¸à¸·à¸</a></td><td align="center">2530</td><td align="center">730</td></tr><tr class="odd"><td align="right">3</td><td><a href="item.php?id=2010-000-0004">10 à¸¡à¸«à¸±à¸¨à¸à¸£à¸£à¸¢à¹ à¸à¸¥à¸±à¸à¸à¸²à¸à¸à¸à¹à¸à¸ à¸à¸¹à¹à¸§à¸´à¸à¸¤à¸à¹à¸¥à¸à¸£à¹à¸­à¸</a></td><td align="center">2550</td><td align="center">2,314</td></tr><tr class="even"><td align="right">4</td><td><a href="item.php?id=2011-000-0001">117 à¸­à¸²à¸à¸µà¸à¹à¸à¸©à¸à¸£à¸à¸£à¸£à¸¡à¸à¸²à¸à¹à¸¥à¸·à¸­à¸ à¹à¸à¸·à¹à¸­à¸£à¸­à¸à¸£à¸±à¸à¸§à¸´à¸à¸¤à¸à¸´à¹à¸¨à¸£à¸©à¸à¸à¸´à¸à¹à¸¥à¸°à¹à¸à¹à¹à¸à¸à¸±à¸à¸«à¸²à¸à¸²à¸£à¸§à¹à¸²à¸à¸à¸²à¸</a></td><td align="center">2552</td><td align="center">3,400</td></tr><tr class="odd"><td align="right">5</td><td><a href="item.php?id=2011-002-0343">20 à¸à¸µ à¹à¸«à¹à¸à¸à¸²à¸£à¸à¸¸à¸à¹à¸à¸´à¸à¸à¸±à¸à¸à¸²à¸à¸·à¹à¸à¸à¸µà¹à¸ªà¸¹à¸à¸ à¸²à¸à¹à¸«à¸à¸·à¸­à¸à¸­à¸à¸à¸£à¸°à¹à¸à¸¨à¹à¸à¸¢</a></td><td align="center">2537</td><td align="center">349</td></tr><tr class="even"><td align="right">6</td><td><a href="item.php?id=20160210">30 à¸à¸µ à¸à¸§à¸²à¸¡à¸£à¹à¸§à¸¡à¸¡à¸·à¸­à¸à¸²à¸à¸§à¸´à¸à¸²à¸à¸²à¸£à¹à¸à¸©à¸à¸£à¸£à¸°à¸«à¸§à¹à¸²à¸à¸¡à¸¹à¸¥à¸à¸´à¸à¸´à¹à¸à¸£à¸à¸à¸²à¸£à¸«à¸¥à¸§à¸à¹à¸¥à¸°à¹à¸à¹à¸«à¸§à¸±à¸ (1972-2002)</a></td><td align="center">2545</td><td align="center">117</td></tr><tr class="odd"><td align="right">7</td><td><a href="item.php?id=20160206">30 à¸à¸µ à¸à¹à¸²à¸¢à¸²à¸à¹à¸à¸ªà¸§à¸à¸à¸´à¸à¸£à¸¥à¸à¸²</a></td><td align="center">2534</td><td align="center">104</td></tr><tr class="even"><td align="right">8</td><td><a href="item.php?id=2011-022-0001">34 à¸à¸µ à¸ªà¸·à¸à¸ªà¸²à¸à¸à¸£à¸°à¸£à¸²à¸à¸à¸à¸´à¸à¸²à¸à¸à¸¸à¹à¸¡à¸à¸£à¸­à¸à¸à¸µà¹à¸à¸´à¸à¹à¸à¸·à¹à¸­à¹à¸à¸©à¸à¸£à¸à¸£à¸£à¸¡</a></td><td align="center">2552</td><td align="center">1,408</td></tr><tr class="odd"><td align="right">9</td><td><a href="item.php?id=2011-002-0257">35 à¸à¸³à¸à¸²à¸¡à¸à¸±à¸à¸à¸²à¸£à¸à¸¥à¸¹à¸à¸¡à¸±à¸à¸à¸¸à¸: à¹à¸­à¸à¸ªà¸²à¸£à¹à¸à¸¢à¹à¸à¸£à¹à¸­à¸±à¸à¸à¸±à¸à¸à¸µà¹ 53</a></td><td align="center">2536</td><td align="center">548</td></tr><tr class="even"><td align="right">10</td><td><a href="item.php?id=20130080">36 à¸à¸µ à¹à¸à¸£à¸·à¹à¸­à¸à¸à¸±à¸à¸£à¸à¸¥à¹à¸à¸©à¸à¸£</a></td><td align="center">2552</td><td align="center">1,051</td></tr><tr class="odd"><td align="right">11</td><td><a href="item.php?id=20150165">36 à¸à¸µ à¸¡à¸¹à¸¥à¸à¸´à¸à¸´à¹à¸à¸£à¸à¸à¸²à¸£à¸«à¸¥à¸§à¸à¸à¸±à¸à¸¡à¸«à¸²à¸§à¸´à¸à¸¢à¸²à¸¥à¸±à¸¢à¹à¸à¸©à¸à¸£à¸¨à¸²à¸ªà¸à¸£à¹ à¸.à¸¨. 2548</a></td><td align="center">à¹à¸¡à¹à¸à¸£à¸²à¸à¸</td><td align="center">10,981</td></tr><tr class="even"><td align="right">12</td><td><a href="item.php?id=20160208">60 à¸à¸µ à¸à¸à¸°à¸ªà¸±à¸à¸§à¹à¸à¸à¸¢à¸¨à¸²à¸ªà¸à¸£à¹ à¸¡à¸«à¸²à¸§à¸´à¸à¸¢à¸²à¸¥à¸±à¸¢à¹à¸à¸©à¸à¸£à¸¨à¸²à¸ªà¸à¸£à¹ à¸.à¸¨.2497-2557 à¸ªà¸±à¸à¸§à¹à¸à¸à¸¢à¹à¹à¸à¸©à¸à¸£ : à¸ªà¸±à¸à¸§à¹à¸à¸à¸¢à¹à¸à¸­à¸à¸à¸£à¸°à¸à¸²à¸à¸</a></td><td align="center">2557</td><td align="center">101</td></tr><tr class="odd"><td align="right">13</td><td><a href="item.php?id=20140120">60 à¸à¸µ à¸à¸¹à¹à¸¨à¸¶à¸à¸©à¸²à¸à¹à¸à¸à¸§à¹à¸²à¸à¸±à¸ 424 à¸à¸µ à¹à¸à¹à¸à¸à¸à¸£à¸°à¸à¹à¸£à¸¨à¸§à¸£</a></td><td align="center">2545</td><td align="center">196</td></tr><tr class="even"><td align="right">14</td><td><a href="item.php?id=20150147">72 à¸à¸µ à¹à¸à¸©à¸à¸£à¸¨à¸²à¸ªà¸à¸£à¹ à¸à¸´à¸à¸±à¸à¸à¹à¹à¸à¹à¸à¸à¸´à¸à¹à¸à¸¢: à¸à¸à¸±à¸à¸à¸´à¹à¸¨à¸©à¸à¸´à¸¡à¸à¹à¹à¸à¸¢à¹à¸à¸£à¹à¹à¸à¸à¸²à¸à¸à¸´à¸à¸µà¸à¸£à¸°à¸£à¸²à¸à¸à¸²à¸à¸à¸£à¸´à¸à¸à¸²à¸à¸±à¸à¸£à¸¡à¸«à¸²à¸§à¸´à¸à¸¢à¸²à¸¥à¸±à¸¢à¹à¸à¸©à¸à¸£à¸¨à¸²à¸ªà¸à¸£à¹ à¸.à¸¨. 2558</a></td><td align="center">2558</td><td align="center">5,817</td></tr><tr class="odd"><td align="right">15</td><td><a href="item.php?id=20150073">72 à¸à¸µ à¹à¸à¸©à¸à¸£à¸¨à¸²à¸ªà¸à¸£à¹ à¸à¸´à¸à¸±à¸à¸à¹à¹à¸à¹à¸à¸à¸´à¸à¹à¸à¸¢: à¸«à¸à¸±à¸à¸ªà¸·à¸­à¸à¸µà¹à¸£à¸°à¸¥à¸¶à¸à¹à¸à¸§à¸²à¸£à¸°à¸à¸£à¸à¸£à¸­à¸ 72 à¸à¸µ à¹à¸«à¹à¸à¸à¸²à¸£à¸ªà¸à¸²à¸à¸à¸²à¸¡à¸«à¸²à¸§à¸´à¸à¸¢à¸²à¸¥à¸±à¸¢à¹à¸à¸©à¸à¸£à¸¨à¸²à¸ªà¸à¸£à¹ (à¸.à¸¨. 2486 - 2558) à¸à¸±à¸à¸à¸²à¸à¸²à¸£à¹à¸¥à¸°à¹à¸à¸µà¸¢à¸£à¸à¸´à¸ à¸¹à¸¡à¸´à¹à¸«à¹à¸à¸¡à¸«à¸²à¸§à¸´à¸à¸¢à¸²à¸¥à¸±à¸¢</a></td><td align="center">2558</td><td align="center">1,850</td></tr><tr class="even"><td align="right">16</td><td><a href="item.php?id=20160046">8 à¸à¸¨à¸§à¸£à¸£à¸© à¸§à¸à¸¨à¸²à¸ªà¸à¸£à¹ à¸¨à¸²à¸ªà¸à¸£à¹à¹à¸«à¹à¸à¸à¸µà¸§à¸´à¸</a></td><td align="center">2559</td><td align="center">154</td></tr><tr class="odd"><td align="right">17</td><td><a href="item.php?id=2011-005-0112">80 à¸à¸£à¸£à¸©à¸² 80 à¸­à¸²à¸à¸µà¸à¸à¸µà¹à¸à¹à¸­à¹à¸«à¹à¸à¸²à¸¡à¹à¸à¸§à¹à¸¨à¸£à¸©à¸à¸à¸´à¸à¸à¸­à¹à¸à¸µà¸¢à¸</a></td><td align="center">2550</td><td align="center">1,193</td></tr><tr class="even"><td align="right">18</td><td><a href="item.php?id=20130130">84 à¸à¸£à¸£à¸©à¸² à¸à¸©à¸±à¸à¸£à¸´à¸¢à¹à¹à¸à¸©à¸à¸£</a></td><td align="center">2555</td><td align="center">1,347</td></tr><tr class="odd"><td align="right">19</td><td><a href="item.php?id=20130034">84 à¸ªà¸¹à¸à¸£à¸­à¸²à¸«à¸²à¸£à¸à¹à¸²à¸§à¸à¸¥à¹à¸­à¸ à¹à¸à¸¥à¸´à¸¡à¸à¸£à¸°à¹à¸à¸µà¸¢à¸£à¸à¸´</a></td><td align="center">2554</td><td align="center">405</td></tr><tr class="even"><td align="right">20</td><td><a href="item.php?id=2010-012-0001">9 à¸à¸à¸à¸±à¸à¸à¸¶à¸à¹à¸«à¹à¸à¸­à¹à¸­à¸¢à¹à¸¥à¸°à¸à¹à¸³à¸à¸²à¸¥à¸à¸£à¸²à¸¢à¹à¸à¸¢</a></td><td align="center">2549</td><td align="center">3,717</td></tr>
</tbody>
</table>

<center>
<div class="pagination">
<strong>1</strong><a class="" href="result2.php?p=2" title="2">2</a><a class="" href="result2.php?p=3" title="3">3</a><a class="" href="result2.php?p=4" title="4">4</a><a class="" href="result2.php?p=5" title="5">5</a><a class="" href="result2.php?p=6" title="6">6</a><a class="" href="result2.php?p=7" title="7">7</a><a class="" href="result2.php?p=8" title="8">8</a><a class="" href="result2.php?p=9" title="9">9</a><a class="" href="result2.php?p=10" title="10">10</a><a class="" href="result2.php?p=11" title="11">11</a><a class="next" href="result2.php?p=2" title="â»">â»</a><a class="last" href="result2.php?p=83" title="à¸ªà¸¸à¸à¸à¹à¸²à¸¢">à¸ªà¸¸à¸à¸à¹à¸²à¸¢</a>
</div></center>
</div>	</div>									
</body>
</html>