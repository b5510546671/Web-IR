<html>
<head>
<title>บริการใบรับรองอิเล็กทรอนิกส์ของเครือข่ายนนทรี(nontrinet certificate services)</title>
<meta http-equiv="content-type" content="text/html; charset=windows-874" />
<link href="caweb.css" type=text/css rel=stylesheet>
</head>
<body bgcolor="#ffffff" leftmargin="9" topmargin="10" marginwidth="9" marginheight="18">

<table width="768" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
<tr valign=top><td>
    <!------------------start top table--------------------------------->
    <table  width="768"  border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
    <tr valign=top> 
    <td><img src="images/catop1-p1.jpg" width="90" height="58" border="0" ></td>
    <td><img src="images/catop2-p1.jpg" width="76" height="58" border="0"></td>
    <td><img src="images/catop3-p1.jpg" width="134" height="58" border="0"></td>
    <td><img src="images/catop4-p1.jpg" width="192" height="58" border="0"></td>
    <td><img src="images/catop5-p1.jpg" width="167" height="58" border="0"></td>
    <td><img src="images/catop6-p1.jpg" width="109" height="58" border="0"></td>
    </tr>
    <tr valign=top> 
    <td><img src="images/catop1-p2.jpg" width="90" height="19" border="0"></td>
    <td><a href="index.html"><img src="images/catop12-p2.jpg" width="76" height="19" border="0" name="home"></a></td>
    <td><a href="service.html"><img src="images/catop13-p2.jpg" width="134" height="19" border="0" name="service"></a></td>
    <td><img src="images/catop14-p2.jpg" width="192" height="19" border="0" name="directory"></td>
    <td><a href="guidesanddocs.html"><img src="images/catop15-p2.jpg" width="167" height="19" border="0" name="docs"></a></td>
    <td><a href="contact.html"><img src="images/catop16-p2.jpg" width="109" height="19" border="0" name="contact"></a></td>
    </tr>
    </table>
    <!------------------end top table--------------------------------->           
</td></tr>
 
    <!------------------start bottom table--------------------------------->    
<div align=left>
<tr valign=top><td>
<table width="100%" border="0" cellspacing="5" cellpadding="0" height="415">
    <tr>     
      <!------------begin left column------------------------>
	  <td width="575" valign="top" align="left" height="100%">
	    <table width="575" border="0" cellspacing="0" cellpadding="0" height="100%">
          <tr> 
            <td height="8"></td>
          </tr>
          <tr> 
            <td height="205" valign="top" align="left"> 

        <table width="575" border="0" cellspacing="0" cellpadding="0" height="100%">
            <td height="1" width="1" align="right"><img src="images/spc_gry.gif" width="1" height="1"></td>
            <td height="1" width="575"><img src="images/spc_gry.gif" width="100%" height="1"></td>
            <td height="1" width="10"></td>
          </tr>

          <tr valign="top" align="left"> 
            <td width="1" height="5" align="right" valign="bottom"><img src="images/spc_gry.gif"  width="1" height="21"></td>
            <td height="5" bgcolor="#e1dfdf" align=center class=thcenter>:: เว็บไซต์ให้บริการแบบปลอดภัยบนเครือข่ายนนทรี ::</td>
            <td width="10" height="5"><img src="images/fold_r.gif" width="22" height="21"></td>
          </tr>

          <tr valign="top" align="left"> 
            <td width="1" align="right"><img src="images/spc_gry.gif" width="1" height="100%"></td>
            <td class="tdleft"><br>
<table border="1" bgcolor="#ffffff" bordercolor="#dcd6bb" width="95%">
<tr valign="top" bgcolor="#f5f5f5">
<td class="thleft"><img src="images/orange-icon.gif" border=0 hspace="5">เว็บไซต์เปิดให้บริการแบบเผยแพร่สู่หน่วยงานภายนอก : จำนวน  33 records </td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://acc3d.ku.ac.th">ระบบบัญชี 3 มิติ</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://eassess.ku.ac.th">ระบบประเมินการเรียนการสอน</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://eduinfo.ku.ac.th">ระบบสารสนเทศการศึกษา</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://gradseminar.ku.ac.th">ระบบลงทะเบียนสัมมนาออนไลน์</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://mic.ku.ac.th">ศูนย์บริหารจัดการข้อมูล</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://mis.person.ku.ac.th">ระบบบริหารจัดการบุคลากร</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://portal.ku.ac.th">ระบบ web portal</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://training.cpc.ku.ac.th">โครงการพัฒนาความรู้ความสามารถทางด้านเทคโนโลยีสารสนเทศของอาจารย์มหาวิทยาลัยเกษตรศาสตร์</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://webregis.ku.ac.th">ระบบลงทะเบียนนิสิต วิทยาเขตกำแพงแสน</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://www.icl.ku.ac.th">ระบบกองทุนกู้ยืมที่ผูกกับรายได้ในอนาคต</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://www.regis.ku.ac.th">ระบบลงทะเบียนนิสิต บางเขน</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://pindex.ku.ac.th">ระบบฐานข้อมูลวิทยานิพนธ์</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://voice-to-president.ku.ac.th">เสียงสู่อธิการบดี</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://alumni.ku.ac.th">บริการรหัสบัญชีผู้ใช้นิสิตเก่า</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://course.ku.ac.th">ระบบ m@xlearn</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://emeeting.ku.ac.th">ระบบงานประชุมอิเล็กทรอนิกส์</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://eoffice.ku.ac.th">ระบบงานสำนักงานอัตโนมัติ</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://gradingweb.ku.ac.th">ระบบ grading services system</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://kuwin.ku.ac.th">บริการเครือข่ายไร้สาย kuwin</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://ldap.ku.ac.th">บริการตรวจสอบสิทธิผู้ใช้งานบนเครือข่ายนนทรี(1)</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://ldap2.ku.ac.th">บริการตรวจสอบสิทธิผู้ใช้งานบนเครือข่ายนนทรี(2)</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://maillist.ku.ac.th">บริการเมลลิ่งลิสต์</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://nontri.ku.ac.th">บริการ nontri server tools</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://pirun.ku.ac.th">บริการพื้นที่โฮมเพจส่วนบุคคล</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://smart.ku.ac.th">ระบบลงทะเบียนเพื่อความมั่นคงของเครือข่าย</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://webmail.ku.ac.th">เว็บเมล์(1)</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://webmail2.ku.ac.th">เว็บเมล์(2)</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://www.ku.ac.th">เว็บมหาวิทยาลัยเกษตรศาสตร์</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://www.nisit.ku.ac.th">บริการพื้นที่โฮมเพจชมรมนิสิต</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://info.ku.ac.th">บริการตรวจสอบเวลาการใช้โมเด็ม</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://wsus.ku.ac.th">บริการ windows server update services</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://kits.ku.ac.th">บริการจองเครื่องคอมพิวเตอร์</a></font></td>
</tr>
<tr valign="top" bgcolor="#ffffff">
<td class="tdleft"><font color="#fb7c00"><img src="images/space.gif" border=0 hspace="10"><img src="images/icon-01.gif" border=0 hspace="10"><a href="https://operation.cpc.ku.ac.th">ฝ่ายปฏิบัติการ สำนักบริการคอมพิวเตอร์</a></font></td>
</tr>
<tr valign="top" bgcolor="#f5f5f5">
<td class="thleft"><img src="images/orange-icon.gif" border=0 hspace="5">เว็บไซต์กำลังพัฒนา ทดสอบและให้บริการภายในหน่วยงานสำนักบริการคอมพิวเตอร์ : จำนวน  31 records </td>
</tr>
</table>

            <td width="10"><img src="images/line_ver.gif" width="22" height="100%"></td>
          </tr>

          <tr valign="top" align="left"> 
            <td width="1" align="right" height="1"> <img src="images/spc_gry.gif" width="1" height="1"></td>
            <td width="100%" height="1"><img src="images/spc_gry.gif" width="100%"1 height="1""></td>
            <td width="10" height="1"><img src="images/bottom_r.gif" width="22" height="1"></td>
          </tr>
       </table>
	  </td>
	 </tr>
	</table>
	<br>
	</td>
    <!------------end left column------------------------>

	 <!------------begin right column------------------------>
      <td width="193" valign="top" align="right"> 
        <table width="193" border="0" cellspacing="0" cellpadding="0" align="left">
          <tr> 
            <td height="8"></td>
          </tr>
          <tr> 
            <td  valign="top" align="left"> 
		
        <table width="193" border="0" cellspacing="0" cellpadding="0"  align="left">
        <tr valign=top><td>
		<table width="193" border="0" cellspacing="0" cellpadding="0"  align="left">
         <tr valign="bottom"> 
            <td align="right" width="1" height="5"><img src="images/spc_gry.gif" width="1" height="1"></td>
             <td width="191" height="5"><img src="images/spc_gry.gif" width="100%" height="1"></td>
             <td align="left" width="1" height="5"><img src="images/spc_gry.gif" width="1" height="1"></td>
          </tr>

          <tr valign=top> 
             <td valign="top" align="right" height="50" width="1"><img src="images/spc_gry.gif"  width="1" height="100%"></td>
             <td  height="50" width="191" bgcolor="#ffffff" valign="top" align="center">
			 <img src="images/start-here.gif" border="0"><br>
              <a href="ssl.crt/root-ku-ca.crt"><img src="images/kuca-install-icon.jpg" border="0" hspace=3 vspace=3>
			  <br>เริ่มติดตั้งใบรับรองอิเล็กทรอนิกส์บนเครือข่ายนนทรี</a>
            </td>
             <td height="50" align="left" valign="top" width="1"><img src="images/spc_gry.gif"  width="1" height="100%"></td>
          </tr>

          <tr valign=top> 
             <td valign="top" align="right" height="50" width="1"><img src="images/spc_gry.gif"  width="1" height="100%"></td>
             <td  height="50" width="191" bgcolor="#ffffff" valign="top" align="center">
              <br><a href="guidesanddocs/kuca-prdocs.html"><img src="images/kuca-quickview.gif" border="0" hspace=3 vspace=3>
			  <br>quick view  บริการใบรับรองอิเล็กทรอนิกส์บนเครือข่ายนนทรี</a>
            </td>
             <td height="50" align="left" valign="top" width="1"><img src="images/spc_gry.gif"  width="1" height="100%"><br></td>
          </tr>

          <tr valign="top" align="left"> 
             <td width="1" align="right" height="2"><img src="images/spc_gry.gif" width="1" height="1"></td>
             <td width="191" height="2"><img src="images/spc_gry.gif" width="100%" height="1"></td>
             <td width="1" height="2"><img src="images/spc_gry.gif" width="1" height="1"></td>
          </tr>
       </table>
		</td></tr>

<!--      <tr valign=top><td>
       <table width="193" border="0" cellspacing="0" cellpadding="0"  align="left">
         <tr valign="bottom"> 
            <td align="right" width="1" height="5"><img src="images/spc_gry.gif" width="1" height="1"></td>
             <td width="191" height="5"><img src="images/spc_gry.gif" width="100%" height="1"></td>
             <td align="left" width="1" height="5"><img src="images/spc_gry.gif" width="1" height="1"></td>
          </tr>
          <tr valign=top> 
             <td valign="top" align="right" height="50" width="1"><img src="images/spc_gry.gif"  width="1" height="100%"></td>
             <td height="50" width="191" bgcolor="#f1efed"  class="thcenter">::  นานาสาระ :: <div=center><hr width=95%></div></td>
             <td height="50" align="left" valign="top" width="1"><img src="images/spc_gry.gif"  width="1" height="100%"></td>
          </tr>

          <tr valign=top> 
             <td valign="top" align="right" height="50" width="1"><img src="images/spc_gry.gif"  width="1" height="100%"></td>
             <td  height="50" width="191" bgcolor="#f1efed"  class="tdcenter"><a href="http://www.ku.ac.th/magazine_online/net_safety.html"><img src="images/net_safety.jpg" border="1"><br>การประยุกต์การใช้งานบนเครือข่ายในระดับปลอดภัย</a>
             <br><br><a href="http://gca.thaigov.net/"><img src="images/gca-logo.jpg" border="1"><br>บริการใบรับรองอิเล็กทรอนิกส์สำหรับภาครัฐ</a>
            </td>
             <td height="50" align="left" valign="top" width="1"><img src="images/spc_gry.gif"  width="1" height="100%"></td>
          </tr>

          <tr valign="top" align="left"> 
             <td width="1" align="right" height="2"><img src="images/spc_gry.gif" width="1" height="1"></td>
             <td width="191" height="2"><img src="images/spc_gry.gif" width="100%" height="1"></td>
             <td width="1" height="2"><img src="images/spc_gry.gif" width="1" height="1"></td>
          </tr>
       </table>
	    </td></tr> -->
   </table>
		
 </td>
     </tr>
    </table>
    </td>
	 <!------------end right column------------------------>

   </tr>
  </table>
</div>
</td></tr>
    <!------------------end bottom table--------------------------------->    
  

<tr valign=top bgcolor="#7a3c01" class="footnote"><td align=center>copyright &reg;  2005 
<br>all rights reserved use of this site is maintained and updated by computer system and network devision, office of computer services, kasetsart university
<br>last  maintained and updated:  29 august 2014
</td></tr>
</table>
</body>
</html>
