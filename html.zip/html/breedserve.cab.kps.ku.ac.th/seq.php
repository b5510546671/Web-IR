<!doctype html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>breedserve - sequencing services</title>
<style type=text/css>
a:link {color=#0000ff); text-decoration: none}
a:visited {color=#800080); text-decoration: none}
a:hover {color:rgb(255,0,0); text-decoration: underline}
</style>
</head>

<body>
    <div class="wrapper">
       <div align=center id="topbg">
         <p>&nbsp;</p>
       </div>
       <h1 width="85%" align='center' ><img src="img/breedserve_logo.png" width="649" height="92"  alt=""/></h1>
       <p width="85%" align='center' ><span style="font-size:18.0pt">ศูนย์เครือข่ายบริการเทคโนโลยีชั้นสูงด้านการปรับปรุงพันธุ์พืช</span></p>
       <!--h1 width="100%" align='center' ><img src="img/bif_db_head_green.png" width="841" height="154" alt=""/></h1>-->
       <div align=center></div>
      <div align="center">
        <table width="80%" align=center>
        <img src="img/greenline.png" width="80%"  >
          <tr align=center style='font-size: 14.0pt'>
            <td width="11%"><a href="index.php">home</a></td>
            <td width="11%"><a href="news.php">news</a></td>
            <td width="25%">sequencing services</a></td>
            <td width="27%"><a href="bif.php">bioinformatics services</a></td>
            <td width="26%"><a href="dbtools.php">databases and tools</a></td>
          </tr>        </table><img src="img/greenline.png" width="80%"  >
        <table width="80%" align=center>
          <tr>
            <td height="60" colspan=2><strong><span style="font-size:18.0pt">sequencing services </span></strong></td>
          </tr>
          <tr>
            <td width="31%" style='font-size:16.0pt'> <a href= "http://www.diversityarrays.com/dart-application-dartseq" target='_blank'>dart-seq</a></td>
            <td width="69%" style='font-size:16.0pt'>diversity array technology ptl ltd (dart p/l)</td>
          </tr>
          <tr>
            <td colspan=2 style='font-size:14.0pt'>&nbsp;</td>
            
          </tr>
          <tr>
          	<td> <a href = "http://www.diversityarrays.com/" target='_blank'><img src="img/dart_logo_tagline.png" width="85%"  alt=""/></a></td>
            <td colspan=1 style='font-size:14.0pt'><p>การให้บริกาคเพื่อนักปรับปรุงพันธุ์ทั้งในภาคัฐและเอกชน  โดยเทคโนโลยยีที่ทางศูนย์ส่งเสริมโดยความร่วมมือกับ diversity  arrays technology pty. ltd.  นั้นเป็นการใช้เทคโนโลยีด้าน next generation  sequencing (ngs) เพื่องานด้านปรับปรุงพันธุ์พืชที่มีความสัญคือ dartseq ซึ่งเป็นการวิเคราะห์ข้อมูลในระดับทั้งจีโนม  โดยทาง dart pty. ltd. จะบริการวิเคราะห์ข้อมูลด้วยการใช้เทคโนโลยี snp (single nucleotide  polymorphism) หรือ gbs (genotype by sequencing) ในการประเมินเชื้อพันธุกรรม </p>
              <p>ระยะเวลาในการวิเคราะห์ดีเอ็นเอนั้น ขึ้นกับความซับซ้อนของจีโนม ทั้งนี้กระบวนการวิเคราะห์ตัวอย่างโดยเฉลี่ยจะใช้เวลาประมาณ 8 สัปดาห์</p>
      		</td>
          </tr>
          <tr><td colspan=2 >&nbsp;</td></tr>
          <tr><td colspan=2 >&nbsp;</td></tr>
          <tr>
            <td colspan=2 style='font-size:14.0pt'>online request form : coming soon...</td></tr>
          <tr><td colspan=2 >&nbsp;</td></tr>
          <tr>
            <td colspan=2 align=right style='font-size:12.0pt'> for more information: kpsppto@ku.ac.th</td>
          </tr>
        </table>
      </div>
            <div class="push"></div>
</div>
        <div align=center></div>
        <br>
</body>
<div class='footer'><hr>
<p align='center' style='font-size:80%;'>สำนักงาน บางเขน : อาคารพิพิธภัณฑ์แมลง 60 ปี มหาวิทยาลัยเกษตรศาสตร์ บางเขน จตุจักร กรุงเทพฯ 10900  <br>สำนักงาน กำแพงแสน : ศูนย์เทคโนโลยีชีวภาพเกษตร มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน อ.กำแพงแสน จ.นครปฐม 73140</p>
</div><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p></html>

