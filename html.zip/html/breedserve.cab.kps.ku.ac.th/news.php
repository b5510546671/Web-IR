<!doctype html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>breedserve - bioinformatics services </title>
<style type=text/css>
a:link {color=#0000ff); text-decoration: none}
a:visited {color=#800080); text-decoration: none}
a:hover {color:rgb(255,0,0); text-decoration: underline}
</style>
</head>

<body>
    <div class="wrapper">
       <div align=center id="topbg">
         <p>&nbsp;</p>
       </div>
       <h1 width="85%" align='center' ><img src="img/breedserve_logo.png" width="649" height="92"  alt=""/></h1>
       <p width="85%" align='center' ><span style="font-size:18.0pt">ศูนย์เครือข่ายบริการเทคโนโลยีชั้นสูงด้านการปรับปรุงพันธุ์พืช</span></p>
       <!--h1 width="100%" align='center' ><img src="img/bif_db_head_green.png" width="841" height="154" alt=""/></h1>-->
       <div align=center></div>
      <div align="center">
        <table width="80%" align=center>
        <img src="img/greenline.png" width="80%"  >
          <tr align=center style='font-size: 14.0pt'>
            <td width="11%"><a href="index.php">home</a></td>
            <td width="11%">news</a></td>
            <td width="25%"><a href="seq.php">sequencing services</a></td>
            <td width="27%"><a href="bif.php">bioinformatics services</a></td>
            <td width="26%"><a href="dbtools.php">databases and tools</a></td>
          </tr>
        </table><img src="img/greenline.png" width="80%"  >
        <table width="80%" align=center>
          <tr>
            <td width="100%" height="60" style='font-size:18.0pt'><strong>news and activities</strong></td>
          </tr>
          <tr>
            <td ><p>3 มิ.ย. 59</p>
          <p align=center><a href="http://cab.kps.ku.ac.th/photoactivity/activity_detail.php?id=375" target='_blank'><img src="img/2016-06-03.jpg" width="80%"  alt=""/></a></p></td></tr>
          <tr>
          <td align=center style='font-size: 14.0pt; font-weight: 100;'><p>......................................................................................</p></td></tr>
          <tr>
            <td style='font-size:14.0pt'><p>breedserve in ag-bio newslettter</p>
          <p align=center><a href="http://www.cab.kps.ku.ac.th/ag-bio_book/pdf/ag-bio-7-4.pdf" target='_blank'><img src="img/bs_in_agbio.png" width="80%"  alt=""/></a></p></td></tr>
          <tr><td align=center style='font-size: 14.0pt; font-weight: 100;'>......................................................................................</td></tr>
          <tr>
            <td align=center>&nbsp;</td></tr>
          <tr><td align=center>&nbsp;</td></tr>
          <tr><td align=center>&nbsp;</td></tr>
</table>
        <p align=center >&nbsp;</p>
      </div>
            <div class="push"></div>
</div>
        <div align=center></div>
        <br>
</body>
<div class='footer'><hr>
<p align='center' style='font-size:80%;'>สำนักงาน บางเขน : อาคารพิพิธภัณฑ์แมลง 60 ปี มหาวิทยาลัยเกษตรศาสตร์ บางเขน จตุจักร กรุงเทพฯ 10900  <br>สำนักงาน กำแพงแสน : ศูนย์เทคโนโลยีชีวภาพเกษตร มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน อ.กำแพงแสน จ.นครปฐม 73140</p>
</div><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p></html>

